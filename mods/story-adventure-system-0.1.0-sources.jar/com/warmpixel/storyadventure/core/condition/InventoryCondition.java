package com.warmpixel.storyadventure.core.condition;

import com.google.gson.JsonObject;
import com.warmpixel.storyadventure.instance.Instance;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7923;

/**
 * Condition that checks if a player has a specific item in their inventory.
 */
public class InventoryCondition implements EdgeCondition {
    public static final String TYPE = "INVENTORY";
    
    private final String itemId;
    private final int minCount;
    private final boolean consumeOnTransition;
    
    public InventoryCondition(String itemId, int minCount, boolean consumeOnTransition) {
        this.itemId = itemId;
        this.minCount = minCount;
        this.consumeOnTransition = consumeOnTransition;
    }
    
    @Override
    public boolean evaluate(Instance instance, class_3222 player) {
        if (player == null) return false;
        
        class_2960 itemLocation = class_2960.method_12829(itemId);
        if (itemLocation == null) return false;
        
        class_1792 item = class_7923.field_41178.method_10223(itemLocation);
        
        int count = 0;
        for (class_1799 stack : player.method_31548().field_7547) {
            if (stack.method_7909() == item) {
                count += stack.method_7947();
            }
        }
        
        return count >= minCount;
    }
    
    @Override
    public String getType() {
        return TYPE;
    }
    
    @Override
    public JsonObject serialize() {
        JsonObject json = new JsonObject();
        json.addProperty("type", TYPE);
        json.addProperty("item", itemId);
        json.addProperty("count", minCount);
        json.addProperty("consume", consumeOnTransition);
        return json;
    }
    
    @Override
    public String getDescription() {
        return "Has " + minCount + "x " + itemId;
    }
    
    public boolean shouldConsume() {
        return consumeOnTransition;
    }
    
    public static InventoryCondition fromJson(JsonObject json) {
        String itemId = json.get("item").getAsString();
        int count = json.has("count") ? json.get("count").getAsInt() : 1;
        boolean consume = json.has("consume") && json.get("consume").getAsBoolean();
        return new InventoryCondition(itemId, count, consume);
    }
}
