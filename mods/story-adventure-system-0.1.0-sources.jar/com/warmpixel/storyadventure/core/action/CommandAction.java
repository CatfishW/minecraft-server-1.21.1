package com.warmpixel.storyadventure.core.action;

import com.google.gson.JsonObject;
import java.util.UUID;
import net.minecraft.class_2168;
import net.minecraft.class_3222;
import java.util.List;

/**
 * Action that executes a server command for each player.
 */
public class CommandAction implements NodeAction {
    
    private final String command;
    private final boolean asOp;
    
    public CommandAction(String command) {
        this(command, false);
    }
    
    public CommandAction(String command, boolean asOp) {
        this.command = command;
        this.asOp = asOp;
    }
    
    @Override
    public String getType() {
        return "COMMAND";
    }
    
    private UUID instanceId;

    public void setInstanceId(UUID instanceId) {
        this.instanceId = instanceId;
    }
    
    @Override
    public void execute(List<class_3222> players) {
        if (players.isEmpty()) return;
        
        var server = players.get(0).method_5682();
        if (server == null) return;

        for (class_3222 player : players) {
            String processedCmd = command
                .replace("{player}", player.method_5477().getString())
                .replace("{uuid}", player.method_5667().toString())
                .replace("{x}", String.format("%.2f", player.method_23317()))
                .replace("{y}", String.format("%.2f", player.method_23318()))
                .replace("{z}", String.format("%.2f", player.method_23321()));
                
            if (instanceId != null) {
                processedCmd = processedCmd.replace("{instance_id}", instanceId.toString());
            }
            
            class_2168 source = asOp ? server.method_3739() : player.method_5671();
            // Suppress output to prevent chat spam
            source = source.method_9217();
            // Ensure permission level if OP
            if (asOp) {
                source = source.method_9206(2);
            }
            
            server.method_3734().method_44252(source, processedCmd);
        }
    }
    
    @Override
    public JsonObject toJson() {
        JsonObject obj = new JsonObject();
        obj.addProperty("type", "COMMAND");
        obj.addProperty("command", command);
        if (asOp) obj.addProperty("as_op", true);
        return obj;
    }
    
    @Override
    public String getSummary() {
        return "命令: " + (command.length() > 30 ? command.substring(0, 28) + ".." : command);
    }
    
    public static CommandAction fromJson(JsonObject obj) {
        String cmd = obj.has("command") ? obj.get("command").getAsString() : "";
        boolean asOp = obj.has("as_op") && obj.get("as_op").getAsBoolean();
        return new CommandAction(cmd, asOp);
    }
}
