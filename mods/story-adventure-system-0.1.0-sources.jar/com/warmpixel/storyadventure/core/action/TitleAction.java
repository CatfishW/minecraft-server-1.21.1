package com.warmpixel.storyadventure.core.action;

import com.google.gson.JsonObject;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;

/**
 * Action that displays a title/subtitle to players.
 */
public class TitleAction implements NodeAction {
    
    private final String title;
    private final String subtitle;
    private final int fadeIn;
    private final int stay;
    private final int fadeOut;
    
    public TitleAction(String title, String subtitle) {
        this(title, subtitle, 10, 70, 20);
    }
    
    public TitleAction(String title, String subtitle, int fadeIn, int stay, int fadeOut) {
        this.title = title;
        this.subtitle = subtitle;
        this.fadeIn = fadeIn;
        this.stay = stay;
        this.fadeOut = fadeOut;
    }
    
    @Override
    public String getType() {
        return "TITLE";
    }
    
    @Override
    public void execute(List<class_3222> players) {
        for (class_3222 player : players) {
            // Set timing
            player.field_13987.method_14364(new class_5905(fadeIn, stay, fadeOut));
            
            // Set subtitle first (order matters)
            if (subtitle != null && !subtitle.isEmpty()) {
                player.field_13987.method_14364(new class_5903(
                    class_2561.method_43470(subtitle.replace("{player}", player.method_5477().getString()))
                ));
            }
            
            // Set title
            if (title != null && !title.isEmpty()) {
                player.field_13987.method_14364(new class_5904(
                    class_2561.method_43470(title.replace("{player}", player.method_5477().getString()))
                ));
            }
        }
    }
    
    @Override
    public JsonObject toJson() {
        JsonObject obj = new JsonObject();
        obj.addProperty("type", "TITLE");
        obj.addProperty("title", title);
        if (subtitle != null && !subtitle.isEmpty()) {
            obj.addProperty("subtitle", subtitle);
        }
        obj.addProperty("fade_in", fadeIn);
        obj.addProperty("stay", stay);
        obj.addProperty("fade_out", fadeOut);
        return obj;
    }
    
    @Override
    public String getSummary() {
        return "标题: " + (title != null && title.length() > 20 ? title.substring(0, 18) + ".." : title);
    }
    
    public static TitleAction fromJson(JsonObject obj) {
        String title = obj.has("title") ? obj.get("title").getAsString() : "";
        String subtitle = obj.has("subtitle") ? obj.get("subtitle").getAsString() : "";
        int fadeIn = obj.has("fade_in") ? obj.get("fade_in").getAsInt() : 10;
        int stay = obj.has("stay") ? obj.get("stay").getAsInt() : 70;
        int fadeOut = obj.has("fade_out") ? obj.get("fade_out").getAsInt() : 20;
        return new TitleAction(title, subtitle, fadeIn, stay, fadeOut);
    }
}
