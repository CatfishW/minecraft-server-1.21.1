package com.warmpixel.storyadventure.core.action;

import com.google.gson.JsonObject;
import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

/**
 * Action that teleports players to a location.
 */
public class TeleportAction implements NodeAction {
    
    private final String dimension;
    private final double x;
    private final double y;
    private final double z;
    private final float yaw;
    private final float pitch;
    
    public TeleportAction(String dimension, double x, double y, double z) {
        this(dimension, x, y, z, 0, 0);
    }
    
    public TeleportAction(String dimension, double x, double y, double z, float yaw, float pitch) {
        this.dimension = dimension;
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaw = yaw;
        this.pitch = pitch;
    }
    
    @Override
    public String getType() {
        return "TELEPORT";
    }
    
    @Override
    public void execute(List<class_3222> players) {
        for (class_3222 player : players) {
            try {
                class_2960 dimLoc = class_2960.method_12829(dimension);
                if (dimLoc != null && player.method_5682() != null) {
                    class_5321<class_1937> dimKey = class_5321.method_29179(class_7924.field_41223, dimLoc);
                    class_3218 targetLevel = player.method_5682().method_3847(dimKey);
                    
                    if (targetLevel != null) {
                        player.method_14251(targetLevel, x, y, z, yaw, pitch);
                    } else {
                        // Same dimension teleport
                        player.method_5859(x, y, z);
                    }
                }
            } catch (Exception e) {
                // Failed teleport, log but don't crash
                e.printStackTrace();
            }
        }
    }
    
    @Override
    public JsonObject toJson() {
        JsonObject obj = new JsonObject();
        obj.addProperty("type", "TELEPORT");
        obj.addProperty("dimension", dimension);
        obj.addProperty("x", x);
        obj.addProperty("y", y);
        obj.addProperty("z", z);
        if (yaw != 0) obj.addProperty("yaw", yaw);
        if (pitch != 0) obj.addProperty("pitch", pitch);
        return obj;
    }
    
    @Override
    public String getSummary() {
        return String.format("传送: %.0f, %.0f, %.0f", x, y, z);
    }
    
    public static TeleportAction fromJson(JsonObject obj) {
        String dim = obj.has("dimension") ? obj.get("dimension").getAsString() : "minecraft:overworld";
        double x = obj.has("x") ? obj.get("x").getAsDouble() : 0;
        double y = obj.has("y") ? obj.get("y").getAsDouble() : 64;
        double z = obj.has("z") ? obj.get("z").getAsDouble() : 0;
        float yaw = obj.has("yaw") ? obj.get("yaw").getAsFloat() : 0;
        float pitch = obj.has("pitch") ? obj.get("pitch").getAsFloat() : 0;
        return new TeleportAction(dim, x, y, z, yaw, pitch);
    }
}
