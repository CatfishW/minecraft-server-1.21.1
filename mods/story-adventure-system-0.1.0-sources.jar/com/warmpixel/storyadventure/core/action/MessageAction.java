package com.warmpixel.storyadventure.core.action;

import com.google.gson.JsonObject;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * Action that sends a message to all players.
 */
public class MessageAction implements NodeAction {
    
    private final String text;
    private final boolean actionBar;
    
    public MessageAction(String text) {
        this(text, false);
    }
    
    public MessageAction(String text, boolean actionBar) {
        this.text = text;
        this.actionBar = actionBar;
    }
    
    @Override
    public String getType() {
        return "MESSAGE";
    }
    
    @Override
    public void execute(List<class_3222> players) {
        for (class_3222 player : players) {
            String processed = text.replace("{player}", player.method_5477().getString());
            
            if (actionBar) {
                player.method_7353(class_2561.method_43470(processed), true);
            } else {
                player.method_43496(class_2561.method_43470(processed));
            }
        }
    }
    
    @Override
    public JsonObject toJson() {
        JsonObject obj = new JsonObject();
        obj.addProperty("type", "MESSAGE");
        obj.addProperty("text", text);
        if (actionBar) obj.addProperty("action_bar", true);
        return obj;
    }
    
    @Override
    public String getSummary() {
        return "消息: " + (text.length() > 25 ? text.substring(0, 23) + ".." : text);
    }
    
    public static MessageAction fromJson(JsonObject obj) {
        String text = obj.has("text") ? obj.get("text").getAsString() : "";
        boolean actionBar = obj.has("action_bar") && obj.get("action_bar").getAsBoolean();
        return new MessageAction(text, actionBar);
    }
}
