package com.warmpixel.storyadventure.core.action;

import com.google.gson.JsonObject;
import java.util.List;
import net.minecraft.class_243;
import net.minecraft.class_3222;

/**
 * Action that spawns an NPC at a specific location.
 */
public class SpawnNPCAction implements NodeAction {
    
    private final String npcTemplate;
    private final String dimension;
    private final class_243 position;
    private final float yaw;
    private final float pitch;
    private java.util.UUID instanceId;
    
    public SpawnNPCAction(String npcTemplate, String dimension, class_243 position, float yaw, float pitch) {
        this.npcTemplate = npcTemplate;
        this.dimension = dimension;
        this.position = position;
        this.yaw = yaw;
        this.pitch = pitch;
    }
    
    public void setInstanceId(java.util.UUID instanceId) {
        this.instanceId = instanceId;
    }
    
    @Override
    public String getType() {
        return "SPAWN_NPC";
    }

    @Override
    public String getSummary() {
        return "Spawn NPC: " + npcTemplate;
    }

    @Override
    public void execute(List<class_3222> players) {
        if (players.isEmpty()) return;
        
        var server = players.get(0).method_5682();
        if (server == null) return;
        
        // Get the server level for spawning
        net.minecraft.class_3218 level = null;
        for (var serverLevel : server.method_3738()) {
            if (serverLevel.method_27983().method_29177().toString().equals(dimension)) {
                level = serverLevel;
                break;
            }
        }
        
        if (level == null) {
            level = server.method_30002();
        }
        
        // Use NPCTemplateManager API to spawn entity to get reference
        try {
            com.warmpixel.storyadventure.StoryAdventureMod.LOGGER.info("[SpawnNPCAction] Attempting api spawn for template: {} at {},{},{}", 
                npcTemplate, position.field_1352, position.field_1351, position.field_1350);
            
            net.minecraft.class_1297 spawnedEntity = null;
            try {
                spawnedEntity = de.markusbordihn.easynpc.config.NPCTemplateManager.spawnEntityFromTemplate(
                    level, npcTemplate, position.field_1352, position.field_1351, position.field_1350
                );
            } catch (Throwable t) {
                com.warmpixel.storyadventure.StoryAdventureMod.LOGGER.error("[SpawnNPCAction] API call failed: {}", t.getMessage());
            }
            
            com.warmpixel.storyadventure.StoryAdventureMod.LOGGER.info("[SpawnNPCAction] API result for {}: {}", npcTemplate, spawnedEntity);
            
            if (spawnedEntity != null) {
                // Success! Add tags
                spawnedEntity.method_5780("story_enemy");
                if (instanceId != null) {
                    spawnedEntity.method_5780("instance_" + instanceId.toString());
                }
                
                com.warmpixel.storyadventure.StoryAdventureMod.LOGGER.info(
                    "[SpawnNPCAction] Successfully spawned NPC '{}' at {},{},{} with tags", 
                    npcTemplate, position.field_1352, position.field_1351, position.field_1350);
                
                // Set rotation
                spawnedEntity.method_36456(yaw);
                spawnedEntity.method_36457(pitch);
                // Force position update to apply rotation
                spawnedEntity.method_48105(level, position.field_1352, position.field_1351, position.field_1350, java.util.Set.of(), yaw, pitch);
                
            } else {
                // Fallback to command if API fails using the NEW command syntax
                StringBuilder tags = new StringBuilder("[\"story_enemy\"");
                if (instanceId != null) {
                    tags.append(",\"instance_").append(instanceId.toString()).append("\"");
                }
                tags.append("]");
                
                String nbt = String.format("{Tags:%s}", tags.toString());
                
                // Use the new syntax: easy_npc template spawn <template> <x> <y> <z> <nbt>
                // Enforce US Locale for coordinates to ensure '.' usage
                String cmd = String.format(java.util.Locale.US,
                    "easy_npc template spawn %s %.2f %.2f %.2f %s", 
                    npcTemplate, position.field_1352, position.field_1351, position.field_1350, nbt
                );
                
                // Execute in the correct dimension
                String fullCmd = String.format("execute in %s run %s", dimension, cmd);
                
                com.warmpixel.storyadventure.StoryAdventureMod.LOGGER.info("[SpawnNPCAction] Executing fallback command: {}", fullCmd);
                
                server.method_3734().method_44252(
                    server.method_3739().method_9217().method_9227(level).method_9206(2), 
                    fullCmd
                );
            }
        } catch (Exception e) {
            com.warmpixel.storyadventure.StoryAdventureMod.LOGGER.error(
                "[SpawnNPCAction] Error spawning NPC '{}': {}", npcTemplate, e.getMessage());
            e.printStackTrace();
        }
    }
    
    @Override
    public JsonObject toJson() {
        JsonObject json = new JsonObject();
        json.addProperty("type", "SPAWN_NPC");
        json.addProperty("npc_template", npcTemplate);
        json.addProperty("dimension", dimension);
        json.addProperty("x", position.field_1352);
        json.addProperty("y", position.field_1351);
        json.addProperty("z", position.field_1350);
        json.addProperty("yaw", yaw);
        json.addProperty("pitch", pitch);
        return json;
    }
    
    public static SpawnNPCAction fromJson(JsonObject json) {
        String template = json.has("npc_template") ? json.get("npc_template").getAsString() : "unknown";
        String dim = json.has("dimension") ? json.get("dimension").getAsString() : "minecraft:overworld";
        double x = json.has("x") ? json.get("x").getAsDouble() : 0;
        double y = json.has("y") ? json.get("y").getAsDouble() : 64;
        double z = json.has("z") ? json.get("z").getAsDouble() : 0;
        float yaw = json.has("yaw") ? json.get("yaw").getAsFloat() : 0;
        float pitch = json.has("pitch") ? json.get("pitch").getAsFloat() : 0;
        
        return new SpawnNPCAction(template, dim, new class_243(x, y, z), yaw, pitch);
    }
}
