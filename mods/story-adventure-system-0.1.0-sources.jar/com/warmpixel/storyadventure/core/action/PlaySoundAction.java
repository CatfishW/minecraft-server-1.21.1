package com.warmpixel.storyadventure.core.action;

import com.google.gson.JsonObject;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;

/**
 * Action that plays a sound effect to players.
 */
public class PlaySoundAction implements NodeAction {
    
    private final String sound;
    private final float volume;
    private final float pitch;
    
    public PlaySoundAction(String sound) {
        this(sound, 1.0f, 1.0f);
    }
    
    public PlaySoundAction(String sound, float volume, float pitch) {
        this.sound = sound;
        this.volume = volume;
        this.pitch = pitch;
    }
    
    @Override
    public String getType() {
        return "PLAY_SOUND";
    }
    
    @Override
    public void execute(List<class_3222> players) {
        for (class_3222 player : players) {
            try {
                class_2960 soundLoc = class_2960.method_12829(sound);
                if (soundLoc != null) {
                    class_3414 soundEvent = class_3414.method_47908(soundLoc);
                    player.method_17356(soundEvent, class_3419.field_15250, volume, pitch);
                }
            } catch (Exception e) {
                // Invalid sound, silently ignore
            }
        }
    }
    
    @Override
    public JsonObject toJson() {
        JsonObject obj = new JsonObject();
        obj.addProperty("type", "PLAY_SOUND");
        obj.addProperty("sound", sound);
        if (volume != 1.0f) obj.addProperty("volume", volume);
        if (pitch != 1.0f) obj.addProperty("pitch", pitch);
        return obj;
    }
    
    @Override
    public String getSummary() {
        return "播放: " + sound;
    }
    
    public static PlaySoundAction fromJson(JsonObject obj) {
        String sound = obj.has("sound") ? obj.get("sound").getAsString() : "minecraft:entity.experience_orb.pickup";
        float volume = obj.has("volume") ? obj.get("volume").getAsFloat() : 1.0f;
        float pitch = obj.has("pitch") ? obj.get("pitch").getAsFloat() : 1.0f;
        return new PlaySoundAction(sound, volume, pitch);
    }
}
