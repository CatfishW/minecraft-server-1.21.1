package com.warmpixel.storyadventure.core.action;

import com.google.gson.JsonObject;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7923;

/**
 * Action that gives items to players.
 */
public class GiveItemAction implements NodeAction {
    
    private final String itemId;
    private final int count;
    private final boolean silent;
    
    public GiveItemAction(String itemId, int count, boolean silent) {
        this.itemId = itemId;
        this.count = count;
        this.silent = silent;
    }

    @Override
    public String getType() {
        return "GIVE_ITEM";
    }

    @Override
    public String getSummary() {
        return "Give Item: " + itemId + " x" + count;
    }
    
    @Override
    public void execute(List<class_3222> players) {
        class_2960 rl = class_2960.method_60654(itemId);
        class_1792 item = class_7923.field_41178.method_10223(rl);
        
        if (item == class_7923.field_41178.method_10223(class_7923.field_41178.method_10137())) {
            // Item not found or is air (default)
            return;
        }
        
        for (class_3222 player : players) {
            class_1799 stack = new class_1799(item, count);
            player.method_31548().method_7394(stack);
            
            if (!silent) {
                player.method_43496(class_2561.method_43469("text.storyadventure.action.give_item", count, stack.method_7964()));
            }
        }
    }
    
    @Override
    public JsonObject toJson() {
        JsonObject json = new JsonObject();
        json.addProperty("type", "GIVE_ITEM");
        json.addProperty("item", itemId);
        json.addProperty("count", count);
        json.addProperty("silent", silent);
        return json;
    }
    
    public static GiveItemAction fromJson(JsonObject json) {
        String item = json.has("item") ? json.get("item").getAsString() : "minecraft:stone";
        int count = json.has("count") ? json.get("count").getAsInt() : 1;
        boolean silent = json.has("silent") && json.get("silent").getAsBoolean();
        return new GiveItemAction(item, count, silent);
    }
}
