package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload to sync the list of active instances to administrative clients.
 */
public record SyncInstancesPayload(List<InstanceInfo> instances) implements class_8710 {
    
    public static final class_8710.class_9154<SyncInstancesPayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "sync_instances"));
    
    public static final class_9139<class_2540, SyncInstancesPayload> STREAM_CODEC = 
        class_9139.method_56437(SyncInstancesPayload::write, SyncInstancesPayload::read);
    
    public record InstanceInfo(UUID id, String storyName, String node, String status, int playerCount, long elapsed) {}
    
    private static void write(class_2540 buf, SyncInstancesPayload payload) {
        buf.method_53002(payload.instances.size());
        for (InstanceInfo info : payload.instances) {
            buf.method_10797(info.id);
            buf.method_10814(info.storyName);
            buf.method_10814(info.node);
            buf.method_10814(info.status);
            buf.method_53002(info.playerCount);
            buf.method_52974(info.elapsed);
        }
    }
    
    private static SyncInstancesPayload read(class_2540 buf) {
        int size = buf.readInt();
        List<InstanceInfo> instances = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            instances.add(new InstanceInfo(
                buf.method_10790(),
                buf.method_19772(),
                buf.method_19772(),
                buf.method_19772(),
                buf.readInt(),
                buf.readLong()
            ));
        }
        return new SyncInstancesPayload(instances);
    }
    
    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
