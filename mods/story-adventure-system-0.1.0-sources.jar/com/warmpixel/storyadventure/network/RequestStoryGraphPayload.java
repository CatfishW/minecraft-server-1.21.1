package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload for requesting a story's JSON data from the server.
 */
public record RequestStoryGraphPayload(String storyId) implements class_8710 {
    public static final class_8710.class_9154<RequestStoryGraphPayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "request_story_graph"));
    
    public static final class_9139<class_2540, RequestStoryGraphPayload> STREAM_CODEC = 
        class_9139.method_56437(RequestStoryGraphPayload::write, RequestStoryGraphPayload::read);

    private static void write(class_2540 buf, RequestStoryGraphPayload payload) {
        buf.method_10814(payload.storyId);
    }
    
    private static RequestStoryGraphPayload read(class_2540 buf) {
        return new RequestStoryGraphPayload(buf.method_19772());
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
