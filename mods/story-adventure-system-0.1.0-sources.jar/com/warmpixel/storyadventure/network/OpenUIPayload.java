package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload to instruct the client to open a specific UI screen.
 */
public record OpenUIPayload(String screenType, String extraData) implements class_8710 {
    
    public static final class_8710.class_9154<OpenUIPayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "open_ui"));
    
    public static final class_9139<class_2540, OpenUIPayload> STREAM_CODEC = 
        class_9139.method_56437(OpenUIPayload::write, OpenUIPayload::read);
    
    // Screen type constants
    public static final String SCREEN_STORIES = "stories";
    public static final String SCREEN_LOBBY = "lobby";
    public static final String SCREEN_DIALOGUE = "dialogue";
    public static final String SCREEN_PUZZLE = "puzzle";
    public static final String SCREEN_ADMIN_DASHBOARD = "admin_dashboard";
    public static final String SCREEN_ADMIN_INSTANCES = "admin_instances";
    public static final String SCREEN_ADMIN_STORIES = "admin_stories";
    public static final String SCREEN_HUD_SHOW = "hud_show";
    public static final String SCREEN_HUD_HIDE = "hud_hide";
    public static final String SCREEN_VICTORY = "victory";
    
    private static void write(class_2540 buf, OpenUIPayload payload) {
        buf.method_10814(payload.screenType);
        buf.method_10814(payload.extraData);
    }
    
    private static OpenUIPayload read(class_2540 buf) {
        return new OpenUIPayload(buf.method_19772(), buf.method_19772());
    }
    
    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
