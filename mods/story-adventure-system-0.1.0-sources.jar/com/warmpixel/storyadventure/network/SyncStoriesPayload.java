package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload to sync available stories to the client.
 */
public record SyncStoriesPayload(List<StorySummary> stories) implements class_8710 {
    
    public static final class_8710.class_9154<SyncStoriesPayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "sync_stories"));
    
    public static final class_9139<class_2540, SyncStoriesPayload> STREAM_CODEC = 
        class_9139.method_56437(SyncStoriesPayload::write, SyncStoriesPayload::read);
    
    public record StorySummary(String id, String name, String description, int minPlayers, int maxPlayers, int estimatedMinutes) {}
    
    private static void write(class_2540 buf, SyncStoriesPayload payload) {
        buf.method_53002(payload.stories.size());
        for (StorySummary story : payload.stories) {
            buf.method_10814(story.id);
            buf.method_10814(story.name);
            buf.method_10814(story.description);
            buf.method_53002(story.minPlayers);
            buf.method_53002(story.maxPlayers);
            buf.method_53002(story.estimatedMinutes);
        }
    }
    
    private static SyncStoriesPayload read(class_2540 buf) {
        int size = buf.readInt();
        List<StorySummary> stories = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            stories.add(new StorySummary(
                buf.method_19772(),
                buf.method_19772(),
                buf.method_19772(),
                buf.readInt(),
                buf.readInt(),
                buf.readInt()
            ));
        }
        return new SyncStoriesPayload(stories);
    }
    
    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
