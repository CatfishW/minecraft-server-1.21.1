package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload for saving a story's JSON data back to the server.
 */
public record SaveStoryPayload(String storyId, String json) implements class_8710 {
    public static final class_8710.class_9154<SaveStoryPayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "save_story"));
    
    public static final class_9139<class_2540, SaveStoryPayload> STREAM_CODEC = 
        class_9139.method_56437(SaveStoryPayload::write, SaveStoryPayload::read);

    private static void write(class_2540 buf, SaveStoryPayload payload) {
        buf.method_10814(payload.storyId);
        buf.method_10814(payload.json);
    }
    
    private static SaveStoryPayload read(class_2540 buf) {
        return new SaveStoryPayload(buf.method_19772(), buf.method_19772());
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
