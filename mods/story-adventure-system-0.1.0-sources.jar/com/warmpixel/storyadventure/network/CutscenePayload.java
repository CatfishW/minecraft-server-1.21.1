package com.warmpixel.storyadventure.network;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Server-to-client payload for cutscene synchronization.
 * Allows the server to start, stop, or skip cutscenes on clients.
 */
public record CutscenePayload(
    String action,           // "START", "STOP", "SKIP"
    String instanceId,       // Instance ID for reference
    String cameraPathJson,   // JSON data for camera path (only for START)
    boolean skippable,       // Whether the cutscene can be skipped
    boolean letterbox,       // Enable letterbox bars
    int fadeInTicks,         // Fade in duration
    int fadeOutTicks         // Fade out duration
) implements class_8710 {
    
    public static final class_2960 ID = class_2960.method_60655("storyadventure", "cutscene");
    public static final class_8710.class_9154<CutscenePayload> TYPE = new class_8710.class_9154<>(ID);
    
    private static final Gson GSON = new Gson();
    
    public static final class_9139<class_2540, CutscenePayload> CODEC = new class_9139<>() {
        @Override
        public CutscenePayload decode(class_2540 buf) {
            String action = buf.method_19772();
            String instanceId = buf.method_19772();
            String cameraPathJson = buf.method_19772();
            boolean skippable = buf.readBoolean();
            boolean letterbox = buf.readBoolean();
            int fadeInTicks = buf.method_10816();
            int fadeOutTicks = buf.method_10816();
            return new CutscenePayload(action, instanceId, cameraPathJson, skippable, letterbox, fadeInTicks, fadeOutTicks);
        }
        
        @Override
        public void encode(class_2540 buf, CutscenePayload payload) {
            buf.method_10814(payload.action());
            buf.method_10814(payload.instanceId());
            buf.method_10814(payload.cameraPathJson());
            buf.method_52964(payload.skippable());
            buf.method_52964(payload.letterbox());
            buf.method_10804(payload.fadeInTicks());
            buf.method_10804(payload.fadeOutTicks());
        }
    };
    
    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
    
    // ==================== Factory Methods ====================
    
    /**
     * Create a START cutscene payload.
     */
    public static CutscenePayload start(String instanceId, JsonObject cameraPath, 
                                         boolean skippable, boolean letterbox,
                                         int fadeInTicks, int fadeOutTicks) {
        String pathJson = cameraPath != null ? GSON.toJson(cameraPath) : "{}";
        return new CutscenePayload("START", instanceId, pathJson, skippable, letterbox, fadeInTicks, fadeOutTicks);
    }
    
    /**
     * Create a STOP cutscene payload.
     */
    public static CutscenePayload stop(String instanceId) {
        return new CutscenePayload("STOP", instanceId, "", true, false, 0, 0);
    }
    
    /**
     * Create a SKIP cutscene payload.
     */
    public static CutscenePayload skip(String instanceId) {
        return new CutscenePayload("SKIP", instanceId, "", true, false, 0, 0);
    }
    
    /**
     * Parse camera path JSON to JsonObject.
     */
    public JsonObject getCameraPathAsJson() {
        if (cameraPathJson == null || cameraPathJson.isEmpty()) {
            return new JsonObject();
        }
        try {
            return GSON.fromJson(cameraPathJson, JsonObject.class);
        } catch (Exception e) {
            return new JsonObject();
        }
    }
}
