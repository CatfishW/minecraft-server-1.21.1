package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload for syncing active waypoints to clients in a story instance.
 */
public record SyncWaypointsPayload(List<WaypointData> waypoints) implements class_8710 {
    public static final class_8710.class_9154<SyncWaypointsPayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "sync_waypoints"));
    
    public static final class_9139<class_2540, SyncWaypointsPayload> STREAM_CODEC = 
        class_9139.method_56437(SyncWaypointsPayload::write, SyncWaypointsPayload::read);

    private static void write(class_2540 buf, SyncWaypointsPayload payload) {
        buf.method_10804(payload.waypoints.size());
        for (WaypointData wp : payload.waypoints) {
            buf.method_10814(wp.id);
            buf.method_10814(wp.label);
            buf.method_52940(wp.x);
            buf.method_52940(wp.y);
            buf.method_52940(wp.z);
            buf.method_10814(wp.icon);
            buf.method_53002(wp.color);
            buf.method_52964(wp.showDistance);
        }
    }
    
    private static SyncWaypointsPayload read(class_2540 buf) {
        int size = buf.method_10816();
        List<WaypointData> list = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            list.add(new WaypointData(
                buf.method_19772(), buf.method_19772(),
                buf.readDouble(), buf.readDouble(), buf.readDouble(),
                buf.method_19772(), buf.readInt(), buf.readBoolean()
            ));
        }
        return new SyncWaypointsPayload(list);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
    
    public record WaypointData(String id, String label, double x, double y, double z, 
                                String icon, int color, boolean showDistance) {}
}
