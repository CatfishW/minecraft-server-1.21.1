package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload to sync lobby member status to all clients in the lobby.
 */
public record SyncLobbyPayload(List<MemberInfo> members, int countdown) implements class_8710 {
    
    public static final class_8710.class_9154<SyncLobbyPayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "sync_lobby"));
    
    public static final class_9139<class_2540, SyncLobbyPayload> STREAM_CODEC = 
        class_9139.method_56437(SyncLobbyPayload::write, SyncLobbyPayload::read);
    
    public record MemberInfo(UUID id, String name, boolean ready, boolean isLeader) {}
    
    private static void write(class_2540 buf, SyncLobbyPayload payload) {
        buf.method_53002(payload.members.size());
        for (MemberInfo info : payload.members) {
            buf.method_10797(info.id);
            buf.method_10814(info.name);
            buf.method_52964(info.ready);
            buf.method_52964(info.isLeader);
        }
        buf.method_53002(payload.countdown);
    }
    
    private static SyncLobbyPayload read(class_2540 buf) {
        int size = buf.readInt();
        List<MemberInfo> members = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            members.add(new MemberInfo(buf.method_10790(), buf.method_19772(), buf.readBoolean(), buf.readBoolean()));
        }
        int countdown = buf.readInt();
        return new SyncLobbyPayload(members, countdown);
    }
    
    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
