package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload for party invitations.
 * C2S: Send invite to player name.
 * S2C: Receive invite from inviter name.
 */
public record InvitePayload(String name, boolean isResponse, boolean accept) implements class_8710 {
    
    public static final class_8710.class_9154<InvitePayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "invite"));
    
    public static final class_9139<class_2540, InvitePayload> STREAM_CODEC = 
        class_9139.method_56437(InvitePayload::write, InvitePayload::read);
    
    private static void write(class_2540 buf, InvitePayload payload) {
        buf.method_10814(payload.name);
        buf.method_52964(payload.isResponse);
        buf.method_52964(payload.accept);
    }
    
    private static InvitePayload read(class_2540 buf) {
        return new InvitePayload(buf.method_19772(), buf.readBoolean(), buf.readBoolean());
    }
    
    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
