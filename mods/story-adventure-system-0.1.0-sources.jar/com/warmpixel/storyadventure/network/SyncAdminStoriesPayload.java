package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload to sync detailed story information to admin clients.
 */
public record SyncAdminStoriesPayload(List<AdminStoryInfo> stories) implements class_8710 {
    
    public static final class_8710.class_9154<SyncAdminStoriesPayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "sync_admin_stories"));
    
    public static final class_9139<class_2540, SyncAdminStoriesPayload> STREAM_CODEC = 
        class_9139.method_56437(SyncAdminStoriesPayload::write, SyncAdminStoriesPayload::read);
    
    public record AdminStoryInfo(String id, String name, int nodeCount, String version, boolean valid, String errorMsg) {}
    
    private static void write(class_2540 buf, SyncAdminStoriesPayload payload) {
        buf.method_53002(payload.stories.size());
        for (AdminStoryInfo story : payload.stories) {
            buf.method_10814(story.id);
            buf.method_10814(story.name);
            buf.method_53002(story.nodeCount);
            buf.method_10814(story.version);
            buf.method_52964(story.valid);
            buf.method_10814(story.errorMsg);
        }
    }
    
    private static SyncAdminStoriesPayload read(class_2540 buf) {
        int size = buf.readInt();
        List<AdminStoryInfo> stories = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            stories.add(new AdminStoryInfo(
                buf.method_19772(),
                buf.method_19772(),
                buf.readInt(),
                buf.method_19772(),
                buf.readBoolean(),
                buf.method_19772()
            ));
        }
        return new SyncAdminStoriesPayload(stories);
    }
    
    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
