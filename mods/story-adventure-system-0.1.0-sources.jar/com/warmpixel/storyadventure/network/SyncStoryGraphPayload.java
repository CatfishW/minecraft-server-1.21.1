package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload for syncing a full story JSON to the client for the graph editor.
 */
public record SyncStoryGraphPayload(String storyId, String json) implements class_8710 {
    public static final class_8710.class_9154<SyncStoryGraphPayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "sync_story_graph"));
    
    public static final class_9139<class_2540, SyncStoryGraphPayload> STREAM_CODEC = 
        class_9139.method_56437(SyncStoryGraphPayload::write, SyncStoryGraphPayload::read);

    private static void write(class_2540 buf, SyncStoryGraphPayload payload) {
        buf.method_10814(payload.storyId);
        buf.method_10814(payload.json);
    }
    
    private static SyncStoryGraphPayload read(class_2540 buf) {
        return new SyncStoryGraphPayload(buf.method_19772(), buf.method_19772());
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
