package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload for administrative instance management actions.
 */
public record AdminInstanceActionPayload(Action action, UUID instanceId) implements class_8710 {
    
    public static final class_8710.class_9154<AdminInstanceActionPayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "admin_instance_action"));
    
    public static final class_9139<class_2540, AdminInstanceActionPayload> STREAM_CODEC = 
        class_9139.method_56437(AdminInstanceActionPayload::write, AdminInstanceActionPayload::read);

    public enum Action {
        SYNC, TERMINATE, PAUSE, RESUME
    }

    private static void write(class_2540 buf, AdminInstanceActionPayload payload) {
        buf.method_10817(payload.action);
        buf.method_52964(payload.instanceId != null);
        if (payload.instanceId != null) {
            buf.method_10797(payload.instanceId);
        }
    }
    
    private static AdminInstanceActionPayload read(class_2540 buf) {
        Action action = buf.method_10818(Action.class);
        UUID instanceId = buf.readBoolean() ? buf.method_10790() : null;
        return new AdminInstanceActionPayload(action, instanceId);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
