package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload for dialogue choices.
 */
public record DialogueChoicePayload(String choiceId) implements class_8710 {
    
    public static final class_8710.class_9154<DialogueChoicePayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "dialogue_choice"));
    
    public static final class_9139<class_2540, DialogueChoicePayload> STREAM_CODEC = 
        class_9139.method_56437(DialogueChoicePayload::write, DialogueChoicePayload::read);
    
    private static void write(class_2540 buf, DialogueChoicePayload payload) {
        buf.method_10814(payload.choiceId);
    }
    
    private static DialogueChoicePayload read(class_2540 buf) {
        return new DialogueChoicePayload(buf.method_19772());
    }
    
    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
