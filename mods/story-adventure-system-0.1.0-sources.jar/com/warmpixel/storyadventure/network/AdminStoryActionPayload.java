package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload for administrative story management actions.
 * Used to request data sync, reload stories, or validate them.
 */
public record AdminStoryActionPayload(Action action, String storyId) implements class_8710 {
    
    public static final class_8710.class_9154<AdminStoryActionPayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "admin_story_action"));
    
    public static final class_9139<class_2540, AdminStoryActionPayload> STREAM_CODEC = 
        class_9139.method_56437(AdminStoryActionPayload::write, AdminStoryActionPayload::read);

    public enum Action {
        SYNC, RELOAD, VALIDATE
    }

    private static void write(class_2540 buf, AdminStoryActionPayload payload) {
        buf.method_10817(payload.action);
        buf.method_10814(payload.storyId != null ? payload.storyId : "");
    }
    
    private static AdminStoryActionPayload read(class_2540 buf) {
        return new AdminStoryActionPayload(
            buf.method_10818(Action.class),
            buf.method_19772()
        );
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
