package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Client-to-server payload sent when a player confirms the victory screen
 * or when the countdown timer expires.
 */
public record VictoryConfirmPayload() implements class_8710 {
    
    public static final class_8710.class_9154<VictoryConfirmPayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "victory_confirm"));
    
    public static final class_9139<class_2540, VictoryConfirmPayload> STREAM_CODEC = 
        class_9139.method_56437(VictoryConfirmPayload::write, VictoryConfirmPayload::read);
    
    private static void write(class_2540 buf, VictoryConfirmPayload payload) {
        // No data needed - server knows player's instance from their UUID
    }
    
    private static VictoryConfirmPayload read(class_2540 buf) {
        return new VictoryConfirmPayload();
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
