package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload for story-related actions (Select, Start, Leave).
 */
public record StoryActionPayload(Action action, String data) implements class_8710 {
    
    public static final class_8710.class_9154<StoryActionPayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "story_action"));
    
    public static final class_9139<class_2540, StoryActionPayload> STREAM_CODEC = 
        class_9139.method_56437(StoryActionPayload::write, StoryActionPayload::read);
    
    public enum Action {
        SELECT_STORY,
        START_ADVENTURE,
        LEAVE_PARTY,
        DISBAND_PARTY
    }
    
    private static void write(class_2540 buf, StoryActionPayload payload) {
        buf.method_10817(payload.action);
        buf.method_10814(payload.data);
    }
    
    private static StoryActionPayload read(class_2540 buf) {
        return new StoryActionPayload(buf.method_10818(Action.class), buf.method_19772());
    }
    
    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
