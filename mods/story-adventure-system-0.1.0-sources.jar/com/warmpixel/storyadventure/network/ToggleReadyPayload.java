package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload to toggle ready status in a lobby.
 */
public record ToggleReadyPayload(boolean ready) implements class_8710 {
    
    public static final class_8710.class_9154<ToggleReadyPayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "toggle_ready"));
    
    public static final class_9139<class_2540, ToggleReadyPayload> STREAM_CODEC = 
        class_9139.method_56437(ToggleReadyPayload::write, ToggleReadyPayload::read);
    
    private static void write(class_2540 buf, ToggleReadyPayload payload) {
        buf.method_52964(payload.ready);
    }
    
    private static ToggleReadyPayload read(class_2540 buf) {
        return new ToggleReadyPayload(buf.readBoolean());
    }
    
    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
