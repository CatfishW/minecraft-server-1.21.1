package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload for syncing trigger boxes to clients (for gizmo rendering).
 */
public record SyncTriggerBoxesPayload(List<TriggerBoxData> boxes) implements class_8710 {
    public static final class_8710.class_9154<SyncTriggerBoxesPayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "sync_trigger_boxes"));
    
    public static final class_9139<class_2540, SyncTriggerBoxesPayload> STREAM_CODEC = 
        class_9139.method_56437(SyncTriggerBoxesPayload::write, SyncTriggerBoxesPayload::read);

    private static void write(class_2540 buf, SyncTriggerBoxesPayload payload) {
        buf.method_10804(payload.boxes.size());
        for (TriggerBoxData box : payload.boxes) {
            buf.method_10814(box.id);
            buf.method_10814(box.label);
            buf.method_52940(box.minX);
            buf.method_52940(box.minY);
            buf.method_52940(box.minZ);
            buf.method_52940(box.maxX);
            buf.method_52940(box.maxY);
            buf.method_52940(box.maxZ);
            buf.method_52964(box.hasPlayersInside);
        }
    }
    
    private static SyncTriggerBoxesPayload read(class_2540 buf) {
        int size = buf.method_10816();
        List<TriggerBoxData> list = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            list.add(new TriggerBoxData(
                buf.method_19772(), buf.method_19772(),
                buf.readDouble(), buf.readDouble(), buf.readDouble(),
                buf.readDouble(), buf.readDouble(), buf.readDouble(),
                buf.readBoolean()
            ));
        }
        return new SyncTriggerBoxesPayload(list);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
    
    public record TriggerBoxData(String id, String label,
                                  double minX, double minY, double minZ,
                                  double maxX, double maxY, double maxZ,
                                  boolean hasPlayersInside) {}
}
