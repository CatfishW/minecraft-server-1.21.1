package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload for puzzle inputs.
 */
public record PuzzleInputPayload(String input) implements class_8710 {
    
    public static final class_8710.class_9154<PuzzleInputPayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "puzzle_input"));
    
    public static final class_9139<class_2540, PuzzleInputPayload> STREAM_CODEC = 
        class_9139.method_56437(PuzzleInputPayload::write, PuzzleInputPayload::read);
    
    private static void write(class_2540 buf, PuzzleInputPayload payload) {
        buf.method_10814(payload.input);
    }
    
    private static PuzzleInputPayload read(class_2540 buf) {
        return new PuzzleInputPayload(buf.method_19772());
    }
    
    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
