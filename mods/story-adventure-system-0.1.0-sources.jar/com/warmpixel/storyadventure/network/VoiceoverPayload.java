package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload for sending voiceover audio to clients.
 * Triggers playback of pre-recorded OGG files for dialogue and narrator lines.
 */
public record VoiceoverPayload(
    String instanceId,
    String soundPath,
    float volume,
    float pitch,
    String characterId
) implements class_8710 {
    
    public static final class_9154<VoiceoverPayload> TYPE = 
        new class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "voiceover"));
    
    public static final class_9139<class_2540, VoiceoverPayload> STREAM_CODEC = 
        class_9139.method_56437(VoiceoverPayload::write, VoiceoverPayload::read);
    
    public static void write(class_2540 buf, VoiceoverPayload payload) {
        buf.method_10814(payload.instanceId);
        buf.method_10814(payload.soundPath);
        buf.method_52941(payload.volume);
        buf.method_52941(payload.pitch);
        buf.method_10814(payload.characterId);
    }
    
    public static VoiceoverPayload read(class_2540 buf) {
        return new VoiceoverPayload(
            buf.method_19772(),
            buf.method_19772(),
            buf.readFloat(),
            buf.readFloat(),
            buf.method_19772()
        );
    }
    
    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
    
    /**
     * Create a voiceover payload for the narrator.
     */
    public static VoiceoverPayload narrator(String instanceId, String soundPath) {
        return new VoiceoverPayload(instanceId, soundPath, 1.0f, 1.0f, "narrator");
    }
    
    /**
     * Create a voiceover payload for a character.
     */
    public static VoiceoverPayload character(String instanceId, String soundPath, String characterId) {
        return new VoiceoverPayload(instanceId, soundPath, 1.0f, 1.0f, characterId);
    }
    
    /**
     * Create a voiceover payload with custom volume and pitch.
     */
    public static VoiceoverPayload custom(String instanceId, String soundPath, float volume, float pitch, String characterId) {
        return new VoiceoverPayload(instanceId, soundPath, volume, pitch, characterId);
    }
}
