package com.warmpixel.storyadventure.network;

import com.warmpixel.storyadventure.StoryAdventureMod;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Payload for admin trigger box actions (save, delete).
 */
public record AdminTriggerActionPayload(Action action, String id, String label, 
                                        double minX, double minY, double minZ,
                                        double maxX, double maxY, double maxZ,
                                        String linkedNodeId) implements class_8710 {
    
    public static final class_8710.class_9154<AdminTriggerActionPayload> TYPE = 
        new class_8710.class_9154<>(class_2960.method_60655(StoryAdventureMod.MOD_ID, "admin_trigger_action"));
    
    public static final class_9139<class_2540, AdminTriggerActionPayload> STREAM_CODEC = 
        class_9139.method_56437(AdminTriggerActionPayload::write, AdminTriggerActionPayload::read);

    public enum Action {
        SAVE, DELETE, LIST
    }

    private static void write(class_2540 buf, AdminTriggerActionPayload payload) {
        buf.method_10817(payload.action);
        buf.method_10814(payload.id);
        buf.method_10814(payload.label != null ? payload.label : "");
        buf.method_52940(payload.minX);
        buf.method_52940(payload.minY);
        buf.method_52940(payload.minZ);
        buf.method_52940(payload.maxX);
        buf.method_52940(payload.maxY);
        buf.method_52940(payload.maxZ);
        buf.method_10814(payload.linkedNodeId != null ? payload.linkedNodeId : "");
    }
    
    private static AdminTriggerActionPayload read(class_2540 buf) {
        return new AdminTriggerActionPayload(
            buf.method_10818(Action.class),
            buf.method_19772(),
            buf.method_19772(),
            buf.readDouble(), buf.readDouble(), buf.readDouble(),
            buf.readDouble(), buf.readDouble(), buf.readDouble(),
            buf.method_19772()
        );
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
