package com.warmpixel.storyadventure.client.audio;

import com.warmpixel.storyadventure.StoryAdventureMod;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.openal.AL10;
import org.lwjgl.stb.STBVorbis;
import org.lwjgl.stb.STBVorbisInfo;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Manages voiceover audio playback on the client.
 * Uses LWJGL's STBVorbis and OpenAL to play OGG files from the config directory.
 * This bypasses Minecraft's resource pack system to allow dynamic audio loading.
 */
@Environment(EnvType.CLIENT)
public class VoiceoverManager {
    
    private static VoiceoverManager instance;
    
    // OpenAL source and buffer for current voiceover
    private int currentSource = -1;
    private int currentBuffer = -1;
    private boolean isPlaying = false;
    
    private VoiceoverManager() {}

    
    public static VoiceoverManager getInstance() {
        if (instance == null) {
            instance = new VoiceoverManager();
        }
        return instance;
    }
    
    /**
     * Play a voiceover sound from the voiceovers folder.
     * Path format: "story_id/sound_name" (without .ogg extension)
     * Files are loaded from: config/storyadventure/voiceovers/<path>.ogg
     * 
     * @param soundPath Path to the sound file (e.g., "stranger_things_hawkins/narrator_intro")
     * @param volume Volume level (0.0 - 1.0)
     * @param pitch Pitch level (0.5 - 2.0)
     * @param characterId Character identifier for logging
     */
    public void playVoiceover(String soundPath, float volume, float pitch, String characterId) {
        // Stop any currently playing voiceover
        stopCurrentVoiceover();
        
        // Build the full path to the OGG file
        Path voiceoverPath = Paths.get("config", "storyadventure", "voiceovers", soundPath + ".ogg");
        
        if (!Files.exists(voiceoverPath)) {
            StoryAdventureMod.LOGGER.debug("[VoiceoverManager] Voiceover file not found: {} (graceful fallback)", voiceoverPath);
            return;
        }
        
        try {
            // Load and play the OGG file using OpenAL
            playOggFile(voiceoverPath.toAbsolutePath().toString(), volume, pitch);
            StoryAdventureMod.LOGGER.info("[VoiceoverManager] Playing voiceover: {} (character: {})", soundPath, characterId);
            
        } catch (Exception e) {
            StoryAdventureMod.LOGGER.warn("[VoiceoverManager] Failed to play voiceover: {} - {}", soundPath, e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Play an OGG file using OpenAL directly.
     * This method decodes the entire OGG file into memory (suitable for voiceovers).
     */
    private void playOggFile(String filePath, float volume, float pitch) throws IOException {
        // Read the file into a byte buffer
        byte[] fileData = Files.readAllBytes(Paths.get(filePath));
        ByteBuffer fileBuffer = MemoryUtil.memAlloc(fileData.length);
        fileBuffer.put(fileData).flip();
        
        try (MemoryStack stack = MemoryStack.stackPush()) {
            IntBuffer errorBuffer = stack.mallocInt(1);
            
            // Open the Vorbis decoder from memory
            long decoder = STBVorbis.stb_vorbis_open_memory(fileBuffer, errorBuffer, null);
            if (decoder == 0) {
                MemoryUtil.memFree(fileBuffer);
                throw new IOException("Failed to open OGG file: error code " + errorBuffer.get(0));
            }
            
            try (STBVorbisInfo info = STBVorbisInfo.malloc(stack)) {
                // Get audio info
                STBVorbis.stb_vorbis_get_info(decoder, info);
                int channels = info.channels();
                int sampleRate = info.sample_rate();
                
                // Get the total number of samples
                int totalSamples = STBVorbis.stb_vorbis_stream_length_in_samples(decoder);
                
                // Allocate buffer for PCM data
                ShortBuffer pcmBuffer = MemoryUtil.memAllocShort(totalSamples * channels);
                
                try {
                    // Decode the entire file
                    STBVorbis.stb_vorbis_get_samples_short_interleaved(decoder, channels, pcmBuffer);
                    pcmBuffer.flip();
                    
                    // Determine OpenAL format
                    int format = channels == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16;
                    
                    // Create OpenAL buffer
                    currentBuffer = AL10.alGenBuffers();
                    AL10.alBufferData(currentBuffer, format, pcmBuffer, sampleRate);
                    
                    // Create OpenAL source
                    currentSource = AL10.alGenSources();
                    AL10.alSourcei(currentSource, AL10.AL_BUFFER, currentBuffer);
                    AL10.alSourcef(currentSource, AL10.AL_GAIN, volume);
                    AL10.alSourcef(currentSource, AL10.AL_PITCH, pitch);
                    AL10.alSourcei(currentSource, AL10.AL_LOOPING, AL10.AL_FALSE);
                    
                    // Position the source at the listener (non-positional audio)
                    AL10.alSourcei(currentSource, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
                    AL10.alSource3f(currentSource, AL10.AL_POSITION, 0, 0, 0);
                    
                    // Play the sound
                    AL10.alSourcePlay(currentSource);
                    isPlaying = true;
                    
                    StoryAdventureMod.LOGGER.debug("[VoiceoverManager] OpenAL playback started: channels={}, sampleRate={}, samples={}", 
                        channels, sampleRate, totalSamples);
                    
                } finally {
                    MemoryUtil.memFree(pcmBuffer);
                }
            } finally {
                STBVorbis.stb_vorbis_close(decoder);
            }
        } finally {
            MemoryUtil.memFree(fileBuffer);
        }
    }
    
    /**
     * Play a voiceover with default volume and pitch.
     */
    public void playVoiceover(String soundPath, String characterId) {
        playVoiceover(soundPath, 1.0f, 1.0f, characterId);
    }
    
    /**
     * Stop the currently playing voiceover if any.
     */
    public void stopCurrentVoiceover() {
        if (currentSource != -1) {
            AL10.alSourceStop(currentSource);
            AL10.alDeleteSources(currentSource);
            currentSource = -1;
        }
        if (currentBuffer != -1) {
            AL10.alDeleteBuffers(currentBuffer);
            currentBuffer = -1;
        }
        isPlaying = false;
        StoryAdventureMod.LOGGER.debug("[VoiceoverManager] Stopped current voiceover");
    }
    
    /**
     * Check if a voiceover is currently playing.
     */
    public boolean isPlaying() {
        if (currentSource != -1) {
            int state = AL10.alGetSourcei(currentSource, AL10.AL_SOURCE_STATE);
            return state == AL10.AL_PLAYING;
        }
        return false;
    }
    
    /**
     * Get the path to the voiceovers directory for a specific story.
     */
    public static Path getVoiceoversPath(String storyId) {
        return Paths.get("config", "storyadventure", "voiceovers", storyId);
    }
    
    /**
     * Check if a voiceover file exists.
     */
    public static boolean voiceoverExists(String soundPath) {
        Path path = Paths.get("config", "storyadventure", "voiceovers", soundPath + ".ogg");
        return Files.exists(path);
    }
    
    /**
     * Ensure the voiceovers directory exists for a story.
     */
    public static void ensureVoiceoverDirectory(String storyId) {
        try {
            Path dir = getVoiceoversPath(storyId);
            if (!Files.exists(dir)) {
                Files.createDirectories(dir);
                StoryAdventureMod.LOGGER.info("[VoiceoverManager] Created voiceover directory: {}", dir);
            }
        } catch (IOException e) {
            StoryAdventureMod.LOGGER.error("[VoiceoverManager] Failed to create voiceover directory", e);
        }
    }
    
    /**
     * Cleanup resources on shutdown.
     */
    public void cleanup() {
        stopCurrentVoiceover();
    }
}
