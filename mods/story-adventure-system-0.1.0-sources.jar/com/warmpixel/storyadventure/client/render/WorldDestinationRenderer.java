package com.warmpixel.storyadventure.client.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Renders 3D indicators at target destinations (e.g., rotating circles).
 */
public class WorldDestinationRenderer {

    private static final List<class_243> destinations = new ArrayList<>();
    private static boolean enabled = true;

    public static void register() {
        WorldRenderEvents.AFTER_TRANSLUCENT.register(WorldDestinationRenderer::onWorldRender);
    }

    public static void setDestinations(List<class_243> points) {
        synchronized (destinations) {
            destinations.clear();
            destinations.addAll(points);
        }
    }

    public static void clearDestinations() {
        synchronized (destinations) {
            destinations.clear();
        }
    }

    private static void onWorldRender(WorldRenderContext context) {
        if (!enabled || destinations.isEmpty()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        class_243 cameraPos = context.camera().method_19326();
        class_4587 poseStack = context.matrixStack();
        if (poseStack == null) return;
        
        // Use a transparent layer
        class_4588 consumer = context.consumers().getBuffer(class_1921.method_23594());

        float time = (mc.field_1687.method_8510() + context.tickCounter().method_60637(true)) / 20.0f;
        
        poseStack.method_22903();
        poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);
        
        Matrix4f matrix = poseStack.method_23760().method_23761();
        
        synchronized (destinations) {
            class_243 playerPos = mc.field_1724.method_19538();
            for (class_243 pos : destinations) {
                renderRotatingCircle(consumer, matrix, pos, time);
                renderPillar(consumer, matrix, pos, time);
                
                // Breadcrumbs trail leading to destination
                renderBreadcrumbs(consumer, matrix, playerPos, pos, time);
            }
        }
        
        poseStack.method_22909();
    }

    private static void renderBreadcrumbs(class_4588 consumer, Matrix4f matrix, class_243 start, class_243 end, float time) {
        double dist = start.method_1022(end);
        if (dist < 5.0) return; // Hide when very close to avoid clutter
        
        // Direction vector
        class_243 dir = end.method_1020(start).method_1029();
        
        // Stranger Things Neon Red color for path
        int r = 255, g = 20, b = 20, a = 200;
        
        // Render dots every 2 blocks instead of 4 for a smoother path
        // Increase render distance for breadcrumbs to 64 blocks
        double maxTrailDist = Math.min(dist - 3.0, 64.0);
        
        for (double d = 6.0; d < maxTrailDist; d += 2.0) {
            class_243 point = start.method_1019(dir.method_1021(d));
            
            // Pulsing animation
            float pulse = (float) Math.sin(time * 4.0f + d * 0.8f);
            
            // Neon flicker effect
            float flicker = (class_310.method_1551().field_1687.method_8510() + (int)d) % 15 == 0 ? 0.3f : 1.0f;
            int currentAlpha = (int)(a * flicker);
            
            float scale = 0.08f + 0.04f * pulse;
            float yOffset = 1.2f + 0.3f * pulse; 
            
            // Add a small "float" motion
            double ox = Math.cos(time * 2.5f + d) * 0.15;
            double oz = Math.sin(time * 2.5f + d) * 0.15;
            
            drawStar(consumer, matrix, point.field_1352 + ox, point.field_1351 + yOffset, point.field_1350 + oz, scale, r, g, b, currentAlpha, time + (float)d);
        }
    }

    private static void drawStar(class_4588 consumer, Matrix4f matrix, double x, double y, double z, float s, int r, int g, int b, int a, float time) {
        // Draw a rotating cross/star shape
        float rot = time * 2.0f;
        float cos = (float) Math.cos(rot) * s;
        float sin = (float) Math.sin(rot) * s;
        
        // Main vertical line
        consumer.method_22918(matrix, (float)x, (float)y - s*1.5f, (float)z).method_1336(r, g, b, a).method_22914(0, 1, 0);
        consumer.method_22918(matrix, (float)x, (float)y + s*1.5f, (float)z).method_1336(r, g, b, a).method_22914(0, 1, 0);
        
        // Rotating horizontal cross 1
        consumer.method_22918(matrix, (float)x - cos, (float)y, (float)z - sin).method_1336(r, g, b, a).method_22914(0, 1, 0);
        consumer.method_22918(matrix, (float)x + cos, (float)y, (float)z + sin).method_1336(r, g, b, a).method_22914(0, 1, 0);
        
        // Rotating horizontal cross 2 (perpendicular)
        consumer.method_22918(matrix, (float)x + sin, (float)y, (float)z - cos).method_1336(r, g, b, a).method_22914(0, 1, 0);
        consumer.method_22918(matrix, (float)x - sin, (float)y, (float)z + cos).method_1336(r, g, b, a).method_22914(0, 1, 0);
    }

    private static void renderRotatingCircle(class_4588 consumer, Matrix4f matrix, class_243 pos, float time) {
        int segments = 32; // More segments for smoother look
        float radius = 2.0f;
        float rotation = time * 2.0f;
        
        // Stranger Things Neon Red
        int r = 255, g = 10, b = 10, a = 255;
        
        for (int i = 0; i < segments; i++) {
            float angle1 = (float) i / segments * class_3532.field_29846 + rotation;
            float angle2 = (float) (i + 1) / segments * class_3532.field_29846 + rotation;

            float x1 = (float) (pos.field_1352 + class_3532.method_15362(angle1) * radius);
            float z1 = (float) (pos.field_1350 + class_3532.method_15374(angle1) * radius);
            float y1 = (float) (pos.field_1351 + 0.1f + class_3532.method_15374(time * 3.0f + angle1 * 3) * 0.15f);

            float x2 = (float) (pos.field_1352 + class_3532.method_15362(angle2) * radius);
            float z2 = (float) (pos.field_1350 + class_3532.method_15374(angle2) * radius);
            float y2 = (float) (pos.field_1351 + 0.1f + class_3532.method_15374(time * 3.0f + angle2 * 3) * 0.15f);

            // Exterior glow (Red)
            consumer.method_22918(matrix, x1, y1, z1).method_1336(r, g, b, a).method_22914(0, 1, 0);
            consumer.method_22918(matrix, x2, y2, z2).method_1336(r, g, b, a).method_22914(0, 1, 0);
            
            // Interior glow (White/Pink for neon effect)
            consumer.method_22918(matrix, x1, y1 + 0.05f, z1).method_1336(255, 200, 200, 200).method_22914(0, 1, 0);
            consumer.method_22918(matrix, x2, y2 + 0.05f, z2).method_1336(255, 200, 200, 200).method_22914(0, 1, 0);
        }
    }

    private static void renderPillar(class_4588 consumer, Matrix4f matrix, class_243 pos, float time) {
        float height = 20.0f; // Taller pillar for easier sighting
        int r = 255, g = 50, b = 50, a = 80;

        // Central vertical beam (more detailed)
        for (int i = 0; i < 8; i++) {
            float angle = (i / 8.0f) * class_3532.field_29846 + time;
            float offset = 0.05f + (float)Math.sin(time * 2.0 + i) * 0.02f;
            float ox = class_3532.method_15362(angle) * offset;
            float oz = class_3532.method_15374(angle) * offset;
            
            consumer.method_22918(matrix, (float)pos.field_1352 + ox, (float)pos.field_1351, (float)pos.field_1350 + oz).method_1336(r, g, b, a).method_22914(0, 1, 0);
            consumer.method_22918(matrix, (float)pos.field_1352 + ox, (float)pos.field_1351 + height, (float)pos.field_1350 + oz).method_1336(r, g, b, 0).method_22914(0, 1, 0);
        }
    }
}
