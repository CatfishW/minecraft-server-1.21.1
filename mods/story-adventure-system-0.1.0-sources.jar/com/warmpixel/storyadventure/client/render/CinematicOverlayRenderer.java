package com.warmpixel.storyadventure.client.render;

import com.warmpixel.storyadventure.client.cinematic.CinematicCameraController;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9779;

/**
 * Renders cinematic overlay effects during cutscenes.
 * Includes letterbox bars, fade effects, skip prompt, and progress bar.
 */
public class CinematicOverlayRenderer implements HudRenderCallback {
    
    private static CinematicOverlayRenderer instance;
    
    // Letterbox settings
    private static final float LETTERBOX_HEIGHT_RATIO = 0.12f; // 12% of screen height for each bar
    private static final int LETTERBOX_COLOR = 0xFF000000; // Pure black
    
    // Fade settings
    private static final int FADE_COLOR_BASE = 0x000000; // Black fade
    
    // Skip prompt
    private static final String SKIP_PROMPT = "Press [ESC] to skip";
    private static final int SKIP_PROMPT_COLOR = 0xAAFFFFFF;
    
    public static void register() {
        instance = new CinematicOverlayRenderer();
        HudRenderCallback.EVENT.register(instance);
    }
    
    public static CinematicOverlayRenderer getInstance() {
        return instance;
    }
    
    @Override
    public void onHudRender(class_332 graphics, class_9779 deltaTracker) {
        CinematicCameraController controller = CinematicCameraController.getInstance();
        
        if (!controller.isActive()) {
            return;
        }
        
        class_310 mc = class_310.method_1551();
        int screenWidth = mc.method_22683().method_4486();
        int screenHeight = mc.method_22683().method_4502();
        float partialTicks = deltaTracker.method_60637(true);
        
        // Update controller tick
        controller.tick(partialTicks);
        
        // Render fade effect (behind letterbox)
        renderFade(graphics, screenWidth, screenHeight, controller.getFadeProgress());
        
        // Render letterbox bars
        if (controller.isLetterboxEnabled()) {
            renderLetterbox(graphics, screenWidth, screenHeight, controller.getLetterboxProgress());
        }
        
        // Render skip prompt
        if (controller.isSkippable()) {
            renderSkipPrompt(graphics, mc.field_1772, screenWidth, screenHeight, controller.getLetterboxProgress());
        }
        
        // Render progress bar (optional, subtle)
        renderProgressBar(graphics, screenWidth, screenHeight, controller.getProgress(), controller.getLetterboxProgress());
    }
    
    /**
     * Render letterbox bars at top and bottom of screen.
     */
    private void renderLetterbox(class_332 graphics, int screenWidth, int screenHeight, float progress) {
        if (progress <= 0) return;
        
        int barHeight = (int) (screenHeight * LETTERBOX_HEIGHT_RATIO * progress);
        
        // Top bar
        graphics.method_25294(0, 0, screenWidth, barHeight, LETTERBOX_COLOR);
        
        // Bottom bar
        graphics.method_25294(0, screenHeight - barHeight, screenWidth, screenHeight, LETTERBOX_COLOR);
    }
    
    /**
     * Render screen fade effect.
     */
    private void renderFade(class_332 graphics, int screenWidth, int screenHeight, float progress) {
        if (progress <= 0) return;
        
        int alpha = (int) (progress * 255);
        int fadeColor = (alpha << 24) | FADE_COLOR_BASE;
        
        graphics.method_25294(0, 0, screenWidth, screenHeight, fadeColor);
    }
    
    /**
     * Render skip prompt in the letterbox area.
     */
    private void renderSkipPrompt(class_332 graphics, class_327 font, int screenWidth, int screenHeight, float letterboxProgress) {
        if (letterboxProgress < 0.5f) return; // Only show when letterbox is mostly visible
        
        // Pulse animation
        long time = System.currentTimeMillis();
        float pulse = 0.6f + 0.4f * (float) Math.sin(time / 500.0);
        int alpha = (int) (pulse * 170);
        int color = (alpha << 24) | 0xFFFFFF;
        
        int barHeight = (int) (screenHeight * LETTERBOX_HEIGHT_RATIO);
        int textWidth = font.method_1727(SKIP_PROMPT);
        int x = screenWidth - textWidth - 20;
        int y = screenHeight - barHeight / 2 - 4;
        
        graphics.method_51433(font, SKIP_PROMPT, x, y, color, false);
    }
    
    /**
     * Render a subtle progress bar at the bottom of the letterbox.
     */
    private void renderProgressBar(class_332 graphics, int screenWidth, int screenHeight, 
                                    float progress, float letterboxProgress) {
        if (letterboxProgress < 0.8f) return;
        
        int barHeight = (int) (screenHeight * LETTERBOX_HEIGHT_RATIO);
        int progressBarHeight = 2;
        int progressBarY = screenHeight - barHeight + 2;
        
        // Background
        int bgAlpha = (int) (100 * letterboxProgress);
        graphics.method_25294(0, progressBarY, screenWidth, progressBarY + progressBarHeight, 
            (bgAlpha << 24) | 0x333333);
        
        // Progress fill
        int fillWidth = (int) (screenWidth * progress);
        int fillAlpha = (int) (200 * letterboxProgress);
        graphics.method_25294(0, progressBarY, fillWidth, progressBarY + progressBarHeight, 
            (fillAlpha << 24) | 0xFFFFFF);
    }
}
