package com.warmpixel.storyadventure.client.render;

import com.warmpixel.storyadventure.core.waypoint.TriggerBox;
import com.warmpixel.storyadventure.item.ModItems;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Renders trigger box gizmos in the world.
 * Only visible when the player is holding the Admin Wand.
 */
public class TriggerBoxGizmoRenderer {
    
    private static TriggerBoxGizmoRenderer instance;
    private List<TriggerBox> triggerBoxes = new ArrayList<>();
    
    public static void register() {
        instance = new TriggerBoxGizmoRenderer();
        WorldRenderEvents.AFTER_TRANSLUCENT.register(instance::render);
    }
    
    public static TriggerBoxGizmoRenderer getInstance() {
        return instance;
    }
    
    private void render(WorldRenderContext context) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        
        // Only render if player is holding admin wand
        boolean holdingWand = mc.field_1724.method_6047().method_7909() == ModItems.ADMIN_WAND ||
                              mc.field_1724.method_6079().method_7909() == ModItems.ADMIN_WAND;
        
        if (!holdingWand || triggerBoxes.isEmpty()) return;
        
        class_243 cameraPos = context.camera().method_19326();
        class_4587 poseStack = context.matrixStack();
        class_4597 bufferSource = context.consumers();
        
        if (poseStack == null || bufferSource == null) return;
        
        poseStack.method_22903();
        poseStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);
        
        for (TriggerBox box : triggerBoxes) {
            if (box.getRadius() > 0) {
                renderSphere(poseStack, bufferSource, box);
            } else {
                renderBox(poseStack, bufferSource, box);
            }
        }
        
        poseStack.method_22909();
    }
    
    private void renderSphere(class_4587 poseStack, class_4597 bufferSource, TriggerBox box) {
        class_243 center = box.getCenter();
        double radius = box.getRadius();
        if (center == null) return;

        float r = 0.2f, g = 1.0f, b = 0.3f, a = 0.6f;
        if (!box.getPlayersInside().isEmpty()) {
            r = 1.0f; g = 0.8f; b = 0.0f;
        }

        class_4588 lineConsumer = bufferSource.getBuffer(class_1921.method_23594());
        Matrix4f matrix = poseStack.method_23760().method_23761();

        // Draw 3 primary circles to represent the sphere
        int segments = 24;
        for (int i = 0; i < segments; i++) {
            float angle1 = (float) i / segments * ((float) Math.PI * 2);
            float angle2 = (float) (i + 1) / segments * ((float) Math.PI * 2);

            float cos1 = (float) Math.cos(angle1) * (float) radius;
            float sin1 = (float) Math.sin(angle1) * (float) radius;
            float cos2 = (float) Math.cos(angle2) * (float) radius;
            float sin2 = (float) Math.sin(angle2) * (float) radius;

            // XY circle
            drawLine(lineConsumer, matrix, (float)center.field_1352 + cos1, (float)center.field_1351 + sin1, (float)center.field_1350, 
                     (float)center.field_1352 + cos2, (float)center.field_1351 + sin2, (float)center.field_1350, r, g, b, a);
            // XZ circle
            drawLine(lineConsumer, matrix, (float)center.field_1352 + cos1, (float)center.field_1351, (float)center.field_1350 + sin1, 
                     (float)center.field_1352 + cos2, (float)center.field_1351, (float)center.field_1350 + sin2, r, g, b, a);
            // YZ circle
            drawLine(lineConsumer, matrix, (float)center.field_1352, (float)center.field_1351 + cos1, (float)center.field_1350 + sin1, 
                     (float)center.field_1352, (float)center.field_1351 + cos2, (float)center.field_1350 + sin2, r, g, b, a);
        }
    }

    private void renderBox(class_4587 poseStack, class_4597 bufferSource, TriggerBox box) {
        class_238 bounds = box.getBounds();
        
        // Colors based on box state
        float r = 0.2f, g = 1.0f, b = 0.3f, a = 0.6f;
        if (!box.getPlayersInside().isEmpty()) {
            // Highlight when players inside
            r = 1.0f; g = 0.8f; b = 0.0f;
        }
        
        class_4588 lineConsumer = bufferSource.getBuffer(class_1921.method_23594());
        Matrix4f matrix = poseStack.method_23760().method_23761();
        
        float minX = (float) bounds.field_1323;
        float minY = (float) bounds.field_1322;
        float minZ = (float) bounds.field_1321;
        float maxX = (float) bounds.field_1320;
        float maxY = (float) bounds.field_1325;
        float maxZ = (float) bounds.field_1324;
        
        // Bottom face
        drawLine(lineConsumer, matrix, minX, minY, minZ, maxX, minY, minZ, r, g, b, a);
        drawLine(lineConsumer, matrix, maxX, minY, minZ, maxX, minY, maxZ, r, g, b, a);
        drawLine(lineConsumer, matrix, maxX, minY, maxZ, minX, minY, maxZ, r, g, b, a);
        drawLine(lineConsumer, matrix, minX, minY, maxZ, minX, minY, minZ, r, g, b, a);
        
        // Top face
        drawLine(lineConsumer, matrix, minX, maxY, minZ, maxX, maxY, minZ, r, g, b, a);
        drawLine(lineConsumer, matrix, maxX, maxY, minZ, maxX, maxY, maxZ, r, g, b, a);
        drawLine(lineConsumer, matrix, maxX, maxY, maxZ, minX, maxY, maxZ, r, g, b, a);
        drawLine(lineConsumer, matrix, minX, maxY, maxZ, minX, maxY, minZ, r, g, b, a);
        
        // Vertical edges
        drawLine(lineConsumer, matrix, minX, minY, minZ, minX, maxY, minZ, r, g, b, a);
        drawLine(lineConsumer, matrix, maxX, minY, minZ, maxX, maxY, minZ, r, g, b, a);
        drawLine(lineConsumer, matrix, maxX, minY, maxZ, maxX, maxY, maxZ, r, g, b, a);
        drawLine(lineConsumer, matrix, minX, minY, maxZ, minX, maxY, maxZ, r, g, b, a);
    }
    
    private void drawLine(class_4588 consumer, Matrix4f matrix,
                          float x1, float y1, float z1, float x2, float y2, float z2,
                          float r, float g, float b, float a) {
        // Calculate normal for line direction
        float nx = x2 - x1;
        float ny = y2 - y1;
        float nz = z2 - z1;
        float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (len > 0) {
            nx /= len;
            ny /= len;
            nz /= len;
        }
        
        consumer.method_22918(matrix, x1, y1, z1)
                .method_22915(r, g, b, a)
                .method_22914(nx, ny, nz);
        consumer.method_22918(matrix, x2, y2, z2)
                .method_22915(r, g, b, a)
                .method_22914(nx, ny, nz);
    }
    
    // Public API
    public void setTriggerBoxes(List<TriggerBox> boxes) {
        this.triggerBoxes = new ArrayList<>(boxes);
    }
    
    public void addTriggerBox(TriggerBox box) {
        triggerBoxes.add(box);
    }
    
    public void removeTriggerBox(String id) {
        triggerBoxes.removeIf(b -> b.getId().equals(id));
    }
    
    public void clear() {
        triggerBoxes.clear();
    }
}
