package com.warmpixel.storyadventure.client.ui;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import java.util.ArrayList;
import java.util.List;

/**
 * Victory screen displayed when a story instance is completed successfully.
 * Shows congratulations, rewards, and countdown to teleport back to spawn.
 */
public class StrangerVictoryScreen extends StrangerScreen {
    
    private static final int COLOR_GOLD = 0xFFFFD700;
    private static final int COLOR_SUCCESS = 0xFF44FF44;
    private static final int COUNTDOWN_SECONDS = 10;
    
    private final String storyName;
    private final long completionTimeMs;
    private final List<RewardEntry> rewards;
    private final long screenOpenTime;
    private int countdownSeconds;
    private long lastCountdownUpdate;
    private boolean confirmed = false;
    private Runnable onConfirm;
    
    public StrangerVictoryScreen(String storyName, long completionTimeMs, List<RewardEntry> rewards) {
        super(class_2561.method_43470("任务完成"));
        this.storyName = storyName;
        this.completionTimeMs = completionTimeMs;
        this.rewards = rewards != null ? rewards : new ArrayList<>();
        this.screenOpenTime = System.currentTimeMillis();
        this.countdownSeconds = COUNTDOWN_SECONDS;
        this.lastCountdownUpdate = System.currentTimeMillis();
    }
    
    public void setOnConfirm(Runnable onConfirm) {
        this.onConfirm = onConfirm;
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        int buttonWidth = 160;
        int buttonHeight = 30;
        int buttonX = (field_22789 - buttonWidth) / 2;
        int buttonY = field_22790 - 60;
        
        addStrangerButton(buttonX, buttonY, buttonWidth, buttonHeight,
            class_2561.method_43470("确认返回"), this::onConfirmClick);
    }
    
    @Override
    public void method_25393() {
        super.method_25393();
        
        if (confirmed) return;
        
        // Update countdown
        long now = System.currentTimeMillis();
        if (now - lastCountdownUpdate >= 1000) {
            lastCountdownUpdate = now;
            countdownSeconds--;
            
            if (countdownSeconds <= 0) {
                onConfirmClick();
            }
        }
    }
    
    private void onConfirmClick() {
        if (!confirmed) {
            confirmed = true;
            if (onConfirm != null) {
                onConfirm.run();
            }
            // Send confirm packet to server
            ClientPlayNetworking.send(
                new com.warmpixel.storyadventure.network.VictoryConfirmPayload()
            );
            
            // Close the screen
            this.method_25419();
        }
    }
    
    @Override
    protected void renderContent(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int centerX = field_22789 / 2;
        int y = 50;
        
        // Pulsing star effect
        float pulse = (float)(0.7 + 0.3 * Math.sin((System.currentTimeMillis() - screenOpenTime) / 300.0));
        int starAlpha = (int)(255 * pulse);
        int starColor = (starAlpha << 24) | (COLOR_GOLD & 0x00FFFFFF);
        
        // Draw congratulations header with stars
        String congrats = "★ 任务完成！ ★";
        int congratsWidth = field_22793.method_1727(congrats);
        graphics.method_25303(field_22793, congrats, centerX - congratsWidth / 2, y, starColor);
        y += 25;
        
        // Draw story name
        String storyText = storyName;
        int storyWidth = field_22793.method_1727(storyText);
        graphics.method_25303(field_22793, storyText, centerX - storyWidth / 2, y, COLOR_TEXT_TITLE);
        y += 15;
        
        // Draw separator
        int sepWidth = 180;
        graphics.method_25294(centerX - sepWidth / 2, y, centerX + sepWidth / 2, y + 1, COLOR_BORDER);
        y += 15;
        
        // Draw completion time
        String timeStr = formatTime(completionTimeMs);
        String timeLabel = "完成时间: " + timeStr;
        int timeWidth = field_22793.method_1727(timeLabel);
        graphics.method_25303(field_22793, timeLabel, centerX - timeWidth / 2, y, COLOR_TEXT_BODY);
        y += 25;
        
        // Draw rewards section
        if (!rewards.isEmpty()) {
            // Rewards box
            int boxWidth = 220;
            int boxHeight = 20 + rewards.size() * 18;
            int boxX = centerX - boxWidth / 2;
            int boxY = y;
            
            // Draw box background
            graphics.method_25294(boxX, boxY, boxX + boxWidth, boxY + boxHeight, 0xC0101010);
            
            // Draw box border
            graphics.method_25294(boxX, boxY, boxX + boxWidth, boxY + 1, COLOR_BORDER);
            graphics.method_25294(boxX, boxY + boxHeight - 1, boxX + boxWidth, boxY + boxHeight, COLOR_BORDER);
            graphics.method_25294(boxX, boxY, boxX + 1, boxY + boxHeight, COLOR_BORDER);
            graphics.method_25294(boxX + boxWidth - 1, boxY, boxX + boxWidth, boxY + boxHeight, COLOR_BORDER);
            
            // Draw rewards header
            String rewardsHeader = "— 奖励 —";
            int headerWidth = field_22793.method_1727(rewardsHeader);
            graphics.method_25303(field_22793, rewardsHeader, centerX - headerWidth / 2, boxY + 5, COLOR_GOLD);
            
            // Draw each reward
            int rewardY = boxY + 20;
            for (RewardEntry reward : rewards) {
                String rewardText = "◆ " + reward.description();
                graphics.method_25303(field_22793, rewardText, boxX + 15, rewardY, COLOR_SUCCESS);
                rewardY += 18;
            }
            
            y = boxY + boxHeight + 20;
        }
        
        // Draw countdown
        String countdownText = "(" + countdownSeconds + " 秒后自动返回)";
        int countdownWidth = field_22793.method_1727(countdownText);
        int countdownY = field_22790 - 35;
        
        // Flash when low
        int countdownColor = countdownSeconds <= 3 ? 
            (System.currentTimeMillis() % 500 < 250 ? 0xFFFF4444 : COLOR_TEXT_DIM) : 
            COLOR_TEXT_DIM;
        
        graphics.method_25303(field_22793, countdownText, centerX - countdownWidth / 2, countdownY, countdownColor);
    }
    
    private String formatTime(long ms) {
        long seconds = ms / 1000;
        long minutes = seconds / 60;
        seconds = seconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }
    
    @Override
    public boolean method_25422() {
        return false; // Prevent accidental closing
    }
    
    /**
     * Represents a reward to display.
     */
    public record RewardEntry(String type, String description, int amount) {
        public static RewardEntry experience(int amount) {
            return new RewardEntry("EXPERIENCE", amount + " 经验值", amount);
        }
        
        public static RewardEntry item(String itemName, int count) {
            String desc = count > 1 ? count + "x " + itemName : itemName;
            return new RewardEntry("ITEM", desc, count);
        }
    }
}
