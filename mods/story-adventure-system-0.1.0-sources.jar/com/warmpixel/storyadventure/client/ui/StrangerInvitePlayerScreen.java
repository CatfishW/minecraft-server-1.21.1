package com.warmpixel.storyadventure.client.ui;

import com.warmpixel.storyadventure.network.InvitePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;

/**
 * Small overlay to input a player's name for invitation.
 */
public class StrangerInvitePlayerScreen extends StrangerScreen {
    
    private class_342 nameInput;
    private final StrangerScreen parent;
    
    public StrangerInvitePlayerScreen(StrangerScreen parent) {
        super(class_2561.method_43470("邀请玩家"));
        this.parent = parent;
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        int boxWidth = 200;
        int boxHeight = 20;
        int x = field_22789 / 2 - boxWidth / 2;
        int y = field_22790 / 2 - 20;
        
        nameInput = new class_342(field_22793, x, y, boxWidth, boxHeight, class_2561.method_43470("玩家名称"));
        nameInput.method_1880(16);
        nameInput.method_25365(true);
        method_25429(nameInput);
        
        addStrangerButton(x, y + 30, 95, 20, class_2561.method_43470("发送邀请"), this::sendInvite);
        addStrangerButton(x + 105, y + 30, 95, 20, class_2561.method_43470("取消"), () -> field_22787.method_1507(parent));
    }
    
    private void sendInvite() {
        String name = nameInput.method_1882().trim();
        if (!name.isEmpty()) {
            ClientPlayNetworking.send(new InvitePayload(name, false, false));
            field_22787.method_1507(parent);
        }
    }
    
    @Override
    protected void renderContent(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        graphics.method_25300(field_22793, "输入玩家名称", field_22789 / 2, field_22790 / 2 - 40, 0xFFFFFFFF);
        nameInput.method_25394(graphics, mouseX, mouseY, partialTick);
    }
}
