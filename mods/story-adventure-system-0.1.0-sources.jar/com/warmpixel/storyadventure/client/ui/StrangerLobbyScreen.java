package com.warmpixel.storyadventure.client.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2561;
import net.minecraft.class_332;

/**
 * Stranger Things themed lobby screen for players to ready up before starting.
 * Shows party members, ready status, and allows configuration.
 */
public class StrangerLobbyScreen extends StrangerScreen {
    
    private static final int MEMBER_ENTRY_HEIGHT = 36;
    
    private String storyName;
    private String storyDescription;
    private int minPlayers;
    private int maxPlayers;
    private int estimatedMinutes;
    
    private List<PartyMember> members = new ArrayList<>();
    private boolean isLeader = false;
    private boolean isReady = false;
    private long countdownStartTime = 0;
    private boolean countdownActive = false;
    
    public StrangerLobbyScreen(String storyName, String storyDescription, 
                                int minPlayers, int maxPlayers, int estimatedMinutes) {
        super(class_2561.method_43470("准备大厅"));
        this.storyName = storyName;
        this.storyDescription = storyDescription;
        this.minPlayers = minPlayers;
        this.maxPlayers = maxPlayers;
        this.estimatedMinutes = estimatedMinutes;
    }
    
    public void setLeader(boolean leader) {
        this.isLeader = leader;
    }
    
    public void setReady(boolean ready) {
        this.isReady = ready;
    }
    
    public void addMember(UUID playerId, String name, boolean ready, boolean isLeader) {
        members.add(new PartyMember(playerId, name, ready, isLeader));
    }
    
    public void clearMembers() {
        members.clear();
    }
    
    public void updateMemberReady(UUID playerId, boolean ready) {
        for (PartyMember m : members) {
            if (m.id.equals(playerId)) {
                members.set(members.indexOf(m), new PartyMember(m.id, m.name, ready, m.isLeader));
                break;
            }
        }
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        int buttonWidth = 140;
        int buttonHeight = 28;
        int bottomY = field_22790 - 50;
        
        // Ready button (for everyone)
        String buttonText = isReady ? "取消准备" : (isLeader ? "准备开始" : "准备就绪");
        addStrangerButton(field_22789 / 2 - buttonWidth / 2, bottomY, buttonWidth, buttonHeight,
            class_2561.method_43470(buttonText),
            this::toggleReady);
            
        // Start button (for leader, only if enough people ready)
        if (isLeader) {
            long readyCount = members.stream().filter(m -> m.ready).count();
            boolean canStart = readyCount >= minPlayers;
            
            StrangerButton startBtn = addStrangerButton(field_22789 / 2 + buttonWidth / 2 + 10, bottomY, 120, buttonHeight,
                class_2561.method_43470("开始冒险"),
                this::startAdventure);
            startBtn.field_22763 = canStart;
            startBtn.setGlowPulse(canStart);
            
            // Invite button
            addStrangerButton(field_22789 / 2 - buttonWidth / 2 - 130, bottomY, 120, buttonHeight,
                class_2561.method_43470("邀请玩家"),
                () -> field_22787.method_1507(new StrangerInvitePlayerScreen(this)));
        }
        
        // Cancel/Leave button (bottom right)
        addStrangerButton(field_22789 - 100, bottomY, 80, buttonHeight,
            class_2561.method_43470(isLeader ? "解散" : "离开"),
            isLeader ? this::disbandParty : this::method_25419);
    }
    
    @Override
    protected void renderContent(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        // Story info panel (left side)
        renderStoryInfoPanel(graphics);
        
        // Party members panel (right side)
        renderPartyPanel(graphics, mouseX, mouseY);
        
        // Countdown overlay
        if (countdownActive) {
            renderCountdown(graphics);
        }
    }
    
    private void renderStoryInfoPanel(class_332 graphics) {
        int panelX = 30;
        int panelY = 50;
        int panelWidth = field_22789 / 2 - 50;
        int panelHeight = field_22790 - 130;
        
        // Background
        graphics.method_25294(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xE0080808);
        drawPanelBorder(graphics, panelX, panelY, panelWidth, panelHeight);
        
        int y = panelY + 10;
        
        // Story title
        graphics.method_25303(field_22793, "【" + storyName + "】", panelX + 15, y, COLOR_NEON_RED);
        y += 20;
        
        // Description (wrapped)
        List<String> descLines = wrapText(storyDescription, panelWidth - 30);
        for (String line : descLines) {
            graphics.method_25303(field_22793, line, panelX + 15, y, COLOR_TEXT_BODY);
            y += 11;
        }
        y += 10;
        
        // Separator
        graphics.method_25294(panelX + 15, y, panelX + panelWidth - 15, y + 1, COLOR_BORDER);
        y += 15;
        
        // Info items
        graphics.method_25303(field_22793, "👥 人数要求: " + minPlayers + "-" + maxPlayers + "人", panelX + 15, y, COLOR_TEXT_DIM);
        y += 14;
        graphics.method_25303(field_22793, "⏱ 预计时长: ~" + estimatedMinutes + "分钟", panelX + 15, y, COLOR_TEXT_DIM);
        y += 14;
        graphics.method_25303(field_22793, "⚠ 难度: ★★★☆☆", panelX + 15, y, COLOR_TEXT_DIM);
        
        // Tips at bottom
        y = panelY + panelHeight - 40;
        graphics.method_25294(panelX + 15, y, panelX + panelWidth - 15, y + 1, COLOR_BORDER);
        y += 8;
        graphics.method_25303(field_22793, "💡 提示: 建议携带武器和食物", panelX + 15, y, 0xFF888888);
    }
    
    private void renderPartyPanel(class_332 graphics, int mouseX, int mouseY) {
        int panelX = field_22789 / 2 + 10;
        int panelY = 50;
        int panelWidth = field_22789 / 2 - 40;
        int panelHeight = field_22790 - 130;
        
        // Background
        graphics.method_25294(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xE0080808);
        drawPanelBorder(graphics, panelX, panelY, panelWidth, panelHeight);
        
        // Panel title
        graphics.method_25303(field_22793, "队伍成员 (" + members.size() + "/" + maxPlayers + ")", 
            panelX + 15, panelY + 10, COLOR_NEON_RED);
        
        // Ready count
        long readyCount = members.stream().filter(m -> m.ready).count();
        String readyText = "准备: " + readyCount + "/" + members.size();
        int readyColor = readyCount == members.size() ? 0xFF44FF44 : COLOR_TEXT_DIM;
        graphics.method_25303(field_22793, readyText, panelX + panelWidth - field_22793.method_1727(readyText) - 15, 
            panelY + 10, readyColor);
        
        // Member entries
        int y = panelY + 30;
        for (PartyMember member : members) {
            renderMemberEntry(graphics, member, panelX + 10, y, panelWidth - 20, mouseX, mouseY);
            y += MEMBER_ENTRY_HEIGHT + 4;
        }
        
        // Empty slots
        for (int i = members.size(); i < maxPlayers; i++) {
            renderEmptySlot(graphics, panelX + 10, y, panelWidth - 20);
            y += MEMBER_ENTRY_HEIGHT + 4;
        }
    }
    
    private void renderMemberEntry(class_332 graphics, PartyMember member, 
                                    int x, int y, int width, int mouseX, int mouseY) {
        // Background
        int bgColor = member.ready ? 0xFF0A1A0A : 0xFF0A0A0A;
        graphics.method_25294(x, y, x + width, y + MEMBER_ENTRY_HEIGHT, bgColor);
        
        // Border
        int borderColor = member.ready ? 0xFF44FF44 : COLOR_BORDER;
        graphics.method_25294(x, y, x + width, y + 1, borderColor);
        graphics.method_25294(x, y + MEMBER_ENTRY_HEIGHT - 1, x + width, y + MEMBER_ENTRY_HEIGHT, borderColor);
        graphics.method_25294(x, y, x + 1, y + MEMBER_ENTRY_HEIGHT, borderColor);
        graphics.method_25294(x + width - 1, y, x + width, y + MEMBER_ENTRY_HEIGHT, borderColor);
        
        // Player icon (placeholder)
        graphics.method_25294(x + 8, y + 6, x + 30, y + 30, 0xFF333333);
        graphics.method_25303(field_22793, "👤", x + 11, y + 12, COLOR_TEXT_BODY);
        
        // Name
        int nameColor = member.isLeader ? COLOR_NEON_RED : COLOR_TEXT_BODY;
        String nameText = member.name + (member.isLeader ? " 👑" : "");
        graphics.method_25303(field_22793, nameText, x + 38, y + 8, nameColor);
        
        // Ready status
        String statusText = member.ready ? "✓ 已准备" : "○ 等待中...";
        int statusColor = member.ready ? 0xFF44FF44 : COLOR_TEXT_DIM;
        graphics.method_25303(field_22793, statusText, x + 38, y + 22, statusColor);
    }
    
    private void renderEmptySlot(class_332 graphics, int x, int y, int width) {
        // Dashed border style for empty slot
        graphics.method_25294(x, y, x + width, y + MEMBER_ENTRY_HEIGHT, 0x40080808);
        
        // Draw dashed border
        for (int i = 0; i < width; i += 8) {
            if ((i / 4) % 2 == 0) {
                graphics.method_25294(x + i, y, Math.min(x + i + 4, x + width), y + 1, COLOR_BORDER);
                graphics.method_25294(x + i, y + MEMBER_ENTRY_HEIGHT - 1, Math.min(x + i + 4, x + width), y + MEMBER_ENTRY_HEIGHT, COLOR_BORDER);
            }
        }
        
        graphics.method_25303(field_22793, "空位 - 等待加入...", x + width / 2 - 45, y + 14, COLOR_TEXT_DIM);
    }
    
    private int countdownSecondsLeft = -1;

    private void renderCountdown(class_332 graphics) {
        if (countdownSecondsLeft < 0) return;
        
        long elapsedSinceLastSync = System.currentTimeMillis() - countdownStartTime;
        // We pulse based on time, but use the seconds from server
        
        // Dark overlay
        graphics.method_25294(0, 0, field_22789, field_22790, 0xC0000000);
        
        // Countdown number
        String countText = String.valueOf(countdownSecondsLeft);
        
        // Pulsing effect
        float pulse = (float)(0.8 + 0.2 * Math.sin(System.currentTimeMillis() / 100.0));
        int alpha = (int)(255 * pulse);
        int color = (alpha << 24) | (COLOR_NEON_RED & 0x00FFFFFF);
        
        graphics.method_25300(field_22793, countText, field_22789 / 2, field_22790 / 2 - 30, color);
        graphics.method_25300(field_22793, "冒险即将开始...", field_22789 / 2, field_22790 / 2 + 20, COLOR_TEXT_BODY);
    }
    
    private void drawPanelBorder(class_332 graphics, int x, int y, int w, int h) {
        graphics.method_25294(x, y, x + w, y + 1, COLOR_BORDER);
        graphics.method_25294(x, y + h - 1, x + w, y + h, COLOR_BORDER);
        graphics.method_25294(x, y, x + 1, y + h, COLOR_BORDER);
        graphics.method_25294(x + w - 1, y, x + w, y + h, COLOR_BORDER);
        
        int cs = 10;
        graphics.method_25294(x, y, x + cs, y + 2, COLOR_NEON_RED);
        graphics.method_25294(x, y, x + 2, y + cs, COLOR_NEON_RED);
        graphics.method_25294(x + w - cs, y, x + w, y + 2, COLOR_NEON_RED);
        graphics.method_25294(x + w - 2, y, x + w, y + cs, COLOR_NEON_RED);
        graphics.method_25294(x, y + h - 2, x + cs, y + h, COLOR_NEON_RED);
        graphics.method_25294(x, y + h - cs, x + 2, y + h, COLOR_NEON_RED);
        graphics.method_25294(x + w - cs, y + h - 2, x + w, y + h, COLOR_NEON_RED);
        graphics.method_25294(x + w - 2, y + h - cs, x + w, y + h, COLOR_NEON_RED);
    }
    
    private List<String> wrapText(String text, int maxWidth) {
        List<String> lines = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            String test = current.toString() + c;
            
            if (field_22793.method_1727(test) <= maxWidth) {
                current.append(c);
            } else {
                if (!current.isEmpty()) lines.add(current.toString());
                current = new StringBuilder(String.valueOf(c));
            }
        }
        
        if (!current.isEmpty()) lines.add(current.toString());
        return lines;
    }
    
    private void toggleReady() {
        isReady = !isReady;
        // Send to server
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.send(
            new com.warmpixel.storyadventure.network.ToggleReadyPayload(isReady)
        );
        // Rebuild will happen when server sends SyncLobby back, 
        // but we can rebuild locally for immediate feedback
        rebuildButtons();
    }
    
    private void startAdventure() {
        // Check if enough players are ready
        long readyCount = members.stream().filter(m -> m.ready).count();
        if (readyCount >= minPlayers) {
            // Send start request
            net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.send(
                new com.warmpixel.storyadventure.network.StoryActionPayload(
                    com.warmpixel.storyadventure.network.StoryActionPayload.Action.START_ADVENTURE,
                    ""
                )
            );
        }
    }
    
    private void disbandParty() {
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.send(
            new com.warmpixel.storyadventure.network.StoryActionPayload(
                isLeader ? com.warmpixel.storyadventure.network.StoryActionPayload.Action.DISBAND_PARTY :
                           com.warmpixel.storyadventure.network.StoryActionPayload.Action.LEAVE_PARTY,
                ""
            )
        );
        method_25419();
    }
    
    public void rebuildButtons() {
        strangerButtons.clear();
        method_37067();
        method_25426();
    }
    
    public void startCountdown(int seconds) {
        this.countdownActive = seconds >= 0;
        this.countdownSecondsLeft = seconds;
        this.countdownStartTime = System.currentTimeMillis();
    }
    
    public record PartyMember(UUID id, String name, boolean ready, boolean isLeader) {}
}
