package com.warmpixel.storyadventure.client.ui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;

/**
 * Stranger Things themed dialogue screen for NPC conversations.
 * Features typewriter text effect, neon accents, and custom choice buttons.
 */
public class StrangerDialogueScreen extends StrangerScreen {
    
    private static final int PANEL_MARGIN = 40;
    private static final int DIALOGUE_BOX_HEIGHT = 120;
    private static final int CHOICE_BUTTON_HEIGHT = 24;
    private static final int CHOICE_BUTTON_MARGIN = 4;
    
    private String npcName;
    private String dialogueText;
    private List<DialogueChoice> choices = new ArrayList<>();
    
    // Typewriter effect
    private int displayedCharacters = 0;
    private long lastCharTime = 0;
    private static final long CHAR_DELAY_MS = 30;
    private boolean textComplete = false;
    
    public StrangerDialogueScreen(String npcName, String dialogueText) {
        super(class_2561.method_43470(npcName));
        this.npcName = npcName;
        this.dialogueText = dialogueText;
    }
    
    public void addChoice(String choiceId, String choiceText, Runnable onSelect) {
        choices.add(new DialogueChoice(choiceId, choiceText, () -> {
            // Send network packet
            net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.send(
                new com.warmpixel.storyadventure.network.DialogueChoicePayload(choiceId)
            );
            // Run custom callback (e.g. close screen)
            if (onSelect != null) onSelect.run();
        }));
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        // Initialize choice buttons (hidden until text complete)
        int choiceY = field_22790 - PANEL_MARGIN - DIALOGUE_BOX_HEIGHT + 50;
        int choiceWidth = field_22789 - PANEL_MARGIN * 4;
        
        for (int i = 0; i < choices.size(); i++) {
            DialogueChoice choice = choices.get(i);
            int y = choiceY + i * (CHOICE_BUTTON_HEIGHT + CHOICE_BUTTON_MARGIN);
            
            StrangerButton button = addStrangerButton(
                field_22789 / 2 - choiceWidth / 2,
                y,
                choiceWidth,
                CHOICE_BUTTON_HEIGHT,
                class_2561.method_43470(choice.text),
                choice.onSelect
            );
            button.field_22764 = false; // Hidden until text completes
            button.setGlowPulse(false);
        }
    }
    
    @Override
    protected void renderContent(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        // Update typewriter effect
        updateTypewriter();
        
        // Render dialogue box
        int boxX = PANEL_MARGIN;
        int boxY = field_22790 - PANEL_MARGIN - DIALOGUE_BOX_HEIGHT;
        int boxWidth = field_22789 - PANEL_MARGIN * 2;
        
        // Draw dialogue box background
        graphics.method_25294(boxX, boxY, boxX + boxWidth, boxY + DIALOGUE_BOX_HEIGHT, 0xE0080808);
        
        // Draw box border
        drawBoxBorder(graphics, boxX, boxY, boxWidth, DIALOGUE_BOX_HEIGHT);
        
        // Draw NPC name badge
        int nameWidth = field_22793.method_1727(npcName) + 16;
        graphics.method_25294(boxX + 10, boxY - 8, boxX + 10 + nameWidth, boxY + 4, 0xFF0A0A0A);
        graphics.method_25294(boxX + 10, boxY - 8, boxX + 10 + nameWidth, boxY - 6, COLOR_NEON_RED);
        graphics.method_25303(field_22793, npcName, boxX + 18, boxY - 6, COLOR_NEON_RED);
        
        // Draw dialogue text with typewriter effect
        String displayText = dialogueText.substring(0, Math.min(displayedCharacters, dialogueText.length()));
        drawWrappedText(graphics, displayText, boxX + 15, boxY + 12, boxWidth - 30, COLOR_TEXT_BODY);
        
        // Show blinking cursor if not complete
        if (!textComplete) {
            long blink = (System.currentTimeMillis() / 500) % 2;
            if (blink == 0) {
                String cursorText = displayText + "▌";
                int cursorX = boxX + 15 + field_22793.method_1727(getLastLine(displayText));
                int cursorY = boxY + 12 + getLineCount(displayText, boxWidth - 30) * 10;
                graphics.method_25303(field_22793, "▌", cursorX, cursorY, COLOR_NEON_RED);
            }
        }
        
        // Show/hide choice buttons based on text completion
        for (int i = 0; i < strangerButtons.size(); i++) {
            strangerButtons.get(i).field_22764 = textComplete;
        }
    }
    
    private void updateTypewriter() {
        if (displayedCharacters < dialogueText.length()) {
            long now = System.currentTimeMillis();
            if (now - lastCharTime >= CHAR_DELAY_MS) {
                displayedCharacters++;
                lastCharTime = now;
            }
        } else {
            textComplete = true;
        }
    }
    
    private void drawBoxBorder(class_332 graphics, int x, int y, int w, int h) {
        // Neon red border with corner accents
        graphics.method_25294(x, y, x + w, y + 1, COLOR_BORDER);
        graphics.method_25294(x, y + h - 1, x + w, y + h, COLOR_BORDER);
        graphics.method_25294(x, y, x + 1, y + h, COLOR_BORDER);
        graphics.method_25294(x + w - 1, y, x + w, y + h, COLOR_BORDER);
        
        // Corner highlights
        int cs = 8;
        graphics.method_25294(x, y, x + cs, y + 2, COLOR_NEON_RED);
        graphics.method_25294(x, y, x + 2, y + cs, COLOR_NEON_RED);
        graphics.method_25294(x + w - cs, y, x + w, y + 2, COLOR_NEON_RED);
        graphics.method_25294(x + w - 2, y, x + w, y + cs, COLOR_NEON_RED);
        graphics.method_25294(x, y + h - 2, x + cs, y + h, COLOR_NEON_RED);
        graphics.method_25294(x, y + h - cs, x + 2, y + h, COLOR_NEON_RED);
        graphics.method_25294(x + w - cs, y + h - 2, x + w, y + h, COLOR_NEON_RED);
        graphics.method_25294(x + w - 2, y + h - cs, x + w, y + h, COLOR_NEON_RED);
    }
    
    private void drawWrappedText(class_332 graphics, String text, int x, int y, int maxWidth, int color) {
        List<String> lines = wrapText(text, maxWidth);
        for (int i = 0; i < lines.size(); i++) {
            graphics.method_25303(field_22793, lines.get(i), x, y + i * 10, color);
        }
    }
    
    private List<String> wrapText(String text, int maxWidth) {
        List<String> lines = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            String test = current.toString() + c;
            
            if (field_22793.method_1727(test) <= maxWidth) {
                current.append(c);
            } else {
                if (!current.isEmpty()) lines.add(current.toString());
                current = new StringBuilder(String.valueOf(c));
            }
        }
        
        if (!current.isEmpty()) lines.add(current.toString());
        return lines;
    }
    
    private String getLastLine(String text) {
        int lastNewline = text.lastIndexOf('\n');
        return lastNewline >= 0 ? text.substring(lastNewline + 1) : text;
    }
    
    private int getLineCount(String text, int maxWidth) {
        return wrapText(text, maxWidth).size();
    }
    
    @Override
    public boolean method_25422() {
        return false;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        // Skip text on any key
        if (!textComplete) {
            displayedCharacters = dialogueText.length();
            textComplete = true;
            return true;
        }
        
        // Prevent closing on ESC by returning true without calling super
        if (keyCode == 256) { // GLFW_KEY_ESCAPE is 256
            return true;
        }
        
        return super.method_25404(keyCode, scanCode, modifiers);
    }
    
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        // Skip text on click
        if (!textComplete) {
            displayedCharacters = dialogueText.length();
            textComplete = true;
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }
    
    public record DialogueChoice(String id, String text, Runnable onSelect) {}
}
