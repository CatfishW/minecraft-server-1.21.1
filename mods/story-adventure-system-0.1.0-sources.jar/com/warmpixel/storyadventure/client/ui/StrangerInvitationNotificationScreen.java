package com.warmpixel.storyadventure.client.ui;

import com.warmpixel.storyadventure.network.InvitePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_332;

/**
 * Screen that pops up when you receive an invitation.
 */
public class StrangerInvitationNotificationScreen extends StrangerScreen {
    
    private final String inviterName;
    
    public StrangerInvitationNotificationScreen(String inviterName) {
        super(class_2561.method_43470("收到邀请"));
        this.inviterName = inviterName;
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        int x = field_22789 / 2;
        int y = field_22790 / 2;
        
        addStrangerButton(x - 105, y + 20, 100, 24, class_2561.method_43470("✔ 接受邀请"), this::accept);
        addStrangerButton(x + 5, y + 20, 100, 24, class_2561.method_43470("✕ 拒绝"), this::decline);
    }
    
    private void accept() {
        ClientPlayNetworking.send(new InvitePayload(inviterName, true, true));
        method_25419();
    }
    
    private void decline() {
        ClientPlayNetworking.send(new InvitePayload(inviterName, true, false));
        method_25419();
    }
    
    @Override
    protected void renderContent(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int rectW = 240;
        int rectH = 100;
        int rectX = field_22789 / 2 - rectW / 2;
        int rectY = field_22790 / 2 - rectH / 2;
        
        graphics.method_25294(rectX, rectY, rectX + rectW, rectY + rectH, 0xF0080808);
        drawPanelBorder(graphics, rectX, rectY, rectW, rectH);
        
        graphics.method_25300(field_22793, "队伍邀请", field_22789 / 2, rectY + 15, COLOR_NEON_RED);
        graphics.method_25300(field_22793, "玩家 " + inviterName + " 邀请你加入他的队伍", field_22789 / 2, rectY + 40, 0xFFFFFFFF);
    }
    
    private void drawPanelBorder(class_332 graphics, int x, int y, int w, int h) {
        graphics.method_25294(x, y, x + w, y + 1, COLOR_BORDER);
        graphics.method_25294(x, y + h - 1, x + w, y + h, COLOR_BORDER);
        graphics.method_25294(x, y, x + 1, y + h, COLOR_BORDER);
        graphics.method_25294(x + w - 1, y, x + w, y + h, COLOR_BORDER);
    }
}
