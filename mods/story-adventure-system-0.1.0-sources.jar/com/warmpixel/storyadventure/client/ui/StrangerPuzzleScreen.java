package com.warmpixel.storyadventure.client.ui;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;

/**
 * Stranger Things themed puzzle interaction screen.
 * Used for code locks, wiring puzzles, symbol matching, etc.
 */
public class StrangerPuzzleScreen extends StrangerScreen {
    
    private final String puzzleType;
    private final String hint;
    private final int maxAttempts;
    private int currentAttempts = 0;
    
    // Code lock state
    private StringBuilder codeInput = new StringBuilder();
    private int maxCodeLength = 4;
    
    public StrangerPuzzleScreen(String puzzleType, String hint, int maxAttempts) {
        super(class_2561.method_43470("解谜"));
        this.puzzleType = puzzleType;
        this.hint = hint;
        this.maxAttempts = maxAttempts;
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        if ("CODE_LOCK".equals(puzzleType)) {
            initCodeLockButtons();
        }
    }
    
    private void initCodeLockButtons() {
        int buttonSize = 40;
        int gap = 8;
        int startX = (field_22789 - (3 * buttonSize + 2 * gap)) / 2;
        int startY = field_22790 / 2 - 20;
        
        // Number pad 1-9
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                int num = row * 3 + col + 1;
                int x = startX + col * (buttonSize + gap);
                int y = startY + row * (buttonSize + gap);
                
                final int digit = num;
                addStrangerButton(x, y, buttonSize, buttonSize, 
                    class_2561.method_43470(String.valueOf(num)),
                    () -> appendDigit(digit));
            }
        }
        
        // 0 button
        int x = startX + (buttonSize + gap);
        int y = startY + 3 * (buttonSize + gap);
        addStrangerButton(x, y, buttonSize, buttonSize, 
            class_2561.method_43470("0"), () -> appendDigit(0));
        
        // Clear and Submit buttons
        addStrangerButton(startX, y, buttonSize, buttonSize, 
            class_2561.method_43470("×"), this::clearCode);
        addStrangerButton(startX + 2 * (buttonSize + gap), y, buttonSize, buttonSize, 
            class_2561.method_43470("✓"), this::submitCode);
    }
    
    private void appendDigit(int digit) {
        if (codeInput.length() < maxCodeLength) {
            codeInput.append(digit);
        }
    }
    
    private void clearCode() {
        codeInput.setLength(0);
    }
    
    private void submitCode() {
        currentAttempts++;
        String input = codeInput.toString();
        
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.send(
            new com.warmpixel.storyadventure.network.PuzzleInputPayload(input)
        );
        
        codeInput.setLength(0);
    }
    
    @Override
    protected void renderContent(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        // Draw puzzle title
        String titleText = getPuzzleTitle();
        int titleWidth = field_22793.method_1727(titleText);
        graphics.method_25303(field_22793, titleText, (field_22789 - titleWidth) / 2, 45, COLOR_TEXT_BODY);
        
        // Draw code display
        if ("CODE_LOCK".equals(puzzleType)) {
            renderCodeDisplay(graphics);
        }
        
        // Draw hint
        if (!hint.isEmpty()) {
            renderHint(graphics);
        }
        
        // Draw attempt counter
        String attemptsText = String.format("尝试次数: %d / %d", currentAttempts, maxAttempts);
        int attemptsColor = currentAttempts >= maxAttempts - 1 ? 0xFFFF4444 : COLOR_TEXT_DIM;
        graphics.method_25303(field_22793, attemptsText, field_22789 - field_22793.method_1727(attemptsText) - 20, field_22790 - 30, attemptsColor);
    }
    
    private void renderCodeDisplay(class_332 graphics) {
        int displayWidth = 150;
        int displayHeight = 36;
        int displayX = (field_22789 - displayWidth) / 2;
        int displayY = field_22790 / 2 - 80;
        
        // Background
        graphics.method_25294(displayX, displayY, displayX + displayWidth, displayY + displayHeight, 0xFF0A0A0A);
        
        // Border
        graphics.method_25294(displayX, displayY, displayX + displayWidth, displayY + 1, COLOR_NEON_RED);
        graphics.method_25294(displayX, displayY + displayHeight - 1, displayX + displayWidth, displayY + displayHeight, COLOR_NEON_RED);
        graphics.method_25294(displayX, displayY, displayX + 1, displayY + displayHeight, COLOR_NEON_RED);
        graphics.method_25294(displayX + displayWidth - 1, displayY, displayX + displayWidth, displayY + displayHeight, COLOR_NEON_RED);
        
        // Code display with asterisks
        StringBuilder display = new StringBuilder();
        for (int i = 0; i < maxCodeLength; i++) {
            if (i < codeInput.length()) {
                display.append("● ");
            } else {
                display.append("○ ");
            }
        }
        
        String displayText = display.toString().trim();
        int textWidth = field_22793.method_1727(displayText);
        graphics.method_25303(field_22793, displayText, displayX + (displayWidth - textWidth) / 2, displayY + 14, COLOR_NEON_RED);
    }
    
    private void renderHint(class_332 graphics) {
        int hintY = field_22790 - 60;
        String hintLabel = "💡 提示: ";
        graphics.method_25303(field_22793, hintLabel + hint, 20, hintY, COLOR_TEXT_DIM);
    }
    
    private String getPuzzleTitle() {
        return switch (puzzleType) {
            case "CODE_LOCK" -> "密码锁";
            case "WIRING" -> "接线谜题";
            case "SYMBOL_MATCH" -> "符号匹配";
            default -> "解谜";
        };
    }
    
    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        // Number keys 0-9
        if (keyCode >= 48 && keyCode <= 57) {
            appendDigit(keyCode - 48);
            return true;
        }
        // Numpad 0-9
        if (keyCode >= 320 && keyCode <= 329) {
            appendDigit(keyCode - 320);
            return true;
        }
        // Backspace
        if (keyCode == 259 && codeInput.length() > 0) {
            codeInput.deleteCharAt(codeInput.length() - 1);
            return true;
        }
        // Enter
        if (keyCode == 257) {
            submitCode();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }
}
