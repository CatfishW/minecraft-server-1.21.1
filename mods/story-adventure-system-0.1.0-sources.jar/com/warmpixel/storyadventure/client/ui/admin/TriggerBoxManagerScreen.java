package com.warmpixel.storyadventure.client.ui.admin;

import com.warmpixel.storyadventure.client.ui.StrangerScreen;
import com.warmpixel.storyadventure.core.waypoint.TriggerBox;
import com.warmpixel.storyadventure.item.AdminWandItem;
import com.warmpixel.storyadventure.network.AdminTriggerActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Admin UI for managing trigger boxes.
 * Shows list of boxes, allows editing properties and actions.
 */
public class TriggerBoxManagerScreen extends StrangerScreen {
    
    private static final int LIST_WIDTH = 220;
    private static final int ENTRY_HEIGHT = 24;
    
    private List<TriggerBoxEntry> boxes = new ArrayList<>();
    private int scrollOffset = 0;
    private TriggerBoxEntry selectedBox = null;
    
    // Edit fields
    private class_342 labelField;
    private class_342 linkedNodeField;
    private class_342 minXField, minYField, minZField;
    private class_342 maxXField, maxYField, maxZField;
    
    public TriggerBoxManagerScreen() {
        super(class_2561.method_43471("gui.storyadventure.admin.triggers.title"));
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        int rightPanelX = LIST_WIDTH + 30;
        int fieldWidth = 150;
        int fieldHeight = 20;
        int y = 60;
        
        // Label field
        labelField = new class_342(field_22793, rightPanelX + 80, y, fieldWidth, fieldHeight, class_2561.method_43471("gui.storyadventure.admin.triggers.label"));
        labelField.method_1880(64);
        method_37063(labelField);
        y += 28;
        
        // Linked node field  
        linkedNodeField = new class_342(field_22793, rightPanelX + 80, y, fieldWidth, fieldHeight, class_2561.method_43471("gui.storyadventure.admin.triggers.linked_node"));
        linkedNodeField.method_1880(64);
        method_37063(linkedNodeField);
        y += 40;
        
        // Coordinate fields
        int coordWidth = 60;
        minXField = new class_342(field_22793, rightPanelX + 40, y, coordWidth, fieldHeight, class_2561.method_43470("X"));
        minYField = new class_342(field_22793, rightPanelX + 110, y, coordWidth, fieldHeight, class_2561.method_43470("Y"));
        minZField = new class_342(field_22793, rightPanelX + 180, y, coordWidth, fieldHeight, class_2561.method_43470("Z"));
        method_37063(minXField);
        method_37063(minYField);
        method_37063(minZField);
        y += 28;
        
        maxXField = new class_342(field_22793, rightPanelX + 40, y, coordWidth, fieldHeight, class_2561.method_43470("X"));
        maxYField = new class_342(field_22793, rightPanelX + 110, y, coordWidth, fieldHeight, class_2561.method_43470("Y"));
        maxZField = new class_342(field_22793, rightPanelX + 180, y, coordWidth, fieldHeight, class_2561.method_43470("Z"));
        method_37063(maxXField);
        method_37063(maxYField);
        method_37063(maxZField);
        y += 40;
        
        // Action buttons
        int btnWidth = 100;
        int btnHeight = 24;
        
        addStrangerButton(rightPanelX, y, btnWidth, btnHeight, 
            class_2561.method_43471("gui.storyadventure.admin.triggers.save"), this::saveCurrentBox);
        addStrangerButton(rightPanelX + btnWidth + 10, y, btnWidth, btnHeight,
            class_2561.method_43471("gui.storyadventure.admin.triggers.delete"), this::deleteCurrentBox);
        y += 35;
        
        addStrangerButton(rightPanelX, y, btnWidth, btnHeight,
            class_2561.method_43471("gui.storyadventure.admin.triggers.teleport"), this::teleportToBox);
        addStrangerButton(rightPanelX + btnWidth + 10, y, btnWidth, btnHeight,
            class_2561.method_43471("gui.storyadventure.admin.triggers.add_action"), this::addAction);
        
        // Bottom toolbar
        int toolbarY = field_22790 - 45;
        addStrangerButton(20, toolbarY, 100, 28, class_2561.method_43471("gui.storyadventure.admin.triggers.refresh"), this::refreshList);
        addStrangerButton(130, toolbarY, 120, 28, class_2561.method_43471("gui.storyadventure.admin.triggers.new"), this::createNewBox);
        addStrangerButton(field_22789 - 110, toolbarY, 100, 28, class_2561.method_43471("gui.storyadventure.admin.triggers.back"), this::goBack);
        
        // Load boxes
        refreshList();
        
        // Check for pending box from wand creation
        checkPendingBox();
    }
    
    private void checkPendingBox() {
        if (field_22787 == null || field_22787.field_1724 == null) return;
        
        var pending = com.warmpixel.storyadventure.item.AdminWandItem.PendingTriggerBoxes.remove(field_22787.field_1724.method_5667());
        if (pending != null) {
            // Add the pending box to our list
            TriggerBox box = new TriggerBox(pending.id(), new class_238(pending.corner1(), pending.corner2()));
            box.setLabel(class_2561.method_43471("gui.storyadventure.admin.triggers.new_trigger").getString());
            boxes.add(new TriggerBoxEntry(box));
            selectBox(boxes.get(boxes.size() - 1));
            
            // Request server to save it
            requestSaveBox(box);
        }
    }
    
    @Override
    protected void renderContent(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        // Left panel - box list
        graphics.method_25294(15, 45, LIST_WIDTH + 15, field_22790 - 55, 0xE0080808);
        drawPanelBorder(graphics, 15, 45, LIST_WIDTH, field_22790 - 100);
        
        graphics.method_27535(field_22793, class_2561.method_43469("gui.storyadventure.admin.triggers.list_title", boxes.size()), 20, 50, COLOR_NEON_RED);
        graphics.method_25294(20, 64, LIST_WIDTH + 10, 65, COLOR_BORDER);
        
        // Render box entries
        int listY = 70;
        int visibleCount = (field_22790 - 130) / ENTRY_HEIGHT;
        int visibleEnd = Math.min(scrollOffset + visibleCount, boxes.size());
        
        for (int i = scrollOffset; i < visibleEnd; i++) {
            TriggerBoxEntry entry = boxes.get(i);
            boolean selected = entry == selectedBox;
            boolean hovered = mouseX >= 20 && mouseX < LIST_WIDTH + 10 && 
                              mouseY >= listY && mouseY < listY + ENTRY_HEIGHT - 2;
            
            int bgColor = selected ? 0xFF331111 : (hovered ? 0xFF1A0808 : 0x00000000);
            if (bgColor != 0) {
                graphics.method_25294(20, listY, LIST_WIDTH + 10, listY + ENTRY_HEIGHT - 2, bgColor);
            }
            
            String label = entry.box.getLabel();
            if (label.length() > 20) label = label.substring(0, 18) + "...";
            graphics.method_25303(field_22793, label, 25, listY + 4, selected ? COLOR_NEON_RED : COLOR_TEXT_BODY);
            graphics.method_25303(field_22793, entry.box.getId(), 25, listY + 13, COLOR_TEXT_DIM);
            
            listY += ENTRY_HEIGHT;
        }
        
        // Right panel - editor
        int rightX = LIST_WIDTH + 25;
        graphics.method_25294(rightX, 45, field_22789 - 15, field_22790 - 55, 0xE0080808);
        drawPanelBorder(graphics, rightX, 45, field_22789 - rightX - 15, field_22790 - 100);
        
        graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.triggers.properties"), rightX + 5, 50, COLOR_NEON_RED);
        graphics.method_25294(rightX + 5, 64, field_22789 - 20, 65, COLOR_BORDER);
        
        if (selectedBox != null) {
            int labelY = 65;
            graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.triggers.label"), rightX + 10, labelY, COLOR_TEXT_BODY);
            labelY += 28;
            graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.triggers.linked_node"), rightX + 10, labelY, COLOR_TEXT_BODY);
            labelY += 40;
            graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.triggers.min_pos"), rightX + 10, labelY, COLOR_TEXT_BODY);
            labelY += 28;
            graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.triggers.max_pos"), rightX + 10, labelY, COLOR_TEXT_BODY);
        } else {
            graphics.method_27534(field_22793, class_2561.method_43471("gui.storyadventure.admin.triggers.empty_selection"), (rightX + field_22789 - 15) / 2, field_22790 / 2, COLOR_TEXT_DIM);
        }
    }
    
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        // Check list clicks
        if (mouseX >= 20 && mouseX < LIST_WIDTH + 10 && mouseY >= 70) {
            int listY = 70;
            int visibleCount = (field_22790 - 130) / ENTRY_HEIGHT;
            int visibleEnd = Math.min(scrollOffset + visibleCount, boxes.size());
            
            for (int i = scrollOffset; i < visibleEnd; i++) {
                if (mouseY >= listY && mouseY < listY + ENTRY_HEIGHT - 2) {
                    selectBox(boxes.get(i));
                    return true;
                }
                listY += ENTRY_HEIGHT;
            }
        }
        
        return super.method_25402(mouseX, mouseY, button);
    }
    
    @Override
    public boolean method_25401(double mouseX, double mouseY, double hAmount, double vAmount) {
        if (mouseX < LIST_WIDTH + 15) {
            scrollOffset = Math.max(0, Math.min(boxes.size() - 5, scrollOffset - (int) vAmount));
            return true;
        }
        return super.method_25401(mouseX, mouseY, hAmount, vAmount);
    }
    
    private void selectBox(TriggerBoxEntry entry) {
        selectedBox = entry;
        if (entry != null) {
            TriggerBox box = entry.box;
            labelField.method_1852(box.getLabel());
            linkedNodeField.method_1852(box.getLinkedNodeId() != null ? box.getLinkedNodeId() : "");
            
            class_238 bounds = box.getBounds();
            minXField.method_1852(String.format("%.1f", bounds.field_1323));
            minYField.method_1852(String.format("%.1f", bounds.field_1322));
            minZField.method_1852(String.format("%.1f", bounds.field_1321));
            maxXField.method_1852(String.format("%.1f", bounds.field_1320));
            maxYField.method_1852(String.format("%.1f", bounds.field_1325));
            maxZField.method_1852(String.format("%.1f", bounds.field_1324));
        }
    }
    
    private void saveCurrentBox() {
        if (selectedBox == null) return;
        
        try {
            TriggerBox box = selectedBox.box;
            box.setLabel(labelField.method_1882());
            box.setLinkedNodeId(linkedNodeField.method_1882().isEmpty() ? null : linkedNodeField.method_1882());
            
            double minX = Double.parseDouble(minXField.method_1882());
            double minY = Double.parseDouble(minYField.method_1882());
            double minZ = Double.parseDouble(minZField.method_1882());
            double maxX = Double.parseDouble(maxXField.method_1882());
            double maxY = Double.parseDouble(maxYField.method_1882());
            double maxZ = Double.parseDouble(maxZField.method_1882());
            box.setBounds(new class_238(minX, minY, minZ, maxX, maxY, maxZ));
            
            requestSaveBox(box);
            showMessage(class_2561.method_43471("command.storyadventure.admin.triggers.saved").getString());
        } catch (NumberFormatException e) {
            showMessage(class_2561.method_43471("command.storyadventure.admin.triggers.error_pos").getString());
        }
    }
    
    private void deleteCurrentBox() {
        if (selectedBox == null) return;
        
        String id = selectedBox.box.getId();
        requestDeleteBox(id);
        boxes.remove(selectedBox);
        selectedBox = null;
        showMessage(class_2561.method_43471("command.storyadventure.admin.triggers.deleted").getString());
    }
    
    private void teleportToBox() {
        if (selectedBox == null || field_22787 == null || field_22787.field_1724 == null) return;
        
        class_238 bounds = selectedBox.box.getBounds();
        double x = (bounds.field_1323 + bounds.field_1320) / 2;
        double y = bounds.field_1322;
        double z = (bounds.field_1321 + bounds.field_1324) / 2;
        
        // Send teleport command
        if (field_22787.method_1562() != null) {
            field_22787.method_1562().method_45730(String.format("tp @s %.1f %.1f %.1f", x, y, z));
        }
    }
    
    private void addAction() {
        if (selectedBox == null) return;
        showMessage(class_2561.method_43471("command.storyadventure.admin.triggers.action_editor_dev").getString());
    }
    
    private void refreshList() {
        // Request box list from server
        requestBoxList();
    }
    
    private void createNewBox() {
        showMessage(class_2561.method_43471("command.storyadventure.admin.triggers.create_wand_hint").getString());
        goBack();
    }
    
    private void goBack() {
        class_310.method_1551().method_1507(new AdminDashboardScreen());
    }
    
    // Network request stubs - will be implemented
    private void requestBoxList() {
        if (field_22787 != null) {
            ClientPlayNetworking.send(new AdminTriggerActionPayload(
                AdminTriggerActionPayload.Action.LIST, "", "", 0, 0, 0, 0, 0, 0, ""
            ));
        }
    }
    
    private void requestSaveBox(TriggerBox box) {
        if (field_22787 != null) {
            var bounds = box.getBounds();
            ClientPlayNetworking.send(new AdminTriggerActionPayload(
                AdminTriggerActionPayload.Action.SAVE,
                box.getId(),
                box.getLabel(),
                bounds.field_1323, bounds.field_1322, bounds.field_1321,
                bounds.field_1320, bounds.field_1325, bounds.field_1324,
                box.getLinkedNodeId() != null ? box.getLinkedNodeId() : ""
            ));
        }
    }
    
    private void requestDeleteBox(String id) {
        if (field_22787 != null) {
            ClientPlayNetworking.send(new AdminTriggerActionPayload(
                AdminTriggerActionPayload.Action.DELETE, id, "", 0, 0, 0, 0, 0, 0, ""
            ));
        }
    }
    
    public void addBoxFromSync(String id, String label, double minX, double minY, double minZ, 
                                double maxX, double maxY, double maxZ) {
        TriggerBox box = new TriggerBox(id, new class_238(minX, minY, minZ, maxX, maxY, maxZ));
        box.setLabel(label);
        boxes.add(new TriggerBoxEntry(box));
    }
    
    public void clearBoxes() {
        boxes.clear();
        selectedBox = null;
    }
    
    private void showMessage(String message) {
        if (field_22787 != null && field_22787.field_1724 != null) {
            field_22787.field_1724.method_43496(class_2561.method_43470(message));
        }
    }
    
    private void drawPanelBorder(class_332 graphics, int x, int y, int w, int h) {
        graphics.method_25294(x, y, x + w, y + 1, COLOR_BORDER);
        graphics.method_25294(x, y + h - 1, x + w, y + h, COLOR_BORDER);
        graphics.method_25294(x, y, x + 1, y + h, COLOR_BORDER);
        graphics.method_25294(x + w - 1, y, x + w, y + h, COLOR_BORDER);
        
        int cs = 6;
        graphics.method_25294(x, y, x + cs, y + 2, COLOR_NEON_RED);
        graphics.method_25294(x, y, x + 2, y + cs, COLOR_NEON_RED);
        graphics.method_25294(x + w - cs, y, x + w, y + 2, COLOR_NEON_RED);
        graphics.method_25294(x + w - 2, y, x + w, y + cs, COLOR_NEON_RED);
    }
    
    private record TriggerBoxEntry(TriggerBox box) {}
}
