package com.warmpixel.storyadventure.client.ui.admin.graph;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.warmpixel.storyadventure.client.ui.StrangerScreen;
import com.warmpixel.storyadventure.client.ui.admin.AdminStoryManagerScreen;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Main visual story graph editor screen.
 * Provides visualization, editing, and JSON persistence for story nodes.
 */
public class StoryGraphScreen extends StrangerScreen {
    
    private static final int PROPERTY_PANEL_WIDTH = 280;
    
    private final String storyId;
    private final String storyName;
    private String entryNodeId;
    
    private GraphCanvas canvas;
    private NodePropertyPanel propertyPanel;
    
    // Story data
    private JsonObject storyJson;
    private Path storyFilePath;
    private boolean hasUnsavedChanges = false;
    
    public StoryGraphScreen(String storyId, String storyName) {
        super(class_2561.method_43470("故事图编辑器 - " + storyName));
        this.storyId = storyId;
        this.storyName = storyName;
    }
    
    private boolean isLoading = true;

    @Override
    protected void method_25426() {
        super.method_25426();
        
        // Initialize canvas
        int canvasWidth = field_22789 - PROPERTY_PANEL_WIDTH - 20;
        canvas = new GraphCanvas();
        canvas.setBounds(10, 50, canvasWidth, field_22790 - 100);
        
        // Initialize property panel
        propertyPanel = new NodePropertyPanel(this, canvasWidth + 20, 50, PROPERTY_PANEL_WIDTH - 10, field_22790 - 100);
        propertyPanel.init(this);
        
        // Toolbar buttons
        int toolbarX = 10;
        int toolbarY = field_22790 - 45;
        int btnWidth = 80;
        int btnHeight = 28;
        int gap = 5;
        
        addStrangerButton(toolbarX, toolbarY, btnWidth, btnHeight,
            class_2561.method_43470("💾 保存"), this::saveStory);
        toolbarX += btnWidth + gap;
        
        addStrangerButton(toolbarX, toolbarY, btnWidth, btnHeight,
            class_2561.method_43470("↺ 重载"), this::reloadStory);
        toolbarX += btnWidth + gap;
        
        addStrangerButton(toolbarX, toolbarY, btnWidth, btnHeight,
            class_2561.method_43470("📐 自动布局"), this::autoLayout);
        toolbarX += btnWidth + gap;
        
        addStrangerButton(toolbarX, toolbarY, btnWidth, btnHeight,
            class_2561.method_43470("🔍 居中"), this::centerView);
        toolbarX += btnWidth + gap;
        
        addStrangerButton(toolbarX, toolbarY, btnWidth, btnHeight,
            class_2561.method_43470("+ 新节点"), this::addNewNode);
        
        // Back button
        addStrangerButton(field_22789 - 100, toolbarY, 90, btnHeight,
            class_2561.method_43470("← 返回"), this::goBack);
        
        // Load story via network
        loadStory();
    }

    private void loadStory() {
        isLoading = true;
        showMessage("§e正在从服务器获取故事数据...");
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.send(
            new com.warmpixel.storyadventure.network.RequestStoryGraphPayload(storyId)
        );
    }
    
    public void onSyncReceived(String json) {
        try {
            JsonElement parsed = com.google.gson.JsonParser.parseString(json);
            if (parsed == null || !parsed.isJsonObject()) {
                showMessage("§c从服务器收到的故事格式错误");
                return;
            }
            
            storyJson = parsed.getAsJsonObject();
            entryNodeId = storyJson.has("entry_node") ? storyJson.get("entry_node").getAsString() : null;
            
            buildGraphFromJson();
            
            // Check if we need auto layout (only if no nodes have positions)
            boolean needLayout = canvas.getNodes().values().stream().allMatch(n -> n.getX() == 0 && n.getY() == 0);
            if (needLayout) {
                canvas.autoLayout(entryNodeId);
            } else {
                canvas.centerView();
            }
            
            isLoading = false;
            showMessage("§a同步成功: " + storyId);
        } catch (Exception e) {
            showMessage("§c处理服务器数据失败: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void buildGraphFromJson() {
        if (storyJson == null) return;
        canvas.clear();
        
        if (!storyJson.has("nodes")) return;
        
        JsonObject nodes = storyJson.getAsJsonObject("nodes");
        
        // First pass: create nodes
        for (Map.Entry<String, JsonElement> entry : nodes.entrySet()) {
            String nodeId = entry.getKey();
            JsonObject nodeData = entry.getValue().getAsJsonObject();
            
            String type = nodeData.has("type") ? nodeData.get("type").getAsString() : "UNKNOWN";
            
            // Check for saved position
            float x = 0, y = 0;
            if (nodeData.has("_editor")) {
                JsonObject editor = nodeData.getAsJsonObject("_editor");
                x = editor.has("x") ? editor.get("x").getAsFloat() : 0;
                y = editor.has("y") ? editor.get("y").getAsFloat() : 0;
            }
            
            GraphNode node = new GraphNode(nodeId, type, x, y);
            
            // Check for triggers
            node.setHasOnEnter(nodeData.has("on_enter") && nodeData.getAsJsonArray("on_enter").size() > 0);
            node.setHasOnExit(nodeData.has("on_exit") && nodeData.getAsJsonArray("on_exit").size() > 0);
            
            canvas.addNode(node);
        }
        
        // Second pass: create edges
        for (Map.Entry<String, JsonElement> entry : nodes.entrySet()) {
            String nodeId = entry.getKey();
            JsonObject nodeData = entry.getValue().getAsJsonObject();
            
            if (nodeData.has("edges")) {
                JsonArray edges = nodeData.getAsJsonArray("edges");
                for (JsonElement edgeElem : edges) {
                    JsonObject edgeData = edgeElem.getAsJsonObject();
                    String targetId = edgeData.get("target").getAsString();
                    
                    GraphEdge edge = new GraphEdge(nodeId, targetId);
                    
                    // Parse conditions
                    if (edgeData.has("conditions")) {
                        List<String> conditions = new ArrayList<>();
                        for (JsonElement cond : edgeData.getAsJsonArray("conditions")) {
                            JsonObject condObj = cond.getAsJsonObject();
                            conditions.add(condObj.get("type").getAsString());
                        }
                        edge.setConditions(conditions);
                    }
                    
                    canvas.addEdge(edge);
                }
            }
        }
    }
    
    @Override
    protected void renderContent(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        // Title bar with unsaved indicator
        String titleText = storyName + (hasUnsavedChanges ? " *" : "");
        graphics.method_25300(field_22793, titleText, field_22789 / 2, 8, 
            hasUnsavedChanges ? 0xFFFFCC44 : COLOR_NEON_RED);
        
        // Story info
        graphics.method_25303(field_22793, "ID: " + storyId, 15, 25, COLOR_TEXT_DIM);
        if (entryNodeId != null) {
            graphics.method_25303(field_22793, "入口: " + entryNodeId, 15, 38, COLOR_TEXT_DIM);
        }
        
        if (isLoading) {
            graphics.method_25300(field_22793, "§e请求数据中...", field_22789 / 2, field_22790 / 2, 0xFFFFFF00);
            return;
        }

        if (storyJson == null) {
            graphics.method_25300(field_22793, "§c故事数据同步失败", field_22789 / 2, field_22790 / 2, 0xFFFF5555);
            return;
        }
        
        // Canvas
        canvas.render(graphics, field_22793, mouseX, mouseY);
        
        // Property panel
        propertyPanel.render(graphics, field_22793, mouseX, mouseY, canvas.getSelectedNode());
    }
    
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (storyJson == null) return super.method_25402(mouseX, mouseY, button);
        
        // Property panel first
        if (propertyPanel.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        
        // Canvas
        boolean handled = canvas.mouseClicked(mouseX, mouseY, button);
        
        // Update property panel with selection
        if (canvas.getSelectedNode() != null) {
            propertyPanel.setNode(canvas.getSelectedNode(), getNodeJsonData(canvas.getSelectedNode().getNodeId()));
        } else {
            propertyPanel.setNode(null, null);
        }
        
        return handled || super.method_25402(mouseX, mouseY, button);
    }
    
    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (storyJson == null) return super.method_25403(mouseX, mouseY, button, dragX, dragY);
        if (canvas.mouseDragged(mouseX, mouseY, button, dragX, dragY)) {
            hasUnsavedChanges = true;
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }
    
    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (storyJson == null) return super.method_25406(mouseX, mouseY, button);
        canvas.mouseReleased(mouseX, mouseY, button);
        return super.method_25406(mouseX, mouseY, button);
    }
    
    @Override
    public boolean method_25401(double mouseX, double mouseY, double hAmount, double vAmount) {
        if (storyJson == null) return super.method_25401(mouseX, mouseY, hAmount, vAmount);
        if (canvas.mouseScrolled(mouseX, mouseY, vAmount)) {
            return true;
        }
        return super.method_25401(mouseX, mouseY, hAmount, vAmount);
    }
    
    @Override
    public void method_16014(double mouseX, double mouseY) {
        if (storyJson == null) return;
        canvas.mouseMoved(mouseX, mouseY);
    }
    
    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (storyJson == null) return super.method_25404(keyCode, scanCode, modifiers);
        if (propertyPanel.keyPressed(keyCode, scanCode, modifiers)) {
            return true;
        }
        
        // Ctrl+S to save
        if (keyCode == 83 && (modifiers & 2) != 0) { // S with Ctrl
            saveStory();
            return true;
        }
        
        // Delete key
        if (keyCode == 261 && canvas.getSelectedNode() != null) {
            deleteSelectedNode();
            return true;
        }
        
        return super.method_25404(keyCode, scanCode, modifiers);
    }
    
    @Override
    public boolean method_25400(char chr, int modifiers) {
        if (storyJson == null) return super.method_25400(chr, modifiers);
        if (propertyPanel.charTyped(chr, modifiers)) {
            return true;
        }
        return super.method_25400(chr, modifiers);
    }
    
    private JsonObject getNodeJsonData(String nodeId) {
        if (storyJson != null && storyJson.has("nodes")) {
            JsonObject nodes = storyJson.getAsJsonObject("nodes");
            if (nodes.has(nodeId)) {
                return nodes.getAsJsonObject(nodeId);
            }
        }
        return null;
    }
    
    public void onNodePropertyChanged(String nodeId, String key, String value) {
        if (storyJson == null) return;
        hasUnsavedChanges = true;
        
        // Update JSON
        if (storyJson.has("nodes")) {
            JsonObject nodes = storyJson.getAsJsonObject("nodes");
            if (nodes.has(nodeId)) {
                JsonObject nodeData = nodes.getAsJsonObject(nodeId);
                if (nodeData.has("data")) {
                    nodeData.getAsJsonObject("data").addProperty(key, value);
                }
            }
        }
    }

    private void saveStory() {
        if (storyJson == null) {
            showMessage("§c由于加载失败，无法保存。");
            return;
        }
        try {
            // Update node positions in JSON
            JsonObject nodes = storyJson.getAsJsonObject("nodes");
            for (GraphNode node : canvas.getNodes().values()) {
                if (nodes.has(node.getNodeId())) {
                    JsonObject nodeData = nodes.getAsJsonObject(node.getNodeId());
                    JsonObject editor = new JsonObject();
                    editor.addProperty("x", node.getX());
                    editor.addProperty("y", node.getY());
                    nodeData.add("_editor", editor);
                }
            }
            
            // Send to server
            com.google.gson.Gson gson = new com.google.gson.GsonBuilder().setPrettyPrinting().create();
            String jsonStr = gson.toJson(storyJson);
            
            showMessage("§e正在保存到服务器...");
            net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.send(
                new com.warmpixel.storyadventure.network.SaveStoryPayload(storyId, jsonStr)
            );
            
            hasUnsavedChanges = false;
        } catch (Exception e) {
            showMessage("§c保存失败: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void reloadStory() {
        if (hasUnsavedChanges) {
            showMessage("§e有未保存的更改，正在重新加载...");
        }
        loadStory();
        hasUnsavedChanges = false;
    }
    
    private void autoLayout() {
        if (storyJson == null) return;
        canvas.autoLayout(entryNodeId);
        hasUnsavedChanges = true;
        showMessage("§a自动布局完成");
    }
    
    private void centerView() {
        if (storyJson == null) return;
        canvas.centerView();
    }
    
    private void addNewNode() {
        if (storyJson == null) {
            showMessage("§c无法添加节点：故事数据未加载");
            return;
        }
        String newId = "new_node_" + System.currentTimeMillis() % 10000;
        
        // Add to JSON
        JsonObject nodes = storyJson.getAsJsonObject("nodes");
        JsonObject newNode = new JsonObject();
        newNode.addProperty("type", "CUTSCENE");
        newNode.add("data", new JsonObject());
        newNode.add("edges", new JsonArray());
        nodes.add(newId, newNode);
        
        // Add to canvas
        GraphNode node = new GraphNode(newId, "CUTSCENE", 100, 100);
        canvas.addNode(node);
        canvas.selectNode(node);
        
        propertyPanel.setNode(node, newNode);
        hasUnsavedChanges = true;
        
        showMessage("§a新节点已创建: " + newId);
    }
    
    private void deleteSelectedNode() {
        if (storyJson == null) return;
        GraphNode selected = canvas.getSelectedNode();
        if (selected == null) return;
        
        String nodeId = selected.getNodeId();
        
        // Remove from JSON
        if (storyJson.has("nodes")) {
            storyJson.getAsJsonObject("nodes").remove(nodeId);
        }
        
        // Rebuild graph
        buildGraphFromJson();
        propertyPanel.setNode(null, null);
        hasUnsavedChanges = true;
        
        showMessage("§c节点已删除: " + nodeId);
    }
    
    private void goBack() {
        if (hasUnsavedChanges) {
            showMessage("§e有未保存的更改");
        }
        class_310.method_1551().method_1507(new AdminStoryManagerScreen());
    }
    
    private void showMessage(String message) {
        var mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            mc.field_1724.method_43496(class_2561.method_43470(message));
        }
    }
}
