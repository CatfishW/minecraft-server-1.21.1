package com.warmpixel.storyadventure.client.ui.admin;

import com.warmpixel.storyadventure.client.ui.StrangerButton;
import com.warmpixel.storyadventure.client.ui.StrangerScreen;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Admin UI for managing players across all active story instances.
 */
public class AdminPlayerManagerScreen extends StrangerScreen {
    
    private static final int PLAYER_ENTRY_HEIGHT = 40;
    
    private final List<PlayerInfo> players = new ArrayList<>();
    private int selectedIndex = -1;
    private int scrollOffset = 0;
    
    public AdminPlayerManagerScreen() {
        super(class_2561.method_43471("gui.storyadventure.admin.players.title"));
    }
    
    public void addPlayer(UUID uuid, String name, String instanceName, String currentNode, boolean isLeader) {
        players.add(new PlayerInfo(uuid, name, instanceName, currentNode, isLeader));
    }
    
    public void clearPlayers() {
        players.clear();
        selectedIndex = -1;
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        int buttonWidth = 140;
        int buttonHeight = 24;
        int rightX = field_22789 - 170;
        int y = 80;
        
        // Teleport to player
        addStrangerButton(rightX, y, buttonWidth, buttonHeight,
            class_2561.method_43471("gui.storyadventure.admin.players.tp"), this::teleportToPlayer);
        y += buttonHeight + 8;
        
        // Kick from instance
        addStrangerButton(rightX, y, buttonWidth, buttonHeight,
            class_2561.method_43471("gui.storyadventure.admin.players.kick"), this::kickPlayer);
        y += buttonHeight + 8;
        
        // Send message
        addStrangerButton(rightX, y, buttonWidth, buttonHeight,
            class_2561.method_43471("gui.storyadventure.admin.players.message"), this::sendMessageToPlayer);
        y += buttonHeight + 8;
        
        // View player details
        addStrangerButton(rightX, y, buttonWidth, buttonHeight,
            class_2561.method_43471("gui.storyadventure.admin.players.details"), this::viewPlayerDetails);
        y += buttonHeight + 20;
        
        // Refresh button
        addStrangerButton(rightX, y, buttonWidth, buttonHeight,
            class_2561.method_43471("gui.storyadventure.admin.players.refresh"), this::refreshList);
        
        // Back button
        addStrangerButton(30, field_22790 - 45, 100, 28,
            class_2561.method_43471("gui.storyadventure.admin.players.back"), this::goBack);
        
        // Close button
        addStrangerButton(field_22789 / 2 - 60, field_22790 - 45, 120, 28,
            class_2561.method_43471("gui.storyadventure.admin.players.close"), this::method_25419);
        
        // Request player data
        refreshList();
    }
    
    @Override
    protected void renderContent(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        // Player list panel
        int listX = 30;
        int listY = 50;
        int listWidth = field_22789 - 230;
        int listHeight = field_22790 - 110;
        
        graphics.method_25294(listX, listY, listX + listWidth, listY + listHeight, 0xE0080808);
        drawPanelBorder(graphics, listX, listY, listWidth, listHeight);
        
        // Headers
        graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.players.col.player"), listX + 10, listY + 8, COLOR_NEON_RED);
        graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.players.col.instance"), listX + 150, listY + 8, COLOR_NEON_RED);
        graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.players.col.node"), listX + 320, listY + 8, COLOR_NEON_RED);
        graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.players.col.role"), listX + 450, listY + 8, COLOR_NEON_RED);
        
        graphics.method_25294(listX + 5, listY + 22, listX + listWidth - 5, listY + 23, COLOR_BORDER);
        
        // Player entries
        int y = listY + 28;
        int visibleCount = (listHeight - 30) / PLAYER_ENTRY_HEIGHT;
        int visibleEnd = Math.min(scrollOffset + visibleCount, players.size());
        
        for (int i = scrollOffset; i < visibleEnd; i++) {
            renderPlayerEntry(graphics, players.get(i), listX + 5, y, listWidth - 10, 
                i == selectedIndex, mouseX, mouseY);
            y += PLAYER_ENTRY_HEIGHT;
        }
        
        if (players.isEmpty()) {
            graphics.method_27534(field_22793, class_2561.method_43471("gui.storyadventure.admin.players.empty"), listX + listWidth / 2, listY + listHeight / 2, COLOR_TEXT_DIM);
        }
        
        // Sidebar details
        renderSidebar(graphics);
        
        // Stats bar
        renderStatsBar(graphics);
    }
    
    private void renderPlayerEntry(class_332 graphics, PlayerInfo info, 
                                    int x, int y, int width, boolean selected, int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + PLAYER_ENTRY_HEIGHT - 2;
        
        int bgColor = selected ? 0xFF1A0808 : (hovered ? 0xFF100505 : 0xFF0A0A0A);
        graphics.method_25294(x, y, x + width, y + PLAYER_ENTRY_HEIGHT - 2, bgColor);
        
        // Status indicator
        int statusColor = info.isLeader ? COLOR_NEON_RED : 0xFF44FF44;
        graphics.method_25294(x, y, x + 3, y + PLAYER_ENTRY_HEIGHT - 2, statusColor);
        
        // Player name
        graphics.method_25303(field_22793, info.name, x + 10, y + 10, COLOR_TEXT_BODY);
        
        // Instance name
        String instanceDisplay = info.instanceName.isEmpty() ? "-" : truncate(info.instanceName, 18);
        graphics.method_25303(field_22793, instanceDisplay, x + 150, y + 10, COLOR_TEXT_BODY);
        
        // Current node
        String nodeDisplay = info.currentNode.isEmpty() ? "-" : truncate(info.currentNode, 16);
        graphics.method_25303(field_22793, nodeDisplay, x + 320, y + 10, COLOR_TEXT_DIM);
        
        // Role
        String roleText = info.isLeader ? class_2561.method_43471("gui.storyadventure.admin.players.role.leader").getString() 
                                      : class_2561.method_43471("gui.storyadventure.admin.players.role.member").getString();
        graphics.method_25303(field_22793, roleText, x + 450, y + 10, info.isLeader ? COLOR_NEON_RED : COLOR_TEXT_DIM);
    }
    
    private void renderSidebar(class_332 graphics) {
        int sidebarX = field_22789 - 170;
        int sidebarY = 50;
        int sidebarWidth = 150;
        
        graphics.method_25294(sidebarX, sidebarY, sidebarX + sidebarWidth, sidebarY + 25, 0xE0080808);
        drawPanelBorder(graphics, sidebarX, sidebarY, sidebarWidth, 25);
        
        graphics.method_27534(field_22793, class_2561.method_43471("gui.storyadventure.admin.instances.actions"), sidebarX + sidebarWidth / 2, sidebarY + 8, COLOR_NEON_RED);
        
        // Selected player info
        if (selectedIndex >= 0 && selectedIndex < players.size()) {
            PlayerInfo info = players.get(selectedIndex);
            int infoY = 260;
            
            graphics.method_25294(sidebarX, infoY, sidebarX + sidebarWidth, infoY + 80, 0xE0080808);
            drawPanelBorder(graphics, sidebarX, infoY, sidebarWidth, 80);
            
            graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.instances.selected"), sidebarX + 5, infoY + 8, COLOR_TEXT_DIM);
            graphics.method_25303(field_22793, info.name, sidebarX + 5, infoY + 22, COLOR_TEXT_BODY);
            graphics.method_25303(field_22793, "UUID:", sidebarX + 5, infoY + 40, COLOR_TEXT_DIM);
            String shortUuid = info.uuid.toString().substring(0, 8);
            graphics.method_25303(field_22793, shortUuid, sidebarX + 5, infoY + 54, COLOR_TEXT_DIM);
        }
    }
    
    private void renderStatsBar(class_332 graphics) {
        int barY = field_22790 - 70;
        
        graphics.method_25294(30, barY, field_22789 - 30, barY + 20, 0xC0080808);
        
        int inInstanceCount = (int) players.stream().filter(p -> !p.instanceName.isEmpty()).count();
        class_2561 stats = class_2561.method_43469("gui.storyadventure.admin.players.stats",
            players.size(),
            inInstanceCount,
            players.stream().filter(p -> p.isLeader).count());
        
        graphics.method_27535(field_22793, stats, 40, barY + 6, COLOR_TEXT_DIM);
    }
    
    private void drawPanelBorder(class_332 graphics, int x, int y, int w, int h) {
        graphics.method_25294(x, y, x + w, y + 1, COLOR_BORDER);
        graphics.method_25294(x, y + h - 1, x + w, y + h, COLOR_BORDER);
        graphics.method_25294(x, y, x + 1, y + h, COLOR_BORDER);
        graphics.method_25294(x + w - 1, y, x + w, y + h, COLOR_BORDER);
        
        int cs = 6;
        graphics.method_25294(x, y, x + cs, y + 2, COLOR_NEON_RED);
        graphics.method_25294(x, y, x + 2, y + cs, COLOR_NEON_RED);
        graphics.method_25294(x + w - cs, y, x + w, y + 2, COLOR_NEON_RED);
        graphics.method_25294(x + w - 2, y, x + w, y + cs, COLOR_NEON_RED);
    }
    
    private String truncate(String text, int maxLen) {
        return text.length() > maxLen ? text.substring(0, maxLen - 2) + ".." : text;
    }
    
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        int listX = 30;
        int listY = 50;
        int listWidth = field_22789 - 230;
        int listHeight = field_22790 - 110;
        
        if (mouseX >= listX && mouseX < listX + listWidth && 
            mouseY >= listY + 28 && mouseY < listY + listHeight) {
            int relY = (int)mouseY - listY - 28;
            int clickedIndex = scrollOffset + relY / PLAYER_ENTRY_HEIGHT;
            if (clickedIndex < players.size()) {
                selectedIndex = clickedIndex;
                return true;
            }
        }
        
        return super.method_25402(mouseX, mouseY, button);
    }
    
    @Override
    public boolean method_25401(double mouseX, double mouseY, double hAmount, double vAmount) {
        int visibleCount = (field_22790 - 110 - 30) / PLAYER_ENTRY_HEIGHT;
        if (vAmount > 0 && scrollOffset > 0) {
            scrollOffset--;
            return true;
        } else if (vAmount < 0 && scrollOffset + visibleCount < players.size()) {
            scrollOffset++;
            return true;
        }
        return super.method_25401(mouseX, mouseY, hAmount, vAmount);
    }
    
    private void sendCommand(String command) {
        var mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            mc.field_1724.field_3944.method_45730(command.startsWith("/") ? command.substring(1) : command);
        }
    }
    
    private void showMessage(String message) {
        var mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            mc.field_1724.method_43496(class_2561.method_43470(message));
        }
    }
    
    private void teleportToPlayer() {
        if (selectedIndex >= 0 && selectedIndex < players.size()) {
            PlayerInfo info = players.get(selectedIndex);
            sendCommand("tp @s " + info.name);
            showMessage(class_2561.method_43469("command.storyadventure.admin.players.tping", info.name).getString());
            method_25419();
        } else {
            showMessage(class_2561.method_43471("command.storyadventure.admin.stories.select_first").getString());
        }
    }
    
    private void kickPlayer() {
        if (selectedIndex >= 0 && selectedIndex < players.size()) {
            PlayerInfo info = players.get(selectedIndex);
            sendCommand("storyadmin kick " + info.name);
            showMessage(class_2561.method_43469("command.storyadventure.admin.players.kicking", info.name).getString());
        } else {
            showMessage(class_2561.method_43471("command.storyadventure.admin.stories.select_first").getString());
        }
    }
    
    private void sendMessageToPlayer() {
        if (selectedIndex >= 0 && selectedIndex < players.size()) {
            PlayerInfo info = players.get(selectedIndex);
            showMessage(class_2561.method_43469("command.storyadventure.admin.players.msg_hint", info.name).getString());
        } else {
            showMessage(class_2561.method_43471("command.storyadventure.admin.stories.select_first").getString());
        }
    }
    
    private void viewPlayerDetails() {
        if (selectedIndex >= 0 && selectedIndex < players.size()) {
            PlayerInfo info = players.get(selectedIndex);
            showMessage(class_2561.method_43471("gui.storyadventure.admin.players.details_title").getString());
            showMessage(class_2561.method_43469("gui.storyadventure.admin.players.details_name", info.name).getString());
            showMessage(class_2561.method_43469("gui.storyadventure.admin.players.details_uuid", info.uuid).getString());
            showMessage(class_2561.method_43469("gui.storyadventure.admin.players.details_instance", (info.instanceName.isEmpty() ? class_2561.method_43471("gui.storyadventure.admin.players.none").getString() : info.instanceName)).getString());
            showMessage(class_2561.method_43469("gui.storyadventure.admin.players.details_node", (info.currentNode.isEmpty() ? class_2561.method_43471("gui.storyadventure.admin.players.none").getString() : info.currentNode)).getString());
            showMessage(class_2561.method_43469("gui.storyadventure.admin.players.details_role", (info.isLeader ? class_2561.method_43471("gui.storyadventure.admin.players.role.leader").getString() : class_2561.method_43471("gui.storyadventure.admin.players.role.member").getString())).getString());
        } else {
            showMessage(class_2561.method_43471("command.storyadventure.admin.stories.select_first").getString());
        }
    }
    
    private void refreshList() {
        sendCommand("storyadmin players");
        showMessage(class_2561.method_43471("command.storyadventure.admin.players.refreshing").getString());
    }
    
    private void goBack() {
        class_310.method_1551().method_1507(new AdminDashboardScreen());
    }
    
    public record PlayerInfo(UUID uuid, String name, String instanceName, String currentNode, boolean isLeader) {}
}
