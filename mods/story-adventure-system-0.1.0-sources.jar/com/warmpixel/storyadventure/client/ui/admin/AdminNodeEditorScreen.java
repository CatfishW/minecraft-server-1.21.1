package com.warmpixel.storyadventure.client.ui.admin;

import com.warmpixel.storyadventure.client.ui.StrangerButton;
import com.warmpixel.storyadventure.client.ui.StrangerScreen;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;

/**
 * Admin UI for editing individual node configuration.
 * Shows type-specific fields based on node type.
 */
public class AdminNodeEditorScreen extends StrangerScreen {
    
    private final String storyId;
    private final String nodeId;
    private final String nodeType;
    
    // Common fields
    private class_342 titleField;
    private class_342 descriptionField;
    
    // Type-specific fields (stored as key-value for simplicity)
    private final List<class_342> dataFields = new ArrayList<>();
    private final List<String> dataFieldLabels = new ArrayList<>();
    
    // Scrolling for fields
    private int scrollOffset = 0;
    
    public AdminNodeEditorScreen(String storyId, String nodeId, String nodeType) {
        super(class_2561.method_43469("gui.storyadventure.admin.nodes.edit_title", nodeId));
        this.storyId = storyId;
        this.nodeId = nodeId;
        this.nodeType = nodeType;
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        int fieldX = 60;
        int fieldWidth = field_22789 - 250;
        int y = 70;
        
        // Node type badge is rendered in renderContent
        
        // Initialize type-specific fields
        initTypeFields(fieldX, y, fieldWidth);
        
        // Action buttons on right side
        int buttonWidth = 140;
        int buttonHeight = 26;
        int rightX = field_22789 - 170;
        int buttonY = 80;
        
        // Save button
        addStrangerButton(rightX, buttonY, buttonWidth, buttonHeight,
            class_2561.method_43471("gui.storyadventure.admin.nodes.save"), this::saveChanges);
        buttonY += buttonHeight + 8;
        
        // Test trigger button
        addStrangerButton(rightX, buttonY, buttonWidth, buttonHeight,
            class_2561.method_43471("gui.storyadventure.admin.nodes.test_trigger"), this::testTrigger);
        buttonY += buttonHeight + 8;
        
        // Reset to default
        addStrangerButton(rightX, buttonY, buttonWidth, buttonHeight,
            class_2561.method_43471("gui.storyadventure.admin.nodes.reset"), this::resetToDefault);
        buttonY += buttonHeight + 20;
        
        // View JSON
        addStrangerButton(rightX, buttonY, buttonWidth, buttonHeight,
            class_2561.method_43471("gui.storyadventure.admin.nodes.view_json"), this::viewJson);
        
        // Navigation buttons
        addStrangerButton(30, field_22790 - 45, 100, 28,
            class_2561.method_43471("gui.storyadventure.admin.nodes.back"), this::goBack);
        
        addStrangerButton(field_22789 / 2 - 60, field_22790 - 45, 120, 28,
            class_2561.method_43471("gui.storyadventure.admin.nodes.cancel"), this::method_25419);
    }
    
    private void initTypeFields(int x, int y, int fieldWidth) {
        int fieldHeight = 20;
        int gap = 30;
        
        switch (nodeType.toUpperCase()) {
            case "CUTSCENE" -> {
                addDataField("duration_ticks", class_2561.method_43471("gui.storyadventure.admin.nodes.field.duration").getString(), "200", x, y, fieldWidth);
                y += gap;
                addDataField("title", class_2561.method_43471("gui.storyadventure.admin.nodes.field.title").getString(), "", x, y, fieldWidth);
                y += gap;
                addDataField("subtitle", class_2561.method_43471("gui.storyadventure.admin.nodes.field.subtitle").getString(), "", x, y, fieldWidth);
                y += gap;
                addDataField("message", class_2561.method_43471("gui.storyadventure.admin.nodes.field.message").getString(), "", x, y, fieldWidth);
                y += gap;
                addDataField("fade_in", class_2561.method_43471("gui.storyadventure.admin.nodes.field.fade_in").getString(), "true", x, y, fieldWidth);
            }
            case "DIALOGUE" -> {
                addDataField("npc_template", class_2561.method_43471("gui.storyadventure.admin.nodes.field.npc_template").getString(), "", x, y, fieldWidth);
                y += gap;
                addDataField("npc_name", class_2561.method_43471("gui.storyadventure.admin.nodes.field.npc_name").getString(), "", x, y, fieldWidth);
                y += gap;
                addDataField("dialog_set", class_2561.method_43471("gui.storyadventure.admin.nodes.field.dialog_set").getString(), "", x, y, fieldWidth);
                y += gap;
                addDataField("lines", class_2561.method_43471("gui.storyadventure.admin.nodes.field.lines").getString(), "", x, y, fieldWidth);
                y += gap;
                addDataField("vote_required", class_2561.method_43471("gui.storyadventure.admin.nodes.field.vote_required").getString(), "false", x, y, fieldWidth);
                y += gap;
                addDataField("vote_id", class_2561.method_43471("gui.storyadventure.admin.nodes.field.vote_id").getString(), "", x, y, fieldWidth);
            }
            case "TASK" -> {
                addDataField("task_type", class_2561.method_43471("gui.storyadventure.admin.nodes.field.task_type").getString(), "FETCH", x, y, fieldWidth);
                y += gap;
                addDataField("title", class_2561.method_43471("gui.storyadventure.admin.nodes.field.title").getString(), "", x, y, fieldWidth);
                y += gap;
                addDataField("description", class_2561.method_43471("gui.storyadventure.admin.nodes.field.description").getString(), "", x, y, fieldWidth);
                y += gap;
                addDataField("time_limit_seconds", class_2561.method_43471("gui.storyadventure.admin.nodes.field.time_limit").getString(), "0", x, y, fieldWidth);
                y += gap;
                addDataField("stealth_required", class_2561.method_43471("gui.storyadventure.admin.nodes.field.stealth").getString(), "false", x, y, fieldWidth);
            }
            case "PUZZLE" -> {
                addDataField("puzzle_type", class_2561.method_43471("gui.storyadventure.admin.nodes.field.puzzle_type").getString(), "CODE_LOCK", x, y, fieldWidth);
                y += gap;
                addDataField("title", class_2561.method_43471("gui.storyadventure.admin.nodes.field.title").getString(), "", x, y, fieldWidth);
                y += gap;
                addDataField("description", class_2561.method_43471("gui.storyadventure.admin.nodes.field.description").getString(), "", x, y, fieldWidth);
                y += gap;
                addDataField("solution", class_2561.method_43471("gui.storyadventure.admin.nodes.field.solution").getString(), "", x, y, fieldWidth);
                y += gap;
                addDataField("max_attempts", class_2561.method_43471("gui.storyadventure.admin.nodes.field.max_attempts").getString(), "5", x, y, fieldWidth);
                y += gap;
                addDataField("hints", class_2561.method_43471("gui.storyadventure.admin.nodes.field.hints").getString(), "", x, y, fieldWidth);
            }
            case "COMBAT" -> {
                addDataField("combat_type", class_2561.method_43471("gui.storyadventure.admin.nodes.field.combat_type").getString(), "BOSS", x, y, fieldWidth);
                y += gap;
                addDataField("title", class_2561.method_43471("gui.storyadventure.admin.nodes.field.title").getString(), "", x, y, fieldWidth);
                y += gap;
                addDataField("description", class_2561.method_43471("gui.storyadventure.admin.nodes.field.description").getString(), "", x, y, fieldWidth);
                y += gap;
                addDataField("enemies", class_2561.method_43471("gui.storyadventure.admin.nodes.field.enemies").getString(), "", x, y, fieldWidth);
                y += gap;
                addDataField("escape_available", class_2561.method_43471("gui.storyadventure.admin.nodes.field.escape_available").getString(), "false", x, y, fieldWidth);
                y += gap;
                addDataField("arena_radius", class_2561.method_43471("gui.storyadventure.admin.nodes.field.arena_radius").getString(), "20", x, y, fieldWidth);
            }
            case "CHECKPOINT" -> {
                addDataField("rewind_anchor", class_2561.method_43471("gui.storyadventure.admin.nodes.field.rewind_anchor").getString(), "true", x, y, fieldWidth);
                y += gap;
                addDataField("save_inventory", class_2561.method_43471("gui.storyadventure.admin.nodes.field.save_inventory").getString(), "true", x, y, fieldWidth);
                y += gap;
                addDataField("message", class_2561.method_43471("gui.storyadventure.admin.nodes.field.message").getString(), "", x, y, fieldWidth);
            }
            default -> {
                addDataField("data", class_2561.method_43471("gui.storyadventure.admin.nodes.field.generic_data").getString(), "{}", x, y, fieldWidth);
            }
        }
    }
    
    private void addDataField(String key, String label, String defaultValue, int x, int y, int fieldWidth) {
        class_342 field = new class_342(field_22793, x, y, fieldWidth, 18, class_2561.method_43470(label));
        field.method_1880(500);
        field.method_1852(defaultValue);
        field.method_1868(0xFFCCCCCC);
        method_37063(field);
        dataFields.add(field);
        dataFieldLabels.add(label);
    }
    
    @Override
    protected void renderContent(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        // Node info header
        int headerY = 48;
        
        // Type badge
        int typeColor = getTypeColor(nodeType);
        String typeDisplay = getTypeDisplayName(nodeType);
        int badgeWidth = field_22793.method_1727(typeDisplay) + 12;
        
        graphics.method_25294(30, headerY, 30 + badgeWidth, headerY + 18, typeColor & 0x60FFFFFF);
        graphics.method_25294(30, headerY, 32, headerY + 18, typeColor);
        graphics.method_25303(field_22793, typeDisplay, 36, headerY + 5, typeColor);
        
        // Node ID
        graphics.method_27535(field_22793, class_2561.method_43469("gui.storyadventure.admin.nodes.node_label", nodeId), 40 + badgeWidth, headerY + 5, COLOR_TEXT_BODY);
        
        // Story ID
        graphics.method_27535(field_22793, class_2561.method_43469("gui.storyadventure.admin.nodes.story_label", storyId), 40 + badgeWidth + field_22793.method_1727("Node: " + nodeId) + 20, headerY + 5, COLOR_TEXT_DIM);
        
        // Field labels
        int labelX = 30;
        int fieldY = 70;
        int gap = 30;
        
        for (int i = 0; i < dataFieldLabels.size(); i++) {
            graphics.method_25303(field_22793, dataFieldLabels.get(i), labelX, fieldY + 4, COLOR_TEXT_DIM);
            fieldY += gap;
        }
        
        // Sidebar info panel
        int sidebarX = field_22789 - 170;
        int sidebarY = 230;
        int sidebarWidth = 150;
        int sidebarHeight = 120;
        
        graphics.method_25294(sidebarX, sidebarY, sidebarX + sidebarWidth, sidebarY + sidebarHeight, 0xE0080808);
        drawPanelBorder(graphics, sidebarX, sidebarY, sidebarWidth, sidebarHeight);
        
        graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.nodes.info_title"), sidebarX + 10, sidebarY + 8, COLOR_NEON_RED);
        graphics.method_25294(sidebarX + 5, sidebarY + 20, sidebarX + sidebarWidth - 5, sidebarY + 21, COLOR_BORDER);
        
        graphics.method_27535(field_22793, class_2561.method_43469("gui.storyadventure.admin.nodes.info_type", typeDisplay), sidebarX + 10, sidebarY + 28, COLOR_TEXT_BODY);
        graphics.method_27535(field_22793, class_2561.method_43469("gui.storyadventure.admin.nodes.info_fields", dataFields.size()), sidebarX + 10, sidebarY + 44, COLOR_TEXT_DIM);
        
        // Help text
        graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.nodes.info_hint"), sidebarX + 10, sidebarY + 65, COLOR_NEON_RED);
        graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.nodes.info_hint1"), sidebarX + 10, sidebarY + 80, COLOR_TEXT_DIM);
        graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.nodes.info_hint2"), sidebarX + 10, sidebarY + 92, COLOR_TEXT_DIM);
    }
    
    private int getTypeColor(String type) {
        return switch (type.toUpperCase()) {
            case "DIALOGUE" -> 0xFF4488FF;
            case "TASK" -> 0xFF44FF44;
            case "PUZZLE" -> 0xFFFF8844;
            case "COMBAT" -> 0xFFFF4444;
            case "CUTSCENE" -> 0xFFCC44FF;
            case "CHECKPOINT" -> 0xFFFFCC44;
            default -> COLOR_TEXT_DIM;
        };
    }
    
    private String getTypeDisplayName(String type) {
        return switch (type.toUpperCase()) {
            case "DIALOGUE" -> class_2561.method_43471("gui.storyadventure.node.type.dialogue").getString();
            case "TASK" -> class_2561.method_43471("gui.storyadventure.node.type.task").getString();
            case "PUZZLE" -> class_2561.method_43471("gui.storyadventure.node.type.puzzle").getString();
            case "COMBAT" -> class_2561.method_43471("gui.storyadventure.node.type.combat").getString();
            case "CUTSCENE" -> class_2561.method_43471("gui.storyadventure.node.type.cutscene").getString();
            case "CHECKPOINT" -> class_2561.method_43471("gui.storyadventure.node.type.checkpoint").getString();
            default -> type;
        };
    }
    
    private void drawPanelBorder(class_332 graphics, int x, int y, int w, int h) {
        graphics.method_25294(x, y, x + w, y + 1, COLOR_BORDER);
        graphics.method_25294(x, y + h - 1, x + w, y + h, COLOR_BORDER);
        graphics.method_25294(x, y, x + 1, y + h, COLOR_BORDER);
        graphics.method_25294(x + w - 1, y, x + w, y + h, COLOR_BORDER);
        
        int cs = 6;
        graphics.method_25294(x, y, x + cs, y + 2, COLOR_NEON_RED);
        graphics.method_25294(x, y, x + 2, y + cs, COLOR_NEON_RED);
        graphics.method_25294(x + w - cs, y, x + w, y + 2, COLOR_NEON_RED);
        graphics.method_25294(x + w - 2, y, x + w, y + cs, COLOR_NEON_RED);
    }
    
    private void sendCommand(String command) {
        var mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            mc.field_1724.field_3944.method_45730(command.startsWith("/") ? command.substring(1) : command);
        }
    }
    
    private void showMessage(String message) {
        var mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            mc.field_1724.method_43496(class_2561.method_43470(message));
        }
    }
    
    private void saveChanges() {
        StringBuilder data = new StringBuilder();
        for (int i = 0; i < dataFields.size(); i++) {
            if (i > 0) data.append(",");
            data.append(dataFieldLabels.get(i)).append("=").append(dataFields.get(i).method_1882());
        }
        
        sendCommand("storyadmin updatenode " + storyId + " " + nodeId + " " + data);
        showMessage(class_2561.method_43471("command.storyadventure.admin.nodes.saved").getString());
        showMessage(class_2561.method_43471("command.storyadventure.admin.nodes.reload_hint").getString());
    }
    
    private void testTrigger() {
        sendCommand("storyadmin trigger " + storyId + " " + nodeId);
        showMessage(class_2561.method_43469("command.storyadventure.admin.nodes.testing", nodeId).getString());
    }
    
    private void resetToDefault() {
        for (class_342 field : dataFields) {
            field.method_1852("");
        }
        showMessage(class_2561.method_43471("command.storyadventure.admin.nodes.reset_done").getString());
    }
    
    private void viewJson() {
        showMessage(class_2561.method_43471("command.storyadventure.admin.nodes.json_title").getString());
        showMessage(class_2561.method_43469("gui.storyadventure.admin.nodes.node_label", nodeId).getString());
        showMessage(class_2561.method_43469("gui.storyadventure.admin.nodes.info_type", nodeType).getString());
        showMessage(class_2561.method_43471("command.storyadventure.admin.nodes.json_hint").getString());
        showMessage("config/storyadventure/stories/" + storyId + ".json");
    }
    
    private void goBack() {
        class_310.method_1551().method_1507(new AdminNodeListScreen(storyId, storyId));
    }
}
