package com.warmpixel.storyadventure.client.ui.admin;

import com.warmpixel.storyadventure.client.ui.StrangerButton;
import com.warmpixel.storyadventure.client.ui.StrangerScreen;
import com.warmpixel.storyadventure.core.graph.NodeType;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Admin UI for viewing and managing all nodes in a story.
 */
public class AdminNodeListScreen extends StrangerScreen {
    
    private static final int NODE_ENTRY_HEIGHT = 35;
    
    private final String storyId;
    private final String storyName;
    private final List<NodeInfo> nodes = new ArrayList<>();
    private int selectedIndex = -1;
    private int scrollOffset = 0;
    
    // Filter
    private String filterType = "ALL";
    
    public AdminNodeListScreen(String storyId, String storyName) {
        super(class_2561.method_43469("gui.storyadventure.admin.nodes.title", storyName));
        this.storyId = storyId;
        this.storyName = storyName;
    }
    
    public void addNode(String nodeId, String type, int edgeCount, String description) {
        nodes.add(new NodeInfo(nodeId, type, edgeCount, description));
    }
    
    public void clearNodes() {
        nodes.clear();
        selectedIndex = -1;
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        int buttonWidth = 140;
        int buttonHeight = 24;
        int rightX = field_22789 - 170;
        int y = 80;
        
        // Edit node button
        addStrangerButton(rightX, y, buttonWidth, buttonHeight,
            class_2561.method_43471("gui.storyadventure.admin.nodes.edit"), this::editNode);
        y += buttonHeight + 8;
        
        // Test trigger button
        addStrangerButton(rightX, y, buttonWidth, buttonHeight,
            class_2561.method_43471("gui.storyadventure.admin.nodes.trigger"), this::triggerNode);
        y += buttonHeight + 8;
        
        // View edges button
        addStrangerButton(rightX, y, buttonWidth, buttonHeight,
            class_2561.method_43471("gui.storyadventure.admin.nodes.edges"), this::viewEdges);
        y += buttonHeight + 20;
        
        // Filter buttons
        addStrangerButton(rightX, y, buttonWidth, buttonHeight,
            class_2561.method_43471("gui.storyadventure.admin.nodes.filter_all"), () -> setFilter("ALL"));
        y += buttonHeight + 5;
        addStrangerButton(rightX, y, buttonWidth / 2 - 2, buttonHeight,
            class_2561.method_43471("gui.storyadventure.node.type.dialogue"), () -> setFilter("DIALOGUE"));
        addStrangerButton(rightX + buttonWidth / 2 + 2, y, buttonWidth / 2 - 2, buttonHeight,
            class_2561.method_43471("gui.storyadventure.node.type.task"), () -> setFilter("TASK"));
        y += buttonHeight + 5;
        addStrangerButton(rightX, y, buttonWidth / 2 - 2, buttonHeight,
            class_2561.method_43471("gui.storyadventure.node.type.puzzle"), () -> setFilter("PUZZLE"));
        addStrangerButton(rightX + buttonWidth / 2 + 2, y, buttonWidth / 2 - 2, buttonHeight,
            class_2561.method_43471("gui.storyadventure.node.type.combat"), () -> setFilter("COMBAT"));
        y += buttonHeight + 5;
        addStrangerButton(rightX, y, buttonWidth / 2 - 2, buttonHeight,
            class_2561.method_43471("gui.storyadventure.node.type.cutscene"), () -> setFilter("CUTSCENE"));
        addStrangerButton(rightX + buttonWidth / 2 + 2, y, buttonWidth / 2 - 2, buttonHeight,
            class_2561.method_43471("gui.storyadventure.node.type.checkpoint"), () -> setFilter("CHECKPOINT"));
        
        // Back button
        addStrangerButton(30, field_22790 - 45, 100, 28,
            class_2561.method_43471("gui.storyadventure.admin.nodes.back"), this::goBack);
        
        // Close button
        addStrangerButton(field_22789 / 2 - 60, field_22790 - 45, 120, 28,
            class_2561.method_43471("gui.storyadventure.admin.nodes.close"), this::method_25419);
        
        // Load nodes
        loadNodes();
    }
    
    @Override
    protected void renderContent(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        // Node list panel
        int listX = 30;
        int listY = 50;
        int listWidth = field_22789 - 230;
        int listHeight = field_22790 - 110;
        
        graphics.method_25294(listX, listY, listX + listWidth, listY + listHeight, 0xE0080808);
        drawPanelBorder(graphics, listX, listY, listWidth, listHeight);
        
        // Headers
        graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.nodes.col.id"), listX + 10, listY + 8, COLOR_NEON_RED);
        graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.nodes.col.type"), listX + 200, listY + 8, COLOR_NEON_RED);
        graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.nodes.col.edges"), listX + 300, listY + 8, COLOR_NEON_RED);
        graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.nodes.col.desc"), listX + 360, listY + 8, COLOR_NEON_RED);
        
        graphics.method_25294(listX + 5, listY + 22, listX + listWidth - 5, listY + 23, COLOR_BORDER);
        
        // Filtered nodes
        List<NodeInfo> filteredNodes = getFilteredNodes();
        
        // Node entries
        int y = listY + 28;
        int visibleCount = (listHeight - 30) / NODE_ENTRY_HEIGHT;
        int visibleEnd = Math.min(scrollOffset + visibleCount, filteredNodes.size());
        
        for (int i = scrollOffset; i < visibleEnd; i++) {
            renderNodeEntry(graphics, filteredNodes.get(i), listX + 5, y, listWidth - 10, 
                i == selectedIndex, mouseX, mouseY);
            y += NODE_ENTRY_HEIGHT;
        }
        
        if (filteredNodes.isEmpty()) {
            class_2561 emptyMsg = filterType.equals("ALL") ? 
                class_2561.method_43471("gui.storyadventure.admin.nodes.empty") : 
                class_2561.method_43469("gui.storyadventure.admin.nodes.empty_filtered", getTypeDisplayName(filterType));
            graphics.method_27534(field_22793, emptyMsg, listX + listWidth / 2, listY + listHeight / 2, COLOR_TEXT_DIM);
        }
        
        // Stats bar
        graphics.method_25294(30, field_22790 - 70, field_22789 - 30, field_22790 - 50, 0xC0080808);
        class_2561 stats = class_2561.method_43469("gui.storyadventure.admin.nodes.stats",
            storyId, nodes.size(), filteredNodes.size(), getTypeDisplayName(filterType));
        graphics.method_27535(field_22793, stats, 40, field_22790 - 64, COLOR_TEXT_DIM);
    }
    
    private void renderNodeEntry(class_332 graphics, NodeInfo info, 
                                  int x, int y, int width, boolean selected, int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + NODE_ENTRY_HEIGHT - 2;
        
        int bgColor = selected ? 0xFF1A0808 : (hovered ? 0xFF100505 : 0xFF0A0A0A);
        graphics.method_25294(x, y, x + width, y + NODE_ENTRY_HEIGHT - 2, bgColor);
        
        // Type color indicator
        int typeColor = getTypeColor(info.type);
        graphics.method_25294(x, y, x + 3, y + NODE_ENTRY_HEIGHT - 2, typeColor);
        
        // Node ID
        graphics.method_25303(field_22793, truncate(info.nodeId, 24), x + 10, y + 10, COLOR_TEXT_BODY);
        
        // Type badge
        String typeDisplay = getTypeDisplayName(info.type);
        graphics.method_25294(x + 195, y + 6, x + 195 + field_22793.method_1727(typeDisplay) + 10, y + 20, typeColor & 0x40FFFFFF);
        graphics.method_25303(field_22793, typeDisplay, x + 200, y + 10, typeColor);
        
        // Edge count
        graphics.method_25303(field_22793, String.valueOf(info.edgeCount), x + 310, y + 10, COLOR_TEXT_DIM);
        
        // Description
        graphics.method_25303(field_22793, truncate(info.description, 30), x + 360, y + 10, COLOR_TEXT_DIM);
    }
    
    private List<NodeInfo> getFilteredNodes() {
        if (filterType.equals("ALL")) {
            return nodes;
        }
        return nodes.stream()
            .filter(n -> n.type.equalsIgnoreCase(filterType))
            .toList();
    }
    
    private void setFilter(String type) {
        this.filterType = type;
        this.selectedIndex = -1;
        this.scrollOffset = 0;
    }
    
    private int getTypeColor(String type) {
        return switch (type.toUpperCase()) {
            case "DIALOGUE" -> 0xFF4488FF;  // Blue
            case "TASK" -> 0xFF44FF44;      // Green
            case "PUZZLE" -> 0xFFFF8844;    // Orange
            case "COMBAT" -> 0xFFFF4444;    // Red
            case "CUTSCENE" -> 0xFFCC44FF;  // Purple
            case "CHECKPOINT" -> 0xFFFFCC44; // Yellow
            default -> COLOR_TEXT_DIM;
        };
    }
    
    private String getTypeDisplayName(String type) {
        return switch (type.toUpperCase()) {
            case "ALL" -> class_2561.method_43471("gui.storyadventure.admin.nodes.filter.all").getString();
            case "DIALOGUE" -> class_2561.method_43471("gui.storyadventure.node.type.dialogue").getString();
            case "TASK" -> class_2561.method_43471("gui.storyadventure.node.type.task").getString();
            case "PUZZLE" -> class_2561.method_43471("gui.storyadventure.node.type.puzzle").getString();
            case "COMBAT" -> class_2561.method_43471("gui.storyadventure.node.type.combat").getString();
            case "CUTSCENE" -> class_2561.method_43471("gui.storyadventure.node.type.cutscene").getString();
            case "CHECKPOINT" -> class_2561.method_43471("gui.storyadventure.node.type.checkpoint").getString();
            default -> type;
        };
    }
    
    private void drawPanelBorder(class_332 graphics, int x, int y, int w, int h) {
        graphics.method_25294(x, y, x + w, y + 1, COLOR_BORDER);
        graphics.method_25294(x, y + h - 1, x + w, y + h, COLOR_BORDER);
        graphics.method_25294(x, y, x + 1, y + h, COLOR_BORDER);
        graphics.method_25294(x + w - 1, y, x + w, y + h, COLOR_BORDER);
        
        int cs = 6;
        graphics.method_25294(x, y, x + cs, y + 2, COLOR_NEON_RED);
        graphics.method_25294(x, y, x + 2, y + cs, COLOR_NEON_RED);
        graphics.method_25294(x + w - cs, y, x + w, y + 2, COLOR_NEON_RED);
        graphics.method_25294(x + w - 2, y, x + w, y + cs, COLOR_NEON_RED);
    }
    
    private String truncate(String text, int maxLen) {
        return text.length() > maxLen ? text.substring(0, maxLen - 2) + ".." : text;
    }
    
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        int listX = 30;
        int listY = 50;
        int listWidth = field_22789 - 230;
        int listHeight = field_22790 - 110;
        
        if (mouseX >= listX && mouseX < listX + listWidth && 
            mouseY >= listY + 28 && mouseY < listY + listHeight) {
            List<NodeInfo> filtered = getFilteredNodes();
            int relY = (int)mouseY - listY - 28;
            int clickedIndex = scrollOffset + relY / NODE_ENTRY_HEIGHT;
            if (clickedIndex < filtered.size()) {
                selectedIndex = clickedIndex;
                return true;
            }
        }
        
        return super.method_25402(mouseX, mouseY, button);
    }
    
    @Override
    public boolean method_25401(double mouseX, double mouseY, double hAmount, double vAmount) {
        List<NodeInfo> filtered = getFilteredNodes();
        int visibleCount = (field_22790 - 110 - 30) / NODE_ENTRY_HEIGHT;
        if (vAmount > 0 && scrollOffset > 0) {
            scrollOffset--;
            return true;
        } else if (vAmount < 0 && scrollOffset + visibleCount < filtered.size()) {
            scrollOffset++;
            return true;
        }
        return super.method_25401(mouseX, mouseY, hAmount, vAmount);
    }
    
    private void sendCommand(String command) {
        var mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            mc.field_1724.field_3944.method_45730(command.startsWith("/") ? command.substring(1) : command);
        }
    }
    
    private void showMessage(String message) {
        var mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            mc.field_1724.method_43496(class_2561.method_43470(message));
        }
    }
    
    private void showTranslatable(String key, Object... args) {
        var mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            mc.field_1724.method_43496(class_2561.method_43469(key, args));
        }
    }
    
    private void loadNodes() {
        // Request nodes from server
        sendCommand("storyadmin nodes " + storyId);
        
        // For now, load some placeholder data based on story
        // In real implementation, this would come from network sync
        clearNodes();
        
        // Placeholder nodes for demonstration
        addNode("intro_cutscene", "CUTSCENE", 1, "开场过场动画");
        addNode("meet_joyce", "DIALOGUE", 2, "遇见乔伊斯");
        addNode("accept_mission", "CHECKPOINT", 1, "接受任务存档点");
        addNode("investigate_house", "TASK", 2, "调查房屋任务");
        addNode("find_first_clue", "CUTSCENE", 1, "发现线索");
        addNode("first_demogorgon_encounter", "COMBAT", 3, "第一次遭遇战斗");
        addNode("lab_puzzle", "PUZZLE", 2, "实验室密码谜题");
        addNode("gather_supplies", "TASK", 1, "收集物资");
        addNode("final_battle_prep", "CHECKPOINT", 1, "最终战斗准备");
        addNode("final_battle_vote", "DIALOGUE", 2, "投票选择策略");
        addNode("final_battle_direct", "COMBAT", 2, "正面突击战斗");
        addNode("good_ending", "CUTSCENE", 0, "好结局");
        addNode("bad_ending_defeated", "CUTSCENE", 0, "坏结局-失败");
    }
    
    private void editNode() {
        List<NodeInfo> filtered = getFilteredNodes();
        if (selectedIndex >= 0 && selectedIndex < filtered.size()) {
            NodeInfo info = filtered.get(selectedIndex);
            class_310.method_1551().method_1507(new AdminNodeEditorScreen(storyId, info.nodeId, info.type));
        } else {
            showTranslatable("command.storyadventure.admin.stories.select_first");
        }
    }
    
    private void triggerNode() {
        List<NodeInfo> filtered = getFilteredNodes();
        if (selectedIndex >= 0 && selectedIndex < filtered.size()) {
            NodeInfo info = filtered.get(selectedIndex);
            sendCommand("storyadmin trigger " + storyId + " " + info.nodeId);
            showTranslatable("command.storyadventure.admin.nodes.triggering", info.nodeId);
        } else {
            showTranslatable("command.storyadventure.admin.stories.select_first");
        }
    }
    
    private void viewEdges() {
        List<NodeInfo> filtered = getFilteredNodes();
        if (selectedIndex >= 0 && selectedIndex < filtered.size()) {
            NodeInfo info = filtered.get(selectedIndex);
            showTranslatable("gui.storyadventure.admin.nodes.edges_title", info.nodeId);
            showTranslatable("gui.storyadventure.admin.nodes.edges_count", info.edgeCount);
            showTranslatable("gui.storyadventure.admin.nodes.edges_hint");
        } else {
            showTranslatable("command.storyadventure.admin.stories.select_first");
        }
    }
    
    private void goBack() {
        AdminStoryManagerScreen screen = new AdminStoryManagerScreen();
        screen.addStory(storyId, storyName, nodes.size(), "1.0.0", true, "");
        class_310.method_1551().method_1507(screen);
    }
    
    public record NodeInfo(String nodeId, String type, int edgeCount, String description) {}
}
