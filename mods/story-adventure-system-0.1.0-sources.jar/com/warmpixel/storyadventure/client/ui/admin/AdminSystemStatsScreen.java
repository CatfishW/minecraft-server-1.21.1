package com.warmpixel.storyadventure.client.ui.admin;

import com.warmpixel.storyadventure.client.ui.StrangerScreen;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Admin UI showing system statistics and server health.
 */
public class AdminSystemStatsScreen extends StrangerScreen {
    
    private int activeInstances = 0;
    private int totalPlayers = 0;
    private int loadedStories = 0;
    private double serverTps = 20.0;
    private long serverMemoryUsed = 0;
    private long serverMemoryMax = 0;
    
    private final List<ActivityEntry> recentActivity = new ArrayList<>();
    private long lastUpdateTime = 0;
    
    public AdminSystemStatsScreen() {
        super(class_2561.method_43471("gui.storyadventure.admin.stats.title"));
    }
    
    public void setStats(int activeInstances, int totalPlayers, int loadedStories, 
                         double serverTps, long memoryUsed, long memoryMax) {
        this.activeInstances = activeInstances;
        this.totalPlayers = totalPlayers;
        this.loadedStories = loadedStories;
        this.serverTps = serverTps;
        this.serverMemoryUsed = memoryUsed;
        this.serverMemoryMax = memoryMax;
    }
    
    public void addActivity(String message, long timestamp) {
        recentActivity.add(0, new ActivityEntry(message, timestamp));
        if (recentActivity.size() > 20) {
            recentActivity.remove(recentActivity.size() - 1);
        }
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        // Refresh button
        addStrangerButton(field_22789 - 150, 50, 120, 24,
            class_2561.method_43471("gui.storyadventure.admin.stats.refresh"), this::refreshStats);
        
        // Back button
        addStrangerButton(30, field_22790 - 45, 100, 28,
            class_2561.method_43471("gui.storyadventure.admin.stats.back"), this::goBack);
        
        // Close button
        addStrangerButton(field_22789 / 2 - 60, field_22790 - 45, 120, 28,
            class_2561.method_43471("gui.storyadventure.admin.stats.close"), this::method_25419);
        
        // Request initial stats
        refreshStats();
    }
    
    @Override
    protected void renderContent(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int panelWidth = 200;
        int panelHeight = 120;
        int gap = 20;
        int startX = 40;
        int startY = 60;
        
        // === Instance Stats Panel ===
        renderStatPanel(graphics, startX, startY, panelWidth, panelHeight, 
            class_2561.method_43471("gui.storyadventure.admin.stats.panel.instances").getString(), 
            new String[]{
            class_2561.method_43469("gui.storyadventure.admin.stats.active_instances", activeInstances).getString(),
            class_2561.method_43471("gui.storyadventure.admin.stats.waiting_teams").getString(),
            class_2561.method_43471("gui.storyadventure.admin.stats.completed_today").getString(),
            class_2561.method_43471("gui.storyadventure.admin.stats.failed_today").getString()
        }, new int[]{
            activeInstances > 0 ? 0xFF44FF44 : COLOR_TEXT_BODY,
            COLOR_TEXT_BODY,
            COLOR_TEXT_BODY,
            COLOR_TEXT_DIM
        });
        
        // === Player Stats Panel ===
        renderStatPanel(graphics, startX + panelWidth + gap, startY, panelWidth, panelHeight, 
            class_2561.method_43471("gui.storyadventure.admin.stats.panel.players").getString(), 
            new String[]{
            class_2561.method_43469("gui.storyadventure.admin.stats.players_in_adventure", totalPlayers).getString(),
            class_2561.method_43469("gui.storyadventure.admin.stats.total_online", (class_310.method_1551().method_1562() != null ? 
                class_310.method_1551().method_1562().method_2880().size() : 0)).getString(),
            class_2561.method_43471("gui.storyadventure.admin.stats.waiting_players").getString()
        }, new int[]{
            totalPlayers > 0 ? COLOR_NEON_RED : COLOR_TEXT_BODY,
            COLOR_TEXT_BODY,
            COLOR_TEXT_DIM
        });
        
        // === Server Health Panel ===
        int healthColor = serverTps >= 19 ? 0xFF44FF44 : (serverTps >= 15 ? 0xFFFFCC00 : 0xFFFF4444);
        String tpsStr = class_2561.method_43469("gui.storyadventure.admin.stats.tps", serverTps).getString();
        long memMB = serverMemoryUsed / (1024 * 1024);
        long maxMB = serverMemoryMax / (1024 * 1024);
        String memStr = class_2561.method_43469("gui.storyadventure.admin.stats.memory", memMB, maxMB).getString();
        String statusNormal = class_2561.method_43469("gui.storyadventure.admin.stats.status", class_2561.method_43471("gui.storyadventure.admin.stats.status.normal").getString()).getString();
        
        renderStatPanel(graphics, startX, startY + panelHeight + gap, panelWidth, panelHeight, 
            class_2561.method_43471("gui.storyadventure.admin.stats.panel.health").getString(), 
            new String[]{
            tpsStr,
            memStr,
            statusNormal
        }, new int[]{
            healthColor,
            COLOR_TEXT_BODY,
            0xFF44FF44
        });
        
        // === Story Stats Panel ===
        renderStatPanel(graphics, startX + panelWidth + gap, startY + panelHeight + gap, panelWidth, panelHeight, 
            class_2561.method_43471("gui.storyadventure.admin.stats.panel.stories").getString(), 
            new String[]{
            class_2561.method_43469("gui.storyadventure.admin.stats.loaded_stories", loadedStories).getString(),
            class_2561.method_43469("gui.storyadventure.admin.stats.valid_stories", loadedStories).getString(),
            class_2561.method_43471("gui.storyadventure.admin.stats.error_stories").getString()
        }, new int[]{
            COLOR_TEXT_BODY,
            0xFF44FF44,
            COLOR_TEXT_DIM
        });
        
        // === Recent Activity Panel ===
        int activityX = startX + (panelWidth + gap) * 2;
        int activityWidth = field_22789 - activityX - 40;
        int activityHeight = field_22790 - 140;
        
        graphics.method_25294(activityX, startY, activityX + activityWidth, startY + activityHeight, 0xE0080808);
        drawPanelBorder(graphics, activityX, startY, activityWidth, activityHeight);
        
        graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.stats.panel.activity"), activityX + 10, startY + 8, COLOR_NEON_RED);
        graphics.method_25294(activityX + 5, startY + 22, activityX + activityWidth - 5, startY + 23, COLOR_BORDER);
        
        int actY = startY + 30;
        if (recentActivity.isEmpty()) {
            graphics.method_27535(field_22793, class_2561.method_43471("gui.storyadventure.admin.stats.no_activity"), activityX + 10, actY, COLOR_TEXT_DIM);
        } else {
            for (int i = 0; i < Math.min(recentActivity.size(), 10); i++) {
                ActivityEntry entry = recentActivity.get(i);
                String timeAgo = formatTimeAgo(entry.timestamp);
                graphics.method_25303(field_22793, "§7" + timeAgo + " §f" + entry.message, activityX + 10, actY, COLOR_TEXT_BODY);
                actY += 14;
            }
        }
        
        // Progress bars for memory
        int barX = startX + 10;
        int barY = startY + panelHeight + gap + panelHeight - 25;
        int barWidth = panelWidth - 20;
        int barHeight = 8;
        
        // Memory bar background
        graphics.method_25294(barX, barY, barX + barWidth, barY + barHeight, 0xFF333333);
        // Memory bar fill
        double memPercent = serverMemoryMax > 0 ? (double) serverMemoryUsed / serverMemoryMax : 0;
        int fillWidth = (int)(barWidth * memPercent);
        int memBarColor = memPercent < 0.7 ? 0xFF44FF44 : (memPercent < 0.9 ? 0xFFFFCC00 : 0xFFFF4444);
        graphics.method_25294(barX, barY, barX + fillWidth, barY + barHeight, memBarColor);
        
        // Last update time
        if (lastUpdateTime > 0) {
            String updateStr = class_2561.method_43469("gui.storyadventure.admin.stats.last_update", formatTimeAgo(lastUpdateTime)).getString();
            graphics.method_25303(field_22793, updateStr, 40, field_22790 - 70, COLOR_TEXT_DIM);
        }
    }
    
    private void renderStatPanel(class_332 graphics, int x, int y, int w, int h, 
                                  String title, String[] lines, int[] colors) {
        graphics.method_25294(x, y, x + w, y + h, 0xE0080808);
        drawPanelBorder(graphics, x, y, w, h);
        
        graphics.method_25303(field_22793, title, x + 10, y + 8, COLOR_NEON_RED);
        graphics.method_25294(x + 5, y + 22, x + w - 5, y + 23, COLOR_BORDER);
        
        int lineY = y + 32;
        for (int i = 0; i < lines.length; i++) {
            int color = i < colors.length ? colors[i] : COLOR_TEXT_BODY;
            graphics.method_25303(field_22793, lines[i], x + 10, lineY, color);
            lineY += 16;
        }
    }
    
    private void drawPanelBorder(class_332 graphics, int x, int y, int w, int h) {
        graphics.method_25294(x, y, x + w, y + 1, COLOR_BORDER);
        graphics.method_25294(x, y + h - 1, x + w, y + h, COLOR_BORDER);
        graphics.method_25294(x, y, x + 1, y + h, COLOR_BORDER);
        graphics.method_25294(x + w - 1, y, x + w, y + h, COLOR_BORDER);
        
        int cs = 6;
        graphics.method_25294(x, y, x + cs, y + 2, COLOR_NEON_RED);
        graphics.method_25294(x, y, x + 2, y + cs, COLOR_NEON_RED);
        graphics.method_25294(x + w - cs, y, x + w, y + 2, COLOR_NEON_RED);
        graphics.method_25294(x + w - 2, y, x + w, y + cs, COLOR_NEON_RED);
    }
    
    private String formatTimeAgo(long timestamp) {
        long diff = System.currentTimeMillis() - timestamp;
        long seconds = diff / 1000;
        if (seconds < 60) return class_2561.method_43469("gui.storyadventure.admin.stats.time.seconds", seconds).getString();
        long minutes = seconds / 60;
        if (minutes < 60) return class_2561.method_43469("gui.storyadventure.admin.stats.time.minutes", minutes).getString();
        long hours = minutes / 60;
        return class_2561.method_43469("gui.storyadventure.admin.stats.time.hours", hours).getString();
    }
    
    private void refreshStats() {
        lastUpdateTime = System.currentTimeMillis();
        
        // Get local stats from client cache
        var instances = com.warmpixel.storyadventure.network.ClientNetworkHandler.getLastSyncedInstances();
        activeInstances = instances.size();
        totalPlayers = instances.stream().mapToInt(i -> i.playerCount()).sum();
        
        // Memory stats (client-side only)
        Runtime runtime = Runtime.getRuntime();
        serverMemoryUsed = runtime.totalMemory() - runtime.freeMemory();
        serverMemoryMax = runtime.maxMemory();
        serverTps = 20.0; // Placeholder - would need server sync
        
        loadedStories = 2; // Placeholder
        
        var mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            mc.field_1724.field_3944.method_45730("storyadmin stats");
            mc.field_1724.method_43496(class_2561.method_43471("command.storyadventure.admin.stats.refreshing"));
        }
    }
    
    private void goBack() {
        class_310.method_1551().method_1507(new AdminDashboardScreen());
    }
    
    public record ActivityEntry(String message, long timestamp) {}
}
