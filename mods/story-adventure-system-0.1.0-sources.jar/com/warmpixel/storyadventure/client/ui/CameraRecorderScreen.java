package com.warmpixel.storyadventure.client.ui;

import com.google.gson.GsonBuilder;
import com.warmpixel.storyadventure.client.cinematic.CameraPath;
import com.warmpixel.storyadventure.client.cinematic.CameraRecording;
import com.warmpixel.storyadventure.client.cinematic.CinematicCameraController;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;

/**
 * Camera Recorder Screen - Compact UI for recording camera positions and rotations.
 * Uses the Stranger Things theme for consistent styling.
 */
public class CameraRecorderScreen extends StrangerScreen {
    
    private static final int PANEL_WIDTH = 340;
    private static final int PANEL_HEIGHT = 320;
    
    // Additional colors
    private static final int COLOR_PANEL_BG = 0xE8101018;
    private static final int COLOR_SECTION_BG = 0xCC1A1A2A;
    private static final int COLOR_ACCENT_CYAN = 0xFF00D9FF;
    private static final int COLOR_SUCCESS = 0xFF4CAF50;
    private static final int COLOR_WARNING = 0xFFFF9800;
    
    private final CameraRecording recording;
    
    // UI state
    private class_342 durationBox;
    private int selectedEasingIndex = 3;
    private final String[] easingOptions = {"LINEAR", "EASE_IN", "EASE_OUT", "EASE_IN_OUT", "CUBIC_IN_OUT", "SMOOTH_STEP"};
    
    private int scrollOffset = 0;
    private int selectedKeyframe = -1;
    
    private String statusMessage = "";
    private long statusMessageTime = 0;
    private int statusColor = COLOR_SUCCESS;
    
    public CameraRecorderScreen() {
        super(class_2561.method_43470("📹 摄像机录制器"));
        this.recording = new CameraRecording("New Recording");
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        strangerButtons.clear();
        
        int panelX = (field_22789 - PANEL_WIDTH) / 2;
        int panelY = (field_22790 - PANEL_HEIGHT) / 2;
        
        // Duration input box
        durationBox = new class_342(field_22793, panelX + 110, panelY + 118, 50, 14, class_2561.method_43470("Duration"));
        durationBox.method_1852("60");
        durationBox.method_1880(5);
        durationBox.method_1890(s -> s.matches("\\d*"));
        durationBox.method_1868(0xFFFFFFFF);
        durationBox.method_1858(true);
        method_37063(durationBox);
        
        // === Recording Controls Row ===
        int ctrlY = panelY + 135;
        
        addStrangerButton(panelX + 15, ctrlY, 120, 18, 
            class_2561.method_43470("📍 录制关键帧"), this::recordKeyframe);
        
        addStrangerButton(panelX + 175, ctrlY, 150, 18,
            class_2561.method_43470(easingOptions[selectedEasingIndex]), this::cycleEasing);
        
        // === Bottom Action Buttons ===
        int btnY = panelY + PANEL_HEIGHT - 32;
        int btnWidth = 60;
        int btnGap = 5;
        int btnX = panelX + 15;
        
        addStrangerButton(btnX, btnY, btnWidth, 18, 
            class_2561.method_43470("💾 保存"), this::saveRecording);
        btnX += btnWidth + btnGap;
        
        addStrangerButton(btnX, btnY, btnWidth, 18,
            class_2561.method_43470("📂 加载"), this::loadRecording);
        btnX += btnWidth + btnGap;
        
        addStrangerButton(btnX, btnY, btnWidth, 18,
            class_2561.method_43470("🗑 清空"), () -> {
                recording.clearKeyframes();
                setStatus("已清空", COLOR_WARNING);
            });
        btnX += btnWidth + btnGap;
        
        addStrangerButton(btnX, btnY, btnWidth, 18,
            class_2561.method_43470("▶ 预览"), this::previewPath);
        btnX += btnWidth + btnGap;
        
        addStrangerButton(btnX, btnY, btnWidth, 18,
            class_2561.method_43470("📋 复制"), this::copyToClipboard);
    }
    
    private void cycleEasing() {
        selectedEasingIndex = (selectedEasingIndex + 1) % easingOptions.length;
        if (strangerButtons.size() > 1) {
            strangerButtons.get(1).method_25355(class_2561.method_43470(easingOptions[selectedEasingIndex]));
        }
    }
    
    @Override
    protected void renderContent(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int panelX = (field_22789 - PANEL_WIDTH) / 2;
        int panelY = (field_22790 - PANEL_HEIGHT) / 2;
        
        // Main panel
        renderPanel(graphics, panelX, panelY, PANEL_WIDTH, PANEL_HEIGHT);
        
        int y = panelY + 30;
        
        // === Current Camera Section ===
        renderSectionBackground(graphics, panelX + 10, y, PANEL_WIDTH - 20, 45);
        graphics.method_25303(field_22793, "§e当前摄像机", panelX + 15, y + 3, COLOR_TEXT_TITLE);
        
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && mc.field_1773 != null) {
            var camera = mc.field_1773.method_19418();
            var pos = camera.method_19326();
            float yaw = camera.method_19330();
            float pitch = camera.method_19329();
            
            graphics.method_25303(field_22793, String.format("§7位置: §fX:%.1f Y:%.1f Z:%.1f", pos.field_1352, pos.field_1351, pos.field_1350), 
                panelX + 15, y + 16, COLOR_TEXT_BODY);
            graphics.method_25303(field_22793, String.format("§7旋转: §f偏航:%.1f° 俯仰:%.1f° §7FOV:§f%.0f", yaw, pitch, mc.field_1690.method_41808().method_41753().doubleValue()), 
                panelX + 15, y + 28, COLOR_TEXT_BODY);
        }
        
        y += 50;
        
        // === Recording Controls Section ===
        renderSectionBackground(graphics, panelX + 10, y, PANEL_WIDTH - 20, 40);
        graphics.method_25303(field_22793, "§e录制控制", panelX + 15, y + 3, COLOR_TEXT_TITLE);
        graphics.method_25303(field_22793, "时长(tick):", panelX + 15, y + 20, COLOR_TEXT_DIM);
        graphics.method_25303(field_22793, "缓动:", panelX + 175, y + 20, COLOR_TEXT_DIM);
        
        y += 60;
        
        // === Keyframes List Section ===
        String listTitle = String.format("§e关键帧 (%d)", recording.getKeyframeCount());
        renderSectionBackground(graphics, panelX + 10, y, PANEL_WIDTH - 20, 85);
        graphics.method_25303(field_22793, listTitle, panelX + 15, y + 3, COLOR_TEXT_TITLE);
        
        int listY = y + 15;
        int listItemHeight = 16;
        int maxVisible = 4;
        
        List<CameraRecording.RecordedKeyframe> keyframes = recording.getKeyframes();
        
        if (keyframes.isEmpty()) {
            graphics.method_25300(field_22793, "§8暂无关键帧", panelX + PANEL_WIDTH / 2, listY + 25, COLOR_TEXT_DIM);
        } else {
            for (int i = scrollOffset; i < Math.min(keyframes.size(), scrollOffset + maxVisible); i++) {
                CameraRecording.RecordedKeyframe kf = keyframes.get(i);
                int itemY = listY + (i - scrollOffset) * listItemHeight;
                
                if (i == selectedKeyframe) {
                    graphics.method_25294(panelX + 12, itemY, panelX + PANEL_WIDTH - 12, itemY + listItemHeight - 1, 0x30FFFFFF);
                }
                
                if (mouseX >= panelX + 12 && mouseX <= panelX + PANEL_WIDTH - 12 &&
                    mouseY >= itemY && mouseY < itemY + listItemHeight) {
                    graphics.method_25294(panelX + 12, itemY, panelX + PANEL_WIDTH - 12, itemY + listItemHeight - 1, 0x15FFFFFF);
                }
                
                graphics.method_25303(field_22793, String.format("§b#%d", i + 1), panelX + 15, itemY + 3, COLOR_ACCENT_CYAN);
                graphics.method_25303(field_22793, String.format("§7(%.0f,%.0f,%.0f)", kf.x(), kf.y(), kf.z()), panelX + 35, itemY + 3, COLOR_TEXT_BODY);
                graphics.method_25303(field_22793, String.format("§f%.0f°/%.0f°", kf.yaw(), kf.pitch()), panelX + 155, itemY + 3, COLOR_TEXT_BODY);
                graphics.method_25303(field_22793, String.format("§e%dt", kf.durationTicks()), panelX + 230, itemY + 3, COLOR_TEXT_BODY);
                graphics.method_25303(field_22793, "§c✕", panelX + PANEL_WIDTH - 25, itemY + 3, 0xFFFF5555);
            }
            
            if (scrollOffset > 0) graphics.method_25303(field_22793, "§7▲", panelX + PANEL_WIDTH - 22, y + 3, 0xAAAAAA);
            if (scrollOffset + maxVisible < keyframes.size()) graphics.method_25303(field_22793, "§7▼", panelX + PANEL_WIDTH - 22, y + 75, 0xAAAAAA);
        }
        
        y += 90;
        
        // === Status Message ===
        if (!statusMessage.isEmpty() && System.currentTimeMillis() - statusMessageTime < 2500) {
            graphics.method_25300(field_22793, statusMessage, panelX + PANEL_WIDTH / 2, y, statusColor);
        }
    }
    
    private void renderPanel(class_332 graphics, int x, int y, int w, int h) {
        // Glow
        for (int i = 3; i >= 1; i--) {
            int glowColor = ((8 + i * 4) << 24) | (COLOR_NEON_RED & 0x00FFFFFF);
            graphics.method_25294(x - i, y - i, x + w + i, y + h + i, glowColor);
        }
        
        graphics.method_25294(x, y, x + w, y + h, COLOR_PANEL_BG);
        
        // Border
        graphics.method_25294(x, y, x + w, y + 1, COLOR_NEON_RED);
        graphics.method_25294(x, y + h - 1, x + w, y + h, COLOR_NEON_RED);
        graphics.method_25294(x, y, x + 1, y + h, COLOR_NEON_RED);
        graphics.method_25294(x + w - 1, y, x + w, y + h, COLOR_NEON_RED);
        
        // Header
        graphics.method_25294(x + 1, y + 1, x + w - 1, y + 24, 0xFF1A0808);
        graphics.method_25294(x + 1, y + 24, x + w - 1, y + 25, COLOR_BORDER);
        
        graphics.method_27534(field_22793, field_22785, x + w / 2, y + 8, COLOR_ACCENT_CYAN);
        graphics.method_25303(field_22793, "§8[ESC]", x + w - 35, y + 8, COLOR_TEXT_DIM);
    }
    
    private void renderSectionBackground(class_332 graphics, int x, int y, int w, int h) {
        graphics.method_25294(x, y, x + w, y + h, COLOR_SECTION_BG);
        graphics.method_25294(x, y, x + w, y + 1, 0x25FFFFFF);
    }
    
    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizAmount, double vertAmount) {
        int maxScroll = Math.max(0, recording.getKeyframeCount() - 4);
        scrollOffset = Math.max(0, Math.min(maxScroll, scrollOffset - (int) vertAmount));
        return true;
    }
    
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        int panelX = (field_22789 - PANEL_WIDTH) / 2;
        int panelY = (field_22790 - PANEL_HEIGHT) / 2;
        
        int listY = panelY + 30 + 50 + 60 + 15;
        int listItemHeight = 16;
        
        if (mouseX >= panelX + 12 && mouseX <= panelX + PANEL_WIDTH - 12) {
            for (int i = 0; i < Math.min(recording.getKeyframeCount() - scrollOffset, 4); i++) {
                int itemY = listY + i * listItemHeight;
                if (mouseY >= itemY && mouseY < itemY + listItemHeight) {
                    int keyframeIndex = scrollOffset + i;
                    
                    if (mouseX >= panelX + PANEL_WIDTH - 30) {
                        recording.removeKeyframe(keyframeIndex);
                        setStatus("已删除 #" + (keyframeIndex + 1), COLOR_WARNING);
                        if (selectedKeyframe >= recording.getKeyframeCount()) selectedKeyframe = -1;
                        return true;
                    }
                    
                    selectedKeyframe = keyframeIndex;
                    return true;
                }
            }
        }
        
        return super.method_25402(mouseX, mouseY, button);
    }
    
    private void recordKeyframe() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1773 == null) return;
        
        var camera = mc.field_1773.method_19418();
        var pos = camera.method_19326();
        float yaw = camera.method_19330();
        float pitch = camera.method_19329();
        float fov = mc.field_1690.method_41808().method_41753().floatValue();
        
        int duration = 60;
        try { duration = Integer.parseInt(durationBox.method_1882()); } catch (NumberFormatException ignored) {}
        if (recording.getKeyframeCount() == 0) duration = 0;
        
        recording.addKeyframe(pos.field_1352, pos.field_1351, pos.field_1350, yaw, pitch, fov, duration, easingOptions[selectedEasingIndex]);
        setStatus("已录制 #" + recording.getKeyframeCount(), COLOR_SUCCESS);
    }
    
    private void saveRecording() {
        if (recording.getKeyframeCount() == 0) { setStatus("无关键帧", COLOR_NEON_RED); return; }
        try {
            Path savedPath = recording.saveToFile();
            setStatus("已保存: " + savedPath.getFileName(), COLOR_SUCCESS);
        } catch (IOException e) { setStatus("保存失败", COLOR_NEON_RED); }
    }
    
    private void loadRecording() {
        List<Path> files = CameraRecording.listRecordingFiles();
        if (files.isEmpty()) { setStatus("无文件", COLOR_WARNING); return; }
        
        try {
            CameraRecording loaded = CameraRecording.loadFromFile(files.get(files.size() - 1));
            recording.clearKeyframes();
            for (var kf : loaded.getKeyframes()) recording.addKeyframe(kf);
            setStatus("已加载 " + loaded.getKeyframeCount() + " 帧", COLOR_SUCCESS);
        } catch (IOException e) { setStatus("加载失败", COLOR_NEON_RED); }
    }
    
    private void previewPath() {
        if (recording.getKeyframeCount() < 2) { setStatus("需≥2帧", COLOR_WARNING); return; }
        
        CameraPath path = recording.toCameraPath();
        CinematicCameraController.CutsceneConfig config = new CinematicCameraController.CutsceneConfig()
            .setSkippable(true).setLetterboxEnabled(true)
            .setOnComplete(() -> class_310.method_1551().method_1507(new CameraRecorderScreen()));
        
        CinematicCameraController.getInstance().startCutscene(path, config);
        this.method_25419();
    }
    
    private void copyToClipboard() {
        if (recording.getKeyframeCount() == 0) { setStatus("无关键帧", COLOR_WARNING); return; }
        String json = new GsonBuilder().setPrettyPrinting().create().toJson(recording.toCameraPathJson());
        class_310.method_1551().field_1774.method_1455(json);
        setStatus("已复制JSON", COLOR_SUCCESS);
    }
    
    private void setStatus(String message, int color) {
        this.statusMessage = message;
        this.statusMessageTime = System.currentTimeMillis();
        this.statusColor = color;
    }
}
