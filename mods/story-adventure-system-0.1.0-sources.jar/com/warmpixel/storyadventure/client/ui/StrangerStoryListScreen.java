package com.warmpixel.storyadventure.client.ui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;

/**
 * Stranger Things themed story selection screen.
 * Lists available stories with neon styling.
 */
public class StrangerStoryListScreen extends StrangerScreen {
    
    private final List<StoryEntry> stories = new ArrayList<>();
    private int selectedIndex = -1;
    private int scrollOffset = 0;
    private static final int ENTRY_HEIGHT = 50;
    private static final int VISIBLE_ENTRIES = 5;
    
    public StrangerStoryListScreen() {
        super(class_2561.method_43470("选择故事"));
    }
    
    public void addStory(String id, String name, String description, int minPlayers, int maxPlayers, int estimatedMinutes) {
        stories.add(new StoryEntry(id, name, description, minPlayers, maxPlayers, estimatedMinutes));
    }

    public void clearStories() {
        stories.clear();
        selectedIndex = -1;
        scrollOffset = 0;
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        int buttonWidth = 150;
        int buttonHeight = 28;
        int bottomY = field_22790 - 50;
        
        // Start button
        addStrangerButton(field_22789 / 2 - buttonWidth - 10, bottomY, buttonWidth, buttonHeight,
            class_2561.method_43470("开始故事"), this::startSelectedStory);
        
        // Back button  
        addStrangerButton(field_22789 / 2 + 10, bottomY, buttonWidth, buttonHeight,
            class_2561.method_43470("返回"), this::method_25419);
    }
    
    @Override
    protected void renderContent(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int listX = 50;
        int listY = 60;
        int listWidth = field_22789 - 100;
        int listHeight = ENTRY_HEIGHT * VISIBLE_ENTRIES;
        
        // Draw list background
        graphics.method_25294(listX, listY, listX + listWidth, listY + listHeight, 0xE0080808);
        
        // Draw list border
        drawListBorder(graphics, listX, listY, listWidth, listHeight);
        
        // Draw entries
        if (stories.isEmpty()) {
             graphics.method_25300(field_22793, "加载中...", field_22789 / 2, listY + listHeight / 2, COLOR_TEXT_DIM);
        } else {
            int visibleEnd = Math.min(scrollOffset + VISIBLE_ENTRIES, stories.size());
            for (int i = scrollOffset; i < visibleEnd; i++) {
                int entryY = listY + (i - scrollOffset) * ENTRY_HEIGHT;
                renderStoryEntry(graphics, stories.get(i), listX + 4, entryY, listWidth - 8, i == selectedIndex, mouseX, mouseY);
            }
        }
        
        // Draw scroll indicators if needed
        if (scrollOffset > 0) {
            graphics.method_25303(field_22793, "▲", listX + listWidth / 2 - 4, listY - 12, COLOR_NEON_RED);
        }
        if (scrollOffset + VISIBLE_ENTRIES < stories.size()) {
            graphics.method_25303(field_22793, "▼", listX + listWidth / 2 - 4, listY + listHeight + 4, COLOR_NEON_RED);
        }
    }
    
    private void renderStoryEntry(class_332 graphics, StoryEntry story, int x, int y, int width, boolean selected, int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + ENTRY_HEIGHT;
        
        // Background
        int bgColor = selected ? 0xFF1A0808 : (hovered ? 0xFF100505 : 0xFF080808);
        graphics.method_25294(x, y, x + width, y + ENTRY_HEIGHT - 2, bgColor);
        
        // Border
        int borderColor = selected ? COLOR_NEON_RED : COLOR_BORDER;
        graphics.method_25294(x, y, x + width, y + 1, borderColor);
        graphics.method_25294(x, y + ENTRY_HEIGHT - 3, x + width, y + ENTRY_HEIGHT - 2, borderColor);
        graphics.method_25294(x, y, x + 1, y + ENTRY_HEIGHT - 2, borderColor);
        graphics.method_25294(x + width - 1, y, x + width, y + ENTRY_HEIGHT - 2, borderColor);
        
        // Title
        graphics.method_25303(field_22793, story.name, x + 8, y + 6, selected ? COLOR_NEON_RED : COLOR_TEXT_BODY);
        
        // Description (truncated)
        String desc = story.description;
        if (field_22793.method_1727(desc) > width - 16) {
            while (field_22793.method_1727(desc + "...") > width - 16 && desc.length() > 0) {
                desc = desc.substring(0, desc.length() - 1);
            }
            desc += "...";
        }
        graphics.method_25303(field_22793, desc, x + 8, y + 20, COLOR_TEXT_DIM);
        
        // Player count and duration
        String info = String.format("%d-%d人 | 约%d分钟", story.minPlayers, story.maxPlayers, story.estimatedMinutes);
        graphics.method_25303(field_22793, info, x + 8, y + 34, COLOR_TEXT_DIM);
    }
    
    private void drawListBorder(class_332 graphics, int x, int y, int w, int h) {
        graphics.method_25294(x, y, x + w, y + 1, COLOR_BORDER);
        graphics.method_25294(x, y + h - 1, x + w, y + h, COLOR_BORDER);
        graphics.method_25294(x, y, x + 1, y + h, COLOR_BORDER);
        graphics.method_25294(x + w - 1, y, x + w, y + h, COLOR_BORDER);
        
        // Corner accents
        int cs = 8;
        graphics.method_25294(x, y, x + cs, y + 2, COLOR_NEON_RED);
        graphics.method_25294(x, y, x + 2, y + cs, COLOR_NEON_RED);
        graphics.method_25294(x + w - cs, y, x + w, y + 2, COLOR_NEON_RED);
        graphics.method_25294(x + w - 2, y, x + w, y + cs, COLOR_NEON_RED);
    }
    
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        // Check for story selection
        int listX = 50;
        int listY = 60;
        int listWidth = field_22789 - 100;
        
        if (mouseX >= listX && mouseX < listX + listWidth) {
            int relY = (int)mouseY - listY;
            if (relY >= 0 && relY < ENTRY_HEIGHT * VISIBLE_ENTRIES) {
                int clickedIndex = scrollOffset + relY / ENTRY_HEIGHT;
                if (clickedIndex < stories.size()) {
                    selectedIndex = clickedIndex;
                    return true;
                }
            }
        }
        
        return super.method_25402(mouseX, mouseY, button);
    }
    
    @Override
    public boolean method_25401(double mouseX, double mouseY, double hAmount, double vAmount) {
        if (vAmount > 0 && scrollOffset > 0) {
            scrollOffset--;
            return true;
        } else if (vAmount < 0 && scrollOffset + VISIBLE_ENTRIES < stories.size()) {
            scrollOffset++;
            return true;
        }
        return super.method_25401(mouseX, mouseY, hAmount, vAmount);
    }
    
    private void startSelectedStory() {
        if (selectedIndex >= 0 && selectedIndex < stories.size()) {
            StoryEntry story = stories.get(selectedIndex);
            net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.send(
                new com.warmpixel.storyadventure.network.StoryActionPayload(
                    com.warmpixel.storyadventure.network.StoryActionPayload.Action.SELECT_STORY,
                    story.id
                )
            );
            // Don't close immediately, wait for server to switch us to Lobby
        }
    }
    
    public record StoryEntry(String id, String name, String description, int minPlayers, int maxPlayers, int estimatedMinutes) {}
}
