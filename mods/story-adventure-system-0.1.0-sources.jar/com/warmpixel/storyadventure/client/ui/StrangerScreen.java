package com.warmpixel.storyadventure.client.ui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

/**
 * Base screen for all Stranger Things themed story screens.
 * Dark background with neon accents, no vanilla UI elements.
 */
public abstract class StrangerScreen extends class_437 {
    // Stranger Things color palette
    protected static final int COLOR_BG_DARK = 0xF0050505;       // Near black with transparency
    protected static final int COLOR_BG_GRADIENT = 0xF0100808;   // Dark red tint
    protected static final int COLOR_NEON_RED = 0xFFE50914;      // Netflix/Stranger Things red
    protected static final int COLOR_NEON_PINK = 0xFFFF3366;     // Neon pink accent
    protected static final int COLOR_TEXT_TITLE = 0xFFE50914;    // Red title text
    protected static final int COLOR_TEXT_BODY = 0xFFCCCCCC;     // Light gray body
    protected static final int COLOR_TEXT_DIM = 0xFF666666;      // Dimmed text
    protected static final int COLOR_BORDER = 0xFF330011;        // Dark red border
    protected static final int COLOR_SCANLINE = 0x08FFFFFF;      // CRT scanline effect
    
    protected final List<StrangerButton> strangerButtons = new ArrayList<>();
    protected long screenOpenTime;
    
    protected StrangerScreen(class_2561 title) {
        super(title);
        this.screenOpenTime = System.currentTimeMillis();
    }
    
    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        // Render dark background with vignette effect
        renderStrangerBackground(graphics);
        
        // Render CRT scanline effect
        renderScanlines(graphics);
        
        // Render title with glow
        renderTitle(graphics);
        
        // Render custom buttons
        for (StrangerButton button : strangerButtons) {
            button.method_25394(graphics, mouseX, mouseY, partialTick);
        }
        
        // Render content (subclass implementation)
        renderContent(graphics, mouseX, mouseY, partialTick);
        
        // Render border frame
        renderBorderFrame(graphics);
    }
    
    protected void renderStrangerBackground(class_332 graphics) {
        // Full screen dark gradient
        int centerX = field_22789 / 2;
        int centerY = field_22790 / 2;
        
        // Base dark fill
        graphics.method_25294(0, 0, field_22789, field_22790, COLOR_BG_DARK);
        
        // Radial vignette effect (darker at edges)
        for (int layer = 0; layer < 5; layer++) {
            int alpha = 20 + layer * 8;
            int vignetteColor = (alpha << 24);
            int inset = layer * 40;
            
            // Top
            graphics.method_25294(0, 0, field_22789, inset, vignetteColor);
            // Bottom
            graphics.method_25294(0, field_22790 - inset, field_22789, field_22790, vignetteColor);
            // Left
            graphics.method_25294(0, 0, inset, field_22790, vignetteColor);
            // Right
            graphics.method_25294(field_22789 - inset, 0, field_22789, field_22790, vignetteColor);
        }
        
        // Subtle red glow in center
        int glowRadius = 100;
        int glowColor = 0x10E50914;
        graphics.method_25294(centerX - glowRadius, centerY - glowRadius, 
                     centerX + glowRadius, centerY + glowRadius, glowColor);
    }
    
    protected void renderScanlines(class_332 graphics) {
        // CRT monitor scanline effect for 80s aesthetic
        for (int y = 0; y < field_22790; y += 2) {
            graphics.method_25294(0, y, field_22789, y + 1, COLOR_SCANLINE);
        }
    }
    
    protected void renderTitle(class_332 graphics) {
        // Pulsing glow effect
        float pulse = (float)(0.7 + 0.3 * Math.sin((System.currentTimeMillis() - screenOpenTime) / 500.0));
        int glowAlpha = (int)(40 * pulse);
        int glowColor = (glowAlpha << 24) | (COLOR_NEON_PINK & 0x00FFFFFF);
        
        String titleText = field_22785.getString();
        int titleWidth = field_22793.method_1727(titleText);
        int titleX = (field_22789 - titleWidth) / 2;
        int titleY = 20;
        
        // Draw glow behind text
        graphics.method_25294(titleX - 10, titleY - 4, titleX + titleWidth + 10, titleY + 14, glowColor);
        
        // Draw title text
        graphics.method_27535(field_22793, field_22785, titleX, titleY, COLOR_TEXT_TITLE);
        
        // Draw underline accent
        int underlineY = titleY + 12;
        graphics.method_25294(titleX - 5, underlineY, titleX + titleWidth + 5, underlineY + 1, COLOR_NEON_RED);
    }
    
    protected void renderBorderFrame(class_332 graphics) {
        int margin = 8;
        int cornerSize = 20;
        
        // Corner accents (Stranger Things style)
        // Top-left
        graphics.method_25294(margin, margin, margin + cornerSize, margin + 2, COLOR_NEON_RED);
        graphics.method_25294(margin, margin, margin + 2, margin + cornerSize, COLOR_NEON_RED);
        
        // Top-right
        graphics.method_25294(field_22789 - margin - cornerSize, margin, field_22789 - margin, margin + 2, COLOR_NEON_RED);
        graphics.method_25294(field_22789 - margin - 2, margin, field_22789 - margin, margin + cornerSize, COLOR_NEON_RED);
        
        // Bottom-left
        graphics.method_25294(margin, field_22790 - margin - 2, margin + cornerSize, field_22790 - margin, COLOR_NEON_RED);
        graphics.method_25294(margin, field_22790 - margin - cornerSize, margin + 2, field_22790 - margin, COLOR_NEON_RED);
        
        // Bottom-right
        graphics.method_25294(field_22789 - margin - cornerSize, field_22790 - margin - 2, field_22789 - margin, field_22790 - margin, COLOR_NEON_RED);
        graphics.method_25294(field_22789 - margin - 2, field_22790 - margin - cornerSize, field_22789 - margin, field_22790 - margin, COLOR_NEON_RED);
    }
    
    /**
     * Override to render screen-specific content.
     */
    protected abstract void renderContent(class_332 graphics, int mouseX, int mouseY, float partialTick);
    
    protected StrangerButton addStrangerButton(int x, int y, int width, int height, 
                                                class_2561 text, Runnable onPress) {
        StrangerButton button = new StrangerButton(x, y, width, height, text, onPress);
        strangerButtons.add(button);
        method_37063(button);
        return button;
    }
    
    @Override
    public boolean method_25421() {
        return false;
    }
}
