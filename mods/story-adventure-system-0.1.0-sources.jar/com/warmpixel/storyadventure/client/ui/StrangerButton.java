package com.warmpixel.storyadventure.client.ui;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

/**
 * Custom Stranger Things themed button - no vanilla styling.
 * Neon red glow effect with dark background, 80s synth-wave aesthetic.
 */
public class StrangerButton extends class_339 {
    // Color scheme (Stranger Things neon red theme)
    private static final int COLOR_NEON_RED = 0xFFE50914;       // Netflix red
    private static final int COLOR_NEON_GLOW = 0xAAFF3366;      // Pink glow
    private static final int COLOR_DARK_BG = 0xFF0A0A0A;        // Near black
    private static final int COLOR_HOVER_BG = 0xFF1A0A0A;       // Slight red tint when hovered
    private static final int COLOR_TEXT = 0xFFE0E0E0;           // Light gray text
    private static final int COLOR_TEXT_HOVER = 0xFFFFFFFF;     // White on hover
    private static final int COLOR_BORDER = 0xFF330011;         // Dark red border
    
    private final Runnable onPress;
    private boolean glowPulse = true;
    private long creationTime;
    
    public StrangerButton(int x, int y, int width, int height, class_2561 message, Runnable onPress) {
        super(x, y, width, height, message);
        this.onPress = onPress;
        this.creationTime = System.currentTimeMillis();
    }
    
    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        boolean hovered = method_49606();
        
        // Calculate pulsing glow effect
        float pulsePhase = ((System.currentTimeMillis() - creationTime) % 2000) / 2000f;
        float glowIntensity = glowPulse ? (float)(0.5 + 0.5 * Math.sin(pulsePhase * Math.PI * 2)) : 1f;
        
        // Draw outer glow (when hovered or pulsing)
        if (hovered || glowPulse) {
            int glowAlpha = (int)(60 * glowIntensity);
            int glowColor = (glowAlpha << 24) | (COLOR_NEON_GLOW & 0x00FFFFFF);
            
            // Multiple layers for blur effect
            for (int i = 3; i >= 1; i--) {
                graphics.method_25294(method_46426() - i, method_46427() - i, method_46426() + field_22758 + i, method_46427() + field_22759 + i, glowColor);
            }
        }
        
        // Draw background
        int bgColor = hovered ? COLOR_HOVER_BG : COLOR_DARK_BG;
        graphics.method_25294(method_46426(), method_46427(), method_46426() + field_22758, method_46427() + field_22759, bgColor);
        
        // Draw border with gradient effect
        int borderColor = hovered ? COLOR_NEON_RED : COLOR_BORDER;
        
        // Top border
        graphics.method_25294(method_46426(), method_46427(), method_46426() + field_22758, method_46427() + 1, borderColor);
        // Bottom border
        graphics.method_25294(method_46426(), method_46427() + field_22759 - 1, method_46426() + field_22758, method_46427() + field_22759, borderColor);
        // Left border
        graphics.method_25294(method_46426(), method_46427(), method_46426() + 1, method_46427() + field_22759, borderColor);
        // Right border
        graphics.method_25294(method_46426() + field_22758 - 1, method_46427(), method_46426() + field_22758, method_46427() + field_22759, borderColor);
        
        // Draw corner accents (80s style)
        if (hovered) {
            int cornerSize = 4;
            // Top-left
            graphics.method_25294(method_46426(), method_46427(), method_46426() + cornerSize, method_46427() + 2, COLOR_NEON_RED);
            graphics.method_25294(method_46426(), method_46427(), method_46426() + 2, method_46427() + cornerSize, COLOR_NEON_RED);
            // Top-right
            graphics.method_25294(method_46426() + field_22758 - cornerSize, method_46427(), method_46426() + field_22758, method_46427() + 2, COLOR_NEON_RED);
            graphics.method_25294(method_46426() + field_22758 - 2, method_46427(), method_46426() + field_22758, method_46427() + cornerSize, COLOR_NEON_RED);
            // Bottom-left
            graphics.method_25294(method_46426(), method_46427() + field_22759 - 2, method_46426() + cornerSize, method_46427() + field_22759, COLOR_NEON_RED);
            graphics.method_25294(method_46426(), method_46427() + field_22759 - cornerSize, method_46426() + 2, method_46427() + field_22759, COLOR_NEON_RED);
            // Bottom-right
            graphics.method_25294(method_46426() + field_22758 - cornerSize, method_46427() + field_22759 - 2, method_46426() + field_22758, method_46427() + field_22759, COLOR_NEON_RED);
            graphics.method_25294(method_46426() + field_22758 - 2, method_46427() + field_22759 - cornerSize, method_46426() + field_22758, method_46427() + field_22759, COLOR_NEON_RED);
        }
        
        // Draw text centered
        int textColor = hovered ? COLOR_TEXT_HOVER : COLOR_TEXT;
        graphics.method_27534(
            net.minecraft.class_310.method_1551().field_1772,
            method_25369(),
            method_46426() + field_22758 / 2,
            method_46427() + (field_22759 - 8) / 2,
            textColor
        );
    }
    
    @Override
    public void method_25348(double mouseX, double mouseY) {
        if (onPress != null) {
            onPress.run();
        }
    }
    
    @Override
    protected void method_47399(class_6382 narration) {
        method_37021(narration);
    }
    
    public StrangerButton setGlowPulse(boolean pulse) {
        this.glowPulse = pulse;
        return this;
    }
}
