package com.warmpixel.storyadventure.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.warmpixel.storyadventure.StoryAdventureMod;
import com.warmpixel.storyadventure.core.graph.StageGraph;
import com.warmpixel.storyadventure.instance.Instance;
import com.warmpixel.storyadventure.instance.InstanceManager;
import com.warmpixel.storyadventure.instance.Party;
import com.warmpixel.storyadventure.instance.PartyManager;
import com.warmpixel.storyadventure.loader.StoryRegistry;
import java.util.UUID;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * Commands for managing story instances.
 */
public class InstanceCommands {
    
    public static void register(CommandDispatcher<class_2168> dispatcher,
                                InstanceManager instanceManager,
                                PartyManager partyManager,
                                StoryRegistry storyRegistry) {
        
        dispatcher.register(class_2170.method_9247("story")
            // List available stories
            .then(class_2170.method_9247("list")
                .executes(ctx -> {
                    var source = ctx.getSource();
                    var stories = storyRegistry.getAllStories();
                    
                    if (stories.isEmpty()) {
                        source.method_9226(() -> class_2561.method_43470("§e没有可用的故事。"), false);
                        return 0;
                    }
                    
                    source.method_9226(() -> class_2561.method_43470("§6=== 可用故事 ==="), false);
                    for (StageGraph story : stories) {
                        source.method_9226(() -> class_2561.method_43470(String.format(
                            "§a%s §7- %s §8(%d节点, %d-%d人)",
                            story.getStoryId(),
                            story.getName(),
                            story.getNodeCount(),
                            story.getMinPlayers(),
                            story.getMaxPlayers()
                        )), false);
                    }
                    
                    return stories.size();
                }))
            
            // Start a story
            .then(class_2170.method_9247("start")
                .then(class_2170.method_9244("story_id", StringArgumentType.word())
                    .suggests((ctx, builder) -> {
                        for (String id : storyRegistry.getStoryIds()) {
                            builder.suggest(id);
                        }
                        return builder.buildFuture();
                    })
                    .executes(ctx -> {
                        class_3222 player = ctx.getSource().method_9207();
                        String storyId = StringArgumentType.getString(ctx, "story_id");
                        
                        StageGraph story = storyRegistry.getStory(storyId);
                        if (story == null) {
                            ctx.getSource().method_9213(class_2561.method_43470("§c故事 '" + storyId + "' 不存在。"));
                            return 0;
                        }
                        
                        // Check if already in instance
                        if (instanceManager.isPlayerInInstance(player.method_5667())) {
                            ctx.getSource().method_9213(class_2561.method_43470("§c你已经在一个故事实例中。使用 /story leave 离开。"));
                            return 0;
                        }
                        
                        // Create party with player as leader
                        Party party = partyManager.createParty(player.method_5667(), story.getMaxPlayers());
                        
                        // Create and start instance
                        Instance instance = instanceManager.createInstance(story, party);
                        if (instance == null) {
                            ctx.getSource().method_9213(class_2561.method_43470("§c无法创建实例。"));
                            return 0;
                        }
                        
                        instance.start(ctx.getSource().method_9211());
                        
                        ctx.getSource().method_9226(() -> class_2561.method_43470(
                            "§a故事 '" + story.getName() + "' 已开始！实例ID: " + instance.getInstanceId()
                        ), false);
                        
                        return 1;
                    })))
            
            // Leave current instance
            .then(class_2170.method_9247("leave")
                .executes(ctx -> {
                    class_3222 player = ctx.getSource().method_9207();
                    
                    Instance instance = instanceManager.getPlayerInstance(player.method_5667());
                    if (instance == null) {
                        ctx.getSource().method_9213(class_2561.method_43470("§c你不在任何故事实例中。"));
                        return 0;
                    }
                    
                    instanceManager.removePlayerFromInstance(player.method_5667());
                    partyManager.leaveParty(player.method_5667());
                    
                    ctx.getSource().method_9226(() -> class_2561.method_43470("§e已离开故事实例。"), false);
                    return 1;
                }))
            
            // Show current progress
            .then(class_2170.method_9247("progress")
                .executes(ctx -> {
                    class_3222 player = ctx.getSource().method_9207();
                    
                    Instance instance = instanceManager.getPlayerInstance(player.method_5667());
                    if (instance == null) {
                        ctx.getSource().method_9213(class_2561.method_43470("§c你不在任何故事实例中。"));
                        return 0;
                    }
                    
                    var source = ctx.getSource();
                    source.method_9226(() -> class_2561.method_43470("§6=== 故事进度 ==="), false);
                    source.method_9226(() -> class_2561.method_43470("§7故事: §f" + instance.getGraph().getName()), false);
                    source.method_9226(() -> class_2561.method_43470("§7当前节点: §f" + instance.getCurrentNodeId()), false);
                    source.method_9226(() -> class_2561.method_43470("§7状态: §f" + instance.getStatus()), false);
                    source.method_9226(() -> class_2561.method_43470("§7队伍人数: §f" + instance.getParty().getMemberCount()), false);
                    source.method_9226(() -> class_2561.method_43470("§7已发现线索: §f" + instance.getState().getDiscoveredClues().size()), false);
                    
                    long elapsedMin = instance.getElapsedMillis() / 60000;
                    source.method_9226(() -> class_2561.method_43470("§7已用时间: §f" + elapsedMin + "分钟"), false);
                    
                    return 1;
                }))
            
            // Join an instance by ID
            .then(class_2170.method_9247("join")
                .then(class_2170.method_9244("instance_id", StringArgumentType.word())
                    .executes(ctx -> {
                        class_3222 player = ctx.getSource().method_9207();
                        String instanceIdStr = StringArgumentType.getString(ctx, "instance_id");
                        
                        UUID instanceId;
                        try {
                            instanceId = UUID.fromString(instanceIdStr);
                        } catch (IllegalArgumentException e) {
                            ctx.getSource().method_9213(class_2561.method_43470("§c无效的实例ID。"));
                            return 0;
                        }
                        
                        if (instanceManager.addPlayerToInstance(player.method_5667(), instanceId)) {
                            ctx.getSource().method_9226(() -> class_2561.method_43470("§a已加入实例。"), false);
                            return 1;
                        } else {
                            ctx.getSource().method_9213(class_2561.method_43470("§c无法加入实例。"));
                            return 0;
                        }
                    })))
        );
    }
}
