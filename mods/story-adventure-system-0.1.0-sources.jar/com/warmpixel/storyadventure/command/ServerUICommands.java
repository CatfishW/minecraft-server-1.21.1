package com.warmpixel.storyadventure.command;

import com.mojang.brigadier.CommandDispatcher;
import com.warmpixel.storyadventure.network.NetworkHandler;
import com.warmpixel.storyadventure.network.OpenUIPayload;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * Server-side commands to trigger UI screens on the client.
 * These commands send network packets to the client to open the appropriate UI.
 */
public class ServerUICommands {
    
    public static void register(CommandDispatcher<class_2168> dispatcher, 
                                com.warmpixel.storyadventure.instance.InstanceManager instanceManager,
                                com.warmpixel.storyadventure.instance.PartyManager partyManager) {
        
        // Main storyui command - server-side version that sends packets to client
        dispatcher.register(class_2170.method_9247("storyui")
            // Story list screen - no instance required
            .then(class_2170.method_9247("stories")
                .executes(ctx -> {
                    class_3222 player = ctx.getSource().method_9207();
                    NetworkHandler.sendOpenUI(player, OpenUIPayload.SCREEN_STORIES);
                    NetworkHandler.syncStoryList(player, com.warmpixel.storyadventure.StoryAdventureMod.getInstance().getStoryRegistry());
                    ctx.getSource().method_9226(() -> class_2561.method_43471("command.storyadventure.ui.stories.opening"), false);
                    return 1;
                }))
            
            // Lobby/ready screen - no instance required, creates party if needed
            .then(class_2170.method_9247("lobby")
                .executes(ctx -> {
                    class_3222 player = ctx.getSource().method_9207();
                    
                    // Ensure player is in a party for the lobby
                    var party = partyManager.getPlayerParty(player.method_5667());
                    if (party == null) {
                        party = partyManager.createParty(player.method_5667(), 4);
                    }
                    
                    // Sync current lobby status
                    NetworkHandler.syncLobby(player, party, ctx.getSource().method_9211());
                    
                    NetworkHandler.sendOpenUI(player, OpenUIPayload.SCREEN_LOBBY);
                    ctx.getSource().method_9226(() -> class_2561.method_43471("command.storyadventure.ui.lobby.opening"), false);
                    return 1;
                }))
            
            // Dialogue screen - requires active instance
            .then(class_2170.method_9247("dialogue")
                .executes(ctx -> {
                    class_3222 player = ctx.getSource().method_9207();
                    
                    // Check if player is in an active instance
                    var instance = instanceManager.getPlayerInstance(player.method_5667());
                    if (instance == null) {
                        ctx.getSource().method_9213(class_2561.method_43471("command.storyadventure.error.no_instance"));
                        return 0;
                    }
                    
                    NetworkHandler.sendOpenUI(player, OpenUIPayload.SCREEN_DIALOGUE);
                    ctx.getSource().method_9226(() -> class_2561.method_43471("command.storyadventure.ui.dialogue.opening"), false);
                    return 1;
                }))
            
            // Puzzle screen - requires active instance
            .then(class_2170.method_9247("puzzle")
                .executes(ctx -> {
                    class_3222 player = ctx.getSource().method_9207();
                    
                    // Check if player is in an active instance
                    var instance = instanceManager.getPlayerInstance(player.method_5667());
                    if (instance == null) {
                        ctx.getSource().method_9213(class_2561.method_43471("command.storyadventure.error.no_instance"));
                        return 0;
                    }
                    
                    NetworkHandler.sendOpenUI(player, OpenUIPayload.SCREEN_PUZZLE);
                    ctx.getSource().method_9226(() -> class_2561.method_43471("command.storyadventure.ui.puzzle.opening"), false);
                    return 1;
                }))
            
            // Toggle HUD - requires active instance
            .then(class_2170.method_9247("hud")
                .then(class_2170.method_9247("show")
                    .executes(ctx -> {
                        class_3222 player = ctx.getSource().method_9207();
                        
                        // Check if player is in an active instance
                        var instance = instanceManager.getPlayerInstance(player.method_5667());
                        if (instance == null) {
                            ctx.getSource().method_9213(class_2561.method_43471("command.storyadventure.error.no_instance_hud"));
                            return 0;
                        }
                        
                        NetworkHandler.sendOpenUI(player, OpenUIPayload.SCREEN_HUD_SHOW);
                        return 1;
                    }))
                .then(class_2170.method_9247("hide")
                    .executes(ctx -> {
                        class_3222 player = ctx.getSource().method_9207();
                        NetworkHandler.sendOpenUI(player, OpenUIPayload.SCREEN_HUD_HIDE);
                        return 1;
                    })))
            
            // Help
            .executes(ctx -> {
                ctx.getSource().method_9226(() -> class_2561.method_43470("§6=== Story UI Commands ==="), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyui stories §7- Open story list"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyui lobby §7- Open lobby"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyui dialogue §7- Dialogue screen"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyui puzzle §7- Puzzle screen"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyui hud show/hide §7- Show/Hide HUD"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyadminui §7- Admin Dashboard"), false);
                return 1;
            })
        );
        
        // Admin UI command
        dispatcher.register(class_2170.method_9247("storyadminui")
            // Main dashboard
            .then(class_2170.method_9247("dashboard")
                .requires(source -> source.method_9259(2))
                .executes(ctx -> {
                    class_3222 player = ctx.getSource().method_9207();
                    NetworkHandler.syncInstances(player, instanceManager);
                    NetworkHandler.sendOpenUI(player, OpenUIPayload.SCREEN_ADMIN_DASHBOARD);
                    ctx.getSource().method_9226(() -> class_2561.method_43471("command.storyadventure.ui.admin.dashboard.opening"), false);
                    return 1;
                }))
            
            // Instance manager
            .then(class_2170.method_9247("instances")
                .requires(source -> source.method_9259(2))
                .executes(ctx -> {
                    class_3222 player = ctx.getSource().method_9207();
                    NetworkHandler.syncInstances(player, instanceManager);
                    NetworkHandler.sendOpenUI(player, OpenUIPayload.SCREEN_ADMIN_INSTANCES);
                    ctx.getSource().method_9226(() -> class_2561.method_43471("command.storyadventure.ui.admin.instances.opening"), false);
                    return 1;
                }))
            
            // Story manager
            .then(class_2170.method_9247("stories")
                .requires(source -> source.method_9259(2))
                .executes(ctx -> {
                    class_3222 player = ctx.getSource().method_9207();
                    NetworkHandler.sendOpenUI(player, OpenUIPayload.SCREEN_ADMIN_STORIES);
                    NetworkHandler.syncAdminStories(player, com.warmpixel.storyadventure.StoryAdventureMod.getInstance().getStoryRegistry());
                    ctx.getSource().method_9226(() -> class_2561.method_43471("command.storyadventure.ui.admin.stories.opening"), false);
                    return 1;
                }))
            
            // Sync only versions - does not open UI
            .then(class_2170.method_9247("sync_stories")
                .requires(source -> source.method_9259(2))
                .executes(ctx -> {
                    class_3222 player = ctx.getSource().method_9207();
                    NetworkHandler.syncAdminStories(player, com.warmpixel.storyadventure.StoryAdventureMod.getInstance().getStoryRegistry());
                    return 1;
                }))
            
            .then(class_2170.method_9247("sync_instances")
                .requires(source -> source.method_9259(2))
                .executes(ctx -> {
                    class_3222 player = ctx.getSource().method_9207();
                    NetworkHandler.syncInstances(player, instanceManager);
                    return 1;
                }))
            
            // Default - open dashboard
            .requires(source -> source.method_9259(2))
            .executes(ctx -> {
                class_3222 player = ctx.getSource().method_9207();
                NetworkHandler.sendOpenUI(player, OpenUIPayload.SCREEN_ADMIN_DASHBOARD);
                ctx.getSource().method_9226(() -> class_2561.method_43471("command.storyadventure.ui.admin.dashboard.opening"), false);
                return 1;
            })
        );
    }
}
