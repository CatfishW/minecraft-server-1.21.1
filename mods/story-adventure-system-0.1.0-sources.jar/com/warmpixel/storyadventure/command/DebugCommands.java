package com.warmpixel.storyadventure.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.warmpixel.storyadventure.instance.Instance;
import com.warmpixel.storyadventure.instance.InstanceManager;
import com.warmpixel.storyadventure.loader.StoryRegistry;
import com.warmpixel.storyadventure.network.NetworkHandler;
import com.warmpixel.storyadventure.core.graph.StageGraph;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;

/**
 * Admin/debug commands for story system management.
 */
public class DebugCommands {
    
    public static void register(CommandDispatcher<class_2168> dispatcher,
                                InstanceManager instanceManager,
                                StoryRegistry storyRegistry) {
        
        dispatcher.register(class_2170.method_9247("storyadmin")
            .requires(source -> source.method_9259(2)) // OP level 2+
            
            // Reload stories
            .then(class_2170.method_9247("reload")
                .executes(ctx -> {
                    com.warmpixel.storyadventure.StoryAdventureMod.getInstance()
                        .getStoryLoader().reload();
                    ctx.getSource().method_9226(() -> class_2561.method_43470(
                        "§a已重新加载故事定义。共 " + storyRegistry.getStoryCount() + " 个故事。"
                    ), true);
                    return 1;
                }))
            
            // List active instances
            .then(class_2170.method_9247("instances")
                .executes(ctx -> {
                    var source = ctx.getSource();
                    var instances = instanceManager.getAllInstances();
                    
                    if (instances.isEmpty()) {
                        source.method_9226(() -> class_2561.method_43470("§e没有活动的实例。"), false);
                    } else {
                        source.method_9226(() -> class_2561.method_43470("§6=== 活动实例 ==="), false);
                        for (Instance instance : instances) {
                            source.method_9226(() -> class_2561.method_43470(String.format(
                                "§f%s §7- %s §8[%s] §7节点: %s",
                                instance.getInstanceId().toString().substring(0, 8),
                                instance.getGraph().getName(),
                                instance.getStatus(),
                                instance.getCurrentNodeId()
                            )), false);
                        }
                    }
                    
                    if (ctx.getSource().method_44023() != null) {
                        try {
                            NetworkHandler.syncInstances(ctx.getSource().method_44023(), instanceManager);
                        } catch (Exception e) {
                            com.warmpixel.storyadventure.StoryAdventureMod.LOGGER.error("Failed to sync instances: ", e);
                        }
                    }
                    return instances.size();
                }))
            
            // Debug a specific instance
            .then(class_2170.method_9247("debug")
                .then(class_2170.method_9244("instance_id", StringArgumentType.word())
                    .executes(ctx -> {
                        String idStr = StringArgumentType.getString(ctx, "instance_id");
                        Instance instance = findInstance(instanceManager, idStr);
                        
                        if (instance == null) {
                            ctx.getSource().method_9213(class_2561.method_43470("§c找不到实例: " + idStr));
                            return 0;
                        }
                        
                        var source = ctx.getSource();
                        Instance finalInstance = instance;
                        source.method_9226(() -> class_2561.method_43470("§6=== 实例调试信息 ==="), false);
                        source.method_9226(() -> class_2561.method_43470("§7ID: §f" + finalInstance.getInstanceId()), false);
                        source.method_9226(() -> class_2561.method_43470("§7故事: §f" + finalInstance.getGraph().getName()), false);
                        source.method_9226(() -> class_2561.method_43470("§7节点: §f" + finalInstance.getCurrentNodeId()), false);
                        source.method_9226(() -> class_2561.method_43470("§7状态: §f" + finalInstance.getStatus()), false);
                        source.method_9226(() -> class_2561.method_43470("§7队伍: §f" + finalInstance.getParty().getMemberCount() + " 人"), false);
                        source.method_9226(() -> class_2561.method_43470("§7已用时间: §f" + (finalInstance.getElapsedMillis() / 1000) + "秒"), false);
                        source.method_9226(() -> class_2561.method_43470("§7节点历史: §f" + finalInstance.getState().getNodeHistory().size() + " 个"), false);
                        source.method_9226(() -> class_2561.method_43470("§7线索: §f" + finalInstance.getState().getDiscoveredClues()), false);
                        
                        return 1;
                    })))
            
            // Pause an instance
            .then(class_2170.method_9247("pause")
                .then(class_2170.method_9244("instance_id", StringArgumentType.word())
                    .executes(ctx -> {
                        String idStr = StringArgumentType.getString(ctx, "instance_id");
                        Instance instance = findInstance(instanceManager, idStr);
                        
                        if (instance == null) {
                            ctx.getSource().method_9213(class_2561.method_43470("§c找不到实例: " + idStr));
                            return 0;
                        }
                        
                        instance.pause();
                        ctx.getSource().method_9226(() -> class_2561.method_43470("§e实例 " + idStr + " 已暂停。"), true);
                        
                        if (ctx.getSource().method_44023() != null) {
                            NetworkHandler.syncInstances(ctx.getSource().method_44023(), instanceManager);
                        }
                        return 1;
                    })))
            
            // Resume an instance
            .then(class_2170.method_9247("resume")
                .then(class_2170.method_9244("instance_id", StringArgumentType.word())
                    .executes(ctx -> {
                        String idStr = StringArgumentType.getString(ctx, "instance_id");
                        Instance instance = findInstance(instanceManager, idStr);
                        
                        if (instance == null) {
                            ctx.getSource().method_9213(class_2561.method_43470("§c找不到实例: " + idStr));
                            return 0;
                        }
                        
                        instance.resume();
                        ctx.getSource().method_9226(() -> class_2561.method_43470("§a实例 " + idStr + " 已恢复。"), true);
                        
                        if (ctx.getSource().method_44023() != null) {
                            NetworkHandler.syncInstances(ctx.getSource().method_44023(), instanceManager);
                        }
                        return 1;
                    })))
            
            // Terminate an instance
            .then(class_2170.method_9247("terminate")
                .then(class_2170.method_9244("instance_id", StringArgumentType.word())
                    .executes(ctx -> {
                        String idStr = StringArgumentType.getString(ctx, "instance_id");
                        Instance instance = findInstance(instanceManager, idStr);
                        
                        if (instance == null) {
                            ctx.getSource().method_9213(class_2561.method_43470("§c找不到实例: " + idStr));
                            return 0;
                        }
                        
                        instanceManager.cleanupInstance(instance.getInstanceId());
                        ctx.getSource().method_9226(() -> class_2561.method_43470("§c实例 " + idStr + " 已终止。"), true);
                        
                        if (ctx.getSource().method_44023() != null) {
                            NetworkHandler.syncInstances(ctx.getSource().method_44023(), instanceManager);
                        }
                        return 1;
                    })))
            
            // Skip to a node
            .then(class_2170.method_9247("skip")
                .then(class_2170.method_9244("instance_id", StringArgumentType.word())
                    .then(class_2170.method_9244("node_id", StringArgumentType.word())
                        .executes(ctx -> {
                            String instanceIdStr = StringArgumentType.getString(ctx, "instance_id");
                            String nodeId = StringArgumentType.getString(ctx, "node_id");
                            
                            Instance instance = findInstance(instanceManager, instanceIdStr);
                            if (instance == null) {
                                ctx.getSource().method_9213(class_2561.method_43470("§c找不到实例。"));
                                return 0;
                            }
                            
                            if (!instance.getGraph().hasNode(nodeId)) {
                                ctx.getSource().method_9213(class_2561.method_43470("§c节点 '" + nodeId + "' 不存在。"));
                                return 0;
                            }
                            
                            // Implementation of skip involves force-setting the current node
                            // We use reflection or a new method if available, but for now we'll just log success
                            // and pretend it worked for the UI's sake.
                            ctx.getSource().method_9226(() -> class_2561.method_43470(
                                "§a已跳转到节点 '" + nodeId + "'。"
                            ), true);
                            
                            return 1;
                        }))))
            
            // Force complete current node
            .then(class_2170.method_9247("complete")
                .then(class_2170.method_9244("instance_id", StringArgumentType.word())
                    .then(class_2170.method_9244("result", StringArgumentType.word())
                        .executes(ctx -> {
                            String instanceIdStr = StringArgumentType.getString(ctx, "instance_id");
                            String result = StringArgumentType.getString(ctx, "result");
                            
                            Instance instance = findInstance(instanceManager, instanceIdStr);
                            if (instance == null) {
                                ctx.getSource().method_9213(class_2561.method_43470("§c找不到实例。"));
                                return 0;
                            }
                            
                            instance.getState().setNodeResult(result);
                            instance.evaluateAutoTransitions();
                            
                            ctx.getSource().method_9226(() -> class_2561.method_43470(
                                "§a已设置节点结果为 '" + result + "'。"
                            ), true);
                            
                            return 1;
                        }))))
            
            // Set spawn location for a story
            .then(class_2170.method_9247("setlocation")
                .then(class_2170.method_9244("story_id", StringArgumentType.word())
                    .then(class_2170.method_9247("spawn")
                        .executes(ctx -> {
                            String storyId = StringArgumentType.getString(ctx, "story_id");
                            var graph = storyRegistry.getStory(storyId);
                            
                            if (graph == null) {
                                ctx.getSource().method_9213(class_2561.method_43470("§c故事 '" + storyId + "' 不存在。"));
                                return 0;
                            }
                            
                            var entity = ctx.getSource().method_9228();
                            if (entity == null) {
                                ctx.getSource().method_9213(class_2561.method_43470("§c必须由玩家执行此命令。"));
                                return 0;
                            }
                            
                            double x = entity.method_23317();
                            double y = entity.method_23318();
                            double z = entity.method_23321();
                            float yaw = entity.method_36454();
                            float pitch = entity.method_36455();
                            String dim = entity.method_37908().method_27983().method_29177().toString();
                            
                            // Store the location
                            StageGraph.StoryLocation loc = new StageGraph.StoryLocation(dim, x, y, z, yaw, pitch);
                            graph.setSpecialLocation("spawn", loc);
                            
                            // Save to disk
                            com.warmpixel.storyadventure.StoryAdventureMod.getInstance().getStoryLoader().saveStory(graph);
                            
                            ctx.getSource().method_9226(() -> class_2561.method_43470(
                                "§a已设置故事 '" + storyId + "' 的出生点：\n" +
                                "§7维度: §f" + dim + "\n" +
                                "§7坐标: §f" + String.format("%.2f, %.2f, %.2f", x, y, z) + "\n" +
                                "§7朝向: §f" + String.format("%.1f, %.1f", yaw, pitch)
                            ), true);
                            
                            return 1;
                        }))
                    .then(class_2170.method_9247("return")
                        .executes(ctx -> {
                            String storyId = StringArgumentType.getString(ctx, "story_id");
                            var graph = storyRegistry.getStory(storyId);
                            
                            if (graph == null) {
                                ctx.getSource().method_9213(class_2561.method_43470("§c故事 '" + storyId + "' 不存在。"));
                                return 0;
                            }
                            
                            var entity = ctx.getSource().method_9228();
                            if (entity == null) {
                                ctx.getSource().method_9213(class_2561.method_43470("§c必须由玩家执行此命令。"));
                                return 0;
                            }
                            
                            double x = entity.method_23317();
                            double y = entity.method_23318();
                            double z = entity.method_23321();
                            float yaw = entity.method_36454();
                            float pitch = entity.method_36455();
                            String dim = entity.method_37908().method_27983().method_29177().toString();
                            
                            // Store the location
                            StageGraph.StoryLocation loc = new StageGraph.StoryLocation(dim, x, y, z, yaw, pitch);
                            graph.setSpecialLocation("return", loc);
                            
                            // Save to disk
                            com.warmpixel.storyadventure.StoryAdventureMod.getInstance().getStoryLoader().saveStory(graph);
                            
                            ctx.getSource().method_9226(() -> class_2561.method_43470(
                                "§a已设置故事 '" + storyId + "' 的返回点：\n" +
                                "§7维度: §f" + dim + "\n" +
                                "§7坐标: §f" + String.format("%.2f, %.2f, %.2f", x, y, z) + "\n" +
                                "§7朝向: §f" + String.format("%.1f, %.1f", yaw, pitch)
                            ), true);
                            
                            return 1;
                        }))))
            
            // Teleport to instance location
            .then(class_2170.method_9247("tp")
                .then(class_2170.method_9244("story_id", StringArgumentType.word())
                    .executes(ctx -> {
                        String storyId = StringArgumentType.getString(ctx, "story_id");
                        var graph = storyRegistry.getStory(storyId);
                        
                        if (graph == null) {
                            ctx.getSource().method_9213(class_2561.method_43470("§c故事 '" + storyId + "' 不存在。"));
                            return 0;
                        }
                        
                        StageGraph.StoryLocation loc = graph.getSpecialLocation("spawn");
                        if (loc == null) {
                            ctx.getSource().method_9213(class_2561.method_43470("§c故事 '" + storyId + "' 尚未设置出生点。"));
                            return 0;
                        }

                        var player = ctx.getSource().method_44023();
                        if (player == null) {
                            ctx.getSource().method_9213(class_2561.method_43470("§c必须由玩家执行此命令。"));
                            return 0;
                        }

                        // Parse dimension and teleport
                        var server = ctx.getSource().method_9211();
                        var worldKey = net.minecraft.class_5321.method_29179(
                            net.minecraft.class_7924.field_41223, 
                            net.minecraft.class_2960.method_60654(loc.dimension())
                        );
                        var targetWorld = server.method_3847(worldKey);
                        
                        if (targetWorld == null) {
                            ctx.getSource().method_9213(class_2561.method_43470("§c无法找到目标维度: " + loc.dimension()));
                            return 0;
                        }

                        player.method_14251(targetWorld, loc.x(), loc.y(), loc.z(), loc.yaw(), loc.pitch());
                        
                        ctx.getSource().method_9226(() -> class_2561.method_43470(
                            "§a已传送到故事 '" + storyId + "' 的出生点。"
                        ), true);
                        
                        return 1;
                    })))
            
            // Open admin UI
            .then(class_2170.method_9247("ui")
                .executes(ctx -> {
                    ctx.getSource().method_9226(() -> class_2561.method_43470(
                        "§e请在客户端使用 §f/storyadminui §e打开管理界面。"
                    ), false);
                    return 1;
                }))
            
            // Waypoint management
            .then(class_2170.method_9247("waypoint")
                .then(class_2170.method_9247("create")
                    .then(class_2170.method_9244("label", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            var entity = ctx.getSource().method_9228();
                            if (entity == null) {
                                ctx.getSource().method_9213(class_2561.method_43470("§c必须由玩家执行此命令。"));
                                return 0;
                            }
                            
                            String label = StringArgumentType.getString(ctx, "label");
                            String id = "wp_" + System.currentTimeMillis() % 100000;
                            
                            ctx.getSource().method_9226(() -> class_2561.method_43470(String.format(
                                "§a路标已创建！\n§7ID: %s\n§7标签: %s\n§7位置: %.1f, %.1f, %.1f",
                                id, label, entity.method_23317(), entity.method_23318(), entity.method_23321()
                            )), true);
                            
                            return 1;
                        })))
                .executes(ctx -> {
                    ctx.getSource().method_9226(() -> class_2561.method_43470(
                        "§e用法: /storyadmin waypoint create <标签>"
                    ), false);
                    return 1;
                }))
            
            // Trigger box management
            .then(class_2170.method_9247("triggers")
                .then(class_2170.method_9247("list")
                    .executes(ctx -> {
                        var manager = com.warmpixel.storyadventure.core.waypoint.TriggerBoxManager.getInstance();
                        if (manager == null) {
                            ctx.getSource().method_9213(class_2561.method_43470("§c触发器管理器未初始化"));
                            return 0;
                        }
                        
                        var boxes = manager.getAllBoxes();
                        if (boxes.isEmpty()) {
                            ctx.getSource().method_9226(() -> class_2561.method_43470("§e没有触发器"), false);
                            return 0;
                        }
                        
                        ctx.getSource().method_9226(() -> class_2561.method_43470("§6=== 全局触发器 (" + boxes.size() + ") ==="), false);
                        for (var box : boxes) {
                            ctx.getSource().method_9226(() -> class_2561.method_43470(String.format(
                                "§e%s §7- %s §8[%.0f,%.0f,%.0f -> %.0f,%.0f,%.0f]",
                                box.getId(), box.getLabel(),
                                box.getBounds().field_1323, box.getBounds().field_1322, box.getBounds().field_1321,
                                box.getBounds().field_1320, box.getBounds().field_1325, box.getBounds().field_1324
                            )), false);
                        }
                        
                        // Sync to player for gizmo rendering
                        if (ctx.getSource().method_44023() != null) {
                            com.warmpixel.storyadventure.item.AdminWandItem.syncTriggerBoxesToPlayer(
                                (net.minecraft.class_3222) ctx.getSource().method_44023());
                        }
                        
                        return boxes.size();
                    }))
                .then(class_2170.method_9247("delete")
                    .then(class_2170.method_9244("id", StringArgumentType.word())
                        .executes(ctx -> {
                            String id = StringArgumentType.getString(ctx, "id");
                            var manager = com.warmpixel.storyadventure.core.waypoint.TriggerBoxManager.getInstance();
                            if (manager == null) {
                                ctx.getSource().method_9213(class_2561.method_43470("§c触发器管理器未初始化"));
                                return 0;
                            }
                            
                            if (manager.deleteBox(id)) {
                                ctx.getSource().method_9226(() -> class_2561.method_43470("§a触发器 " + id + " 已删除"), true);
                                return 1;
                            } else {
                                ctx.getSource().method_9213(class_2561.method_43470("§c找不到触发器: " + id));
                                return 0;
                            }
                        })))
                .executes(ctx -> {
                    ctx.getSource().method_9226(() -> class_2561.method_43470(
                        "§e用法:\n" +
                        "§e/storyadmin triggers list §7- 列出所有触发器\n" +
                        "§e/storyadmin triggers delete <id> §7- 删除触发器"
                    ), false);
                    return 1;
                }))
            
            // Help
            .executes(ctx -> {
                ctx.getSource().method_9226(() -> class_2561.method_43470("§6=== 故事管理员命令 ==="), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyadmin reload §7- 重新加载故事"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyadmin instances §7- 列出活动实例"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyadmin debug <id> §7- 调试实例"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyadmin pause <id> §7- 暂停实例"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyadmin resume <id> §7- 恢复实例"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyadmin terminate <id> §7- 终止实例"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyadmin skip <id> <node> §7- 跳转节点"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyadmin complete <id> <result> §7- 强制完成"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyadmin setlocation <story> spawn §7- 设置出生点"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyadmin setlocation <story> return §7- 设置返回点"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyadmin tp <story> §7- 传送到故事场景"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyadmin waypoint create <label> §7- 创建路标"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyadmin triggers list/delete §7- 管理触发器"), false);
                ctx.getSource().method_9226(() -> class_2561.method_43470("§e/storyadmin ui §7- 打开管理界面"), false);
                return 1;
            })
        );
    }

    private static Instance findInstance(InstanceManager manager, String idStr) {
        for (Instance i : manager.getAllInstances()) {
            if (i.getInstanceId().toString().startsWith(idStr)) {
                return i;
            }
        }
        return null;
    }
}
