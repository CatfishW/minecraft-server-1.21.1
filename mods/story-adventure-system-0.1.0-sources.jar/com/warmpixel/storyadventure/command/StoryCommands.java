package com.warmpixel.storyadventure.command;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;

/**
 * Basic story commands (player-facing).
 */
public class StoryCommands {
    
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("storyadventure")
            .then(class_2170.method_9247("help")
                .executes(ctx -> {
                    var source = ctx.getSource();
                    source.method_9226(() -> class_2561.method_43470("§6=== 故事冒险系统帮助 ==="), false);
                    source.method_9226(() -> class_2561.method_43470("§e/story list §7- 查看可用故事"), false);
                    source.method_9226(() -> class_2561.method_43470("§e/story start <id> §7- 开始一个故事"), false);
                    source.method_9226(() -> class_2561.method_43470("§e/story leave §7- 离开当前故事"), false);
                    source.method_9226(() -> class_2561.method_43470("§e/story progress §7- 查看进度"), false);
                    source.method_9226(() -> class_2561.method_43470("§e/story join <id> §7- 加入他人的故事"), false);
                    return 1;
                }))
            .then(class_2170.method_9247("version")
                .executes(ctx -> {
                    ctx.getSource().method_9226(() -> class_2561.method_43470(
                        "§6Story Adventure System §7v0.1.0 §8by Warm Pixel"
                    ), false);
                    return 1;
                }))
        );
    }
}
