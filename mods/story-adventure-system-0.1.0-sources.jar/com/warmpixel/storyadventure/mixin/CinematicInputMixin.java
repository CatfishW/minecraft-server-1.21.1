package com.warmpixel.storyadventure.mixin;

import com.warmpixel.storyadventure.client.cinematic.CinematicCameraController;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin to disable player keyboard input during cinematic cutscenes.
 */
@Mixin(class_743.class)
public class CinematicInputMixin {
    
    /**
     * Disable all movement input during cutscenes.
     */
    @Inject(method = "tick", at = @At("TAIL"))
    private void storyadventure$disableInputDuringCutscene(boolean slowDown, float slowDownFactor, CallbackInfo ci) {
        CinematicCameraController controller = CinematicCameraController.getInstance();
        if (controller.isActive()) {
            class_744 input = (class_744)(Object)this;
            
            // Zero out all movement
            input.field_3905 = 0;
            input.field_3907 = 0;
            input.field_3910 = false;
            input.field_3909 = false;
            input.field_3908 = false;
            input.field_3906 = false;
            input.field_3904 = false;
            input.field_3903 = false;
        }
    }
}
