package com.warmpixel.storyadventure.mixin;

import com.warmpixel.storyadventure.client.cinematic.CinematicCameraController;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin to hide HUD elements during cinematic cutscenes.
 */
@Mixin(class_329.class)
public class CinematicGuiMixin {
    
    /**
     * Hide the main HUD group (hotbar, health, exp, etc.) during cutscenes.
     */
    @Inject(method = "renderHotbarAndDecorations", at = @At("HEAD"), cancellable = true)
    private void storyadventure$hideHudGroup(class_332 graphics, class_9779 deltaTracker, CallbackInfo ci) {
        if (CinematicCameraController.getInstance().isActive()) {
            ci.cancel();
        }
    }
    
    /**
     * Hide the crosshair during cutscenes.
     */
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void storyadventure$hideCrosshair(class_332 graphics, class_9779 deltaTracker, CallbackInfo ci) {
        if (CinematicCameraController.getInstance().isActive()) {
            ci.cancel();
        }
    }
}
