package com.warmpixel.storyadventure.mixin;

import com.warmpixel.storyadventure.client.cinematic.CinematicCameraController;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_746;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin to hide held items/arms during cinematic cutscenes.
 */
@Mixin(class_759.class)
public class CinematicItemInHandRendererMixin {
    
    /**
     * Skip rendering hands and items when a cutscene is active.
     */
    @Inject(method = "renderHandsWithItems", at = @At("HEAD"), cancellable = true)
    private void storyadventure$hideHandsDuringCutscene(float partialTicks, class_4587 poseStack, class_4597.class_4598 bufferSource, class_746 player, int light, CallbackInfo ci) {
        if (CinematicCameraController.getInstance().isActive()) {
            ci.cancel();
        }
    }
}
