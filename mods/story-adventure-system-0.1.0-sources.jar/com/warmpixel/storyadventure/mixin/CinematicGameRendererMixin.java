package com.warmpixel.storyadventure.mixin;

import com.warmpixel.storyadventure.client.cinematic.CinematicCameraController;
import net.minecraft.class_4184;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Mixin to override FOV during cinematic cutscenes.
 */
@Mixin(class_757.class)
public class CinematicGameRendererMixin {
    
    /**
     * Override FOV when cinematic camera is active.
     */
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void storyadventure$overrideFov(class_4184 camera, float partialTicks, boolean useFovSetting, 
                                             CallbackInfoReturnable<Double> cir) {
        CinematicCameraController controller = CinematicCameraController.getInstance();
        if (controller.isActive()) {
            cir.setReturnValue((double) controller.getCameraFov());
        }
    }
}
