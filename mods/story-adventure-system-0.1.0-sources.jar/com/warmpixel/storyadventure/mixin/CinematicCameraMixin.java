package com.warmpixel.storyadventure.mixin;

import com.warmpixel.storyadventure.client.cinematic.CinematicCameraController;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin to override camera position and rotation during cinematic cutscenes.
 */
@Mixin(class_4184.class)
public abstract class CinematicCameraMixin {
    
    @Shadow
    private float xRot;
    
    @Shadow
    private float yRot;
    
    @Shadow
    protected abstract void setPosition(double x, double y, double z);
    
    @Shadow
    protected abstract void setRotation(float yRot, float xRot);
    
    /**
     * Override camera setup when cinematic is active.
     */
    @Inject(method = "setup", at = @At("TAIL"))
    private void storyadventure$overrideCameraSetup(class_1922 level, class_1297 focusedEntity, 
                                                     boolean detached, boolean thirdPersonReverse, 
                                                     float partialTick, CallbackInfo ci) {
        CinematicCameraController controller = CinematicCameraController.getInstance();
        if (controller.isActive()) {
            // Override camera position
            var pos = controller.getCameraPosition();
            setPosition(pos.field_1352, pos.field_1351, pos.field_1350);
            
            // Override camera rotation
            setRotation(controller.getCameraYaw(), controller.getCameraPitch());
        }
    }
}
