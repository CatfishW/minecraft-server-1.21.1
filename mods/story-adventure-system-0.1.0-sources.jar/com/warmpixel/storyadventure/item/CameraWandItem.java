package com.warmpixel.storyadventure.item;

import com.warmpixel.storyadventure.client.ui.CameraRecorderScreen;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_310;

/**
 * Camera Recording Wand - A tool for recording camera positions and rotations.
 * Right-click opens the Camera Recorder UI panel.
 * Used to create camera paths for cutscenes.
 */
public class CameraWandItem extends class_1792 {
    
    public CameraWandItem() {
        super(new class_1793()
            .method_7889(1)
            .method_7894(class_1814.field_8903)
        );
    }
    
    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        
        // Check if player has permission (OP level 2+)
        if (!player.method_5687(2)) {
            if (!level.field_9236) {
                player.method_43496(class_2561.method_43470("§c你需要管理员权限才能使用摄像机魔杖"));
            }
            return class_1271.method_22431(stack);
        }
        
        // Open Camera Recorder UI on client
        if (level.field_9236) {
            openCameraRecorderUI();
        }
        
        return class_1271.method_29237(stack, level.field_9236);
    }
    
    @net.fabricmc.api.Environment(net.fabricmc.api.EnvType.CLIENT)
    private void openCameraRecorderUI() {
        class_310.method_1551().method_1507(new CameraRecorderScreen());
    }
    
    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 flag) {
        tooltip.add(class_2561.method_43470("摄像机录制魔杖").method_27692(class_124.field_1080));
        tooltip.add(class_2561.method_43470(""));
        tooltip.add(class_2561.method_43470("右键 - 打开录制面板").method_27692(class_124.field_1054));
        tooltip.add(class_2561.method_43470("用于录制过场动画的摄像机路径").method_27692(class_124.field_1080));
        tooltip.add(class_2561.method_43470("").method_27692(class_124.field_1080));
        tooltip.add(class_2561.method_43470("仅限管理员").method_27692(class_124.field_1061));
    }
    
    @Override
    public boolean method_7886(class_1799 stack) {
        return true; // Always show enchantment glint
    }
}
