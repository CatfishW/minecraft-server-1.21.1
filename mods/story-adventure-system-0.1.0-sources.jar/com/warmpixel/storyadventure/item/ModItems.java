package com.warmpixel.storyadventure.item;

import com.warmpixel.storyadventure.StoryAdventureMod;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Registry for all Story Adventure items.
 */
public class ModItems {
    
    public static final String MOD_ID = StoryAdventureMod.MOD_ID;
    private static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    
    public static final class_1792 ADMIN_WAND = register("admin_wand", new AdminWandItem());
    public static final class_1792 CAMERA_WAND = register("camera_wand", new CameraWandItem());
    
    private static class_1792 register(String name, class_1792 item) {
        return class_2378.method_10230(
            class_7923.field_41178,
            class_2960.method_60655(MOD_ID, name),
            item
        );
    }
    
    public static void registerItems() {
        LOGGER.info("Registering Story Adventure items...");
    }
}

