package com.warmpixel.storyadventure.item;

import com.warmpixel.storyadventure.client.ui.admin.AdminDashboardScreen;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;

/**
 * Admin Wand - A special item for story administrators.
 * Right-click opens the admin dashboard UI.
 * Shift+Right-click creates trigger boxes (2-click selection).
 */
public class AdminWandItem extends class_1792 {
    
    // Track pending trigger box corners per player
    private static final Map<UUID, class_243> pendingCorner1 = new HashMap<>();
    
    public AdminWandItem() {
        super(new class_1793()
            .method_7889(1)
            .method_7894(class_1814.field_8904)
        );
    }
    
    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        
        // Check if player has permission (OP level 2+)
        if (!player.method_5687(2)) {
            if (!level.field_9236) {
                player.method_43496(class_2561.method_43471("item.storyadventure.admin_wand.no_permission"));
            }
            return class_1271.method_22431(stack);
        }
        
        // Shift+Right Click = Creation Mode
        if (player.method_5715()) {
            if (!level.field_9236) {
                // Check if Ctrl is also held (check via sneaking + crouching state)
                // For now, Shift+RClick = Trigger Box, we'll add waypoint via command
                handleTriggerBoxCreation(player);
            }
            return class_1271.method_29237(stack, level.field_9236);
        }
        
        // Normal Right Click = Open Admin UI
        if (level.field_9236) {
            openAdminUI();
        } else {
            player.method_43496(class_2561.method_43471("item.storyadventure.admin_wand.opening_dashboard"));
            
            // Also sync trigger boxes to this player for gizmo rendering
            if (player instanceof net.minecraft.class_3222 sp) {
                syncTriggerBoxesToPlayer(sp);
            }
        }
        
        return class_1271.method_29237(stack, level.field_9236);
    }
    
    /**
     * Handle trigger box creation (server-side).
     * First click: Set corner 1
     * Second click: Set corner 2 and create box
     */
    private void handleTriggerBoxCreation(class_1657 player) {
        UUID playerId = player.method_5667();
        class_243 currentPos = player.method_19538();
        
        if (pendingCorner1.containsKey(playerId)) {
            // Second click - create the box
            class_243 corner1 = pendingCorner1.remove(playerId);
            class_243 corner2 = currentPos;
            
            // Generate unique ID
            String boxId = "trigger_" + System.currentTimeMillis() % 100000;
            
            // Log the creation
            player.method_43496(class_2561.method_43469("item.storyadventure.admin_wand.trigger_created", 
                boxId, corner1.field_1352, corner1.field_1351, corner1.field_1350, corner2.field_1352, corner2.field_1351, corner2.field_1350));
            
            // Create and save the trigger box on server
            if (player instanceof net.minecraft.class_3222 serverPlayer) {
                var manager = com.warmpixel.storyadventure.core.waypoint.TriggerBoxManager.getInstance();
                if (manager != null) {
                    var bounds = new net.minecraft.class_238(corner1, corner2);
                    manager.createBox(boxId, bounds, class_2561.method_43471("gui.storyadventure.admin.triggers.new_trigger").getString());
                    
                    // Sync all boxes to this player for gizmo rendering
                    syncTriggerBoxesToPlayer(serverPlayer);
                }
            }
            
            // Store in temporary registry for editor UI
            PendingTriggerBoxes.store(playerId, boxId, corner1, corner2);
            
        } else {
            // First click - store corner 1
            pendingCorner1.put(playerId, currentPos);
            player.method_43496(class_2561.method_43469("item.storyadventure.admin_wand.corner1_set", 
                currentPos.field_1352, currentPos.field_1351, currentPos.field_1350));
        }
    }
    
    /**
     * Cancel pending box creation for a player.
     */
    public static void cancelPending(UUID playerId) {
        pendingCorner1.remove(playerId);
    }
    
    /**
     * Check if a player has a pending corner.
     */
    public static boolean hasPendingCorner(UUID playerId) {
        return pendingCorner1.containsKey(playerId);
    }
    
    @net.fabricmc.api.Environment(net.fabricmc.api.EnvType.CLIENT)
    private void openAdminUI() {
        class_310.method_1551().method_1507(new AdminDashboardScreen());
    }
    
    @Override
    public void method_7851(class_1799 stack, class_9635 context, List<class_2561> tooltip, class_1836 flag) {
        tooltip.add(class_2561.method_43471("item.storyadventure.admin_wand.tooltip.title").method_27692(net.minecraft.class_124.field_1080));
        tooltip.add(class_2561.method_43470(""));
        tooltip.add(class_2561.method_43471("item.storyadventure.admin_wand.tooltip.right_click").method_27692(net.minecraft.class_124.field_1054));
        tooltip.add(class_2561.method_43471("item.storyadventure.admin_wand.tooltip.shift_right_click").method_27692(net.minecraft.class_124.field_1054));
        tooltip.add(class_2561.method_43471("item.storyadventure.admin_wand.tooltip.waypoint").method_27692(net.minecraft.class_124.field_1080));
        tooltip.add(class_2561.method_43471("item.storyadventure.admin_wand.tooltip.admin_only").method_27692(net.minecraft.class_124.field_1061));
    }
    
    @Override
    public boolean method_7886(class_1799 stack) {
        return true; // Always show enchantment glint
    }
    
    /**
     * Sync all trigger boxes to a player for gizmo rendering.
     */
    public static void syncTriggerBoxesToPlayer(net.minecraft.class_3222 player) {
        var manager = com.warmpixel.storyadventure.core.waypoint.TriggerBoxManager.getInstance();
        if (manager == null) return;
        
        java.util.List<com.warmpixel.storyadventure.network.SyncTriggerBoxesPayload.TriggerBoxData> boxes = 
            new java.util.ArrayList<>();
        
        for (var box : manager.getAllBoxes()) {
            var bounds = box.getBounds();
            boxes.add(new com.warmpixel.storyadventure.network.SyncTriggerBoxesPayload.TriggerBoxData(
                box.getId(), box.getLabel(),
                bounds.field_1323, bounds.field_1322, bounds.field_1321,
                bounds.field_1320, bounds.field_1325, bounds.field_1324,
                !box.getPlayersInside().isEmpty()
            ));
        }
        
        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(player, 
            new com.warmpixel.storyadventure.network.SyncTriggerBoxesPayload(boxes));
    }
    
    /**
     * Temporary storage for pending trigger boxes awaiting editor.
     */
    public static class PendingTriggerBoxes {
        private static final Map<UUID, PendingBox> pending = new HashMap<>();
        
        public static void store(UUID playerId, String boxId, class_243 corner1, class_243 corner2) {
            pending.put(playerId, new PendingBox(boxId, corner1, corner2));
        }
        
        public static PendingBox get(UUID playerId) {
            return pending.get(playerId);
        }
        
        public static PendingBox remove(UUID playerId) {
            return pending.remove(playerId);
        }
        
        public record PendingBox(String id, class_243 corner1, class_243 corner2) {}
    }
}
