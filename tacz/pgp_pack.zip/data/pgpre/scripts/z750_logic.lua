local M = {}

function M.shoot(api)
    if(api:getFireMode() == AUTO)then
        api:shootOnce(api:isShootingNeedConsumeAmmo() == FALSE)
    end
    if(api:getFireMode() == BURST)then
        api:shootOnce(api:isShootingNeedConsumeAmmo())
        api:putAmmoInMagazine(1)
    end
    if(api:getFireMode() == SEMI)then
        api:shootOnce(api:isShootingNeedConsumeAmmo())
        api:putAmmoInMagazine(1)
    end
end

return M